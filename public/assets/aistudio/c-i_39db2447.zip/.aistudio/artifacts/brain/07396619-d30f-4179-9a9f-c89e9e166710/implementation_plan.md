# Implementation Plan: Compose Multiplatform Desktop App (Windows/Mac) & Bilingual (HE/EN) Interface

This plan outlines the creation of a native **Compose for Desktop (JVM)** application module for **Contact Ways** (exportable as a Windows `.exe`/`.msi`, macOS `.dmg`, or Linux `.deb`), together with a live **Bilingual Switcher (`עברית / EN`)** that dynamically switches between Hebrew (RTL) and English (LTR).

---

## 1. Bilingual Switchable Interface (`עברית ⇄ English`)
- **Live Language Toggle (`AppLanguage.HE` / `AppLanguage.EN`)**:
  - Add a prominent **`עברית | EN`** toggle button in the Top Bar, Side Navigation Rail, and Opening Animation Screen.
  - Dynamically switches `LocalLayoutDirection` between **`LayoutDirection.Rtl`** (Hebrew) and **`LayoutDirection.Ltr`** (English).
- **Full Localization of Core Somatic Content**:
  - **Opening Weight-Transfer Screen & Rationale Dialog**: Full English and Hebrew titles, descriptions, and rationale explanations.
  - **Navigation Tabs**:
    - `ראשי` / `Home`
    - `רשומות` / `Records`
    - `רפלקציה חדשה` / `New Reflection`
    - `שיחות` / `Inquiries`
    - `התקדמות` / `Progress`
    - `חשבון משתמש` / `Profile`
  - **6 Somatic Radar Axes & `ⓘ` Info Guides**:
    1. *Somatic Attunement* (`הקשבה סומטית`)
    2. *Weight Sharing* (`שיתוף משקל`)
    3. *Boundaries & Consent* (`גבולות והסכמה`)
    4. *Falling & Momentum* (`נפילה ומומנטום`)
    5. *Grounding — The Small Dance* (`קרקוע — הריקוד הקטן`)
    6. *Tactile Attention* (`תשומת לב עורית`)
  - **All Info & Guidance Dialogs (`ⓘ`)**: Bilingual explanations, 1–10 rating scale descriptions, practical tips, and reflection prompts.

---

## 2. Compose Multiplatform Desktop Module (`/desktop`)
- **Dedicated Desktop Application Module (`/desktop`)**:
  - **`/desktop/build.gradle.kts` & `/desktop/settings.gradle.kts`**: Configured with `org.jetbrains.compose` and `org.jetbrains.kotlin.plugin.compose` targeting JVM 17, including `compose.desktop.currentOs`.
  - **Native Installer Packaging (`nativeDistributions`)**:
    - Configured for **Windows (`TargetFormat.Msi`, `TargetFormat.Exe`)**, **macOS (`TargetFormat.Dmg`)**, and **Linux (`TargetFormat.Deb`)** with the custom `C-i` framed launcher icon, window title `"Contact Ways — Moving Dialogue"`, and default 1280×840 widescreen window size (plus full-screen keyboard shortcut `F11`).
  - **Desktop Entry Point (`/desktop/src/jvmMain/kotlin/com/example/desktop/Main.kt`)**:
    - Launches the native desktop `Window` with keyboard shortcuts (`F11` for Full-Screen, `Ctrl+N` / `Cmd+N` for New 6-Axis Reflection, `Ctrl+L` / `Cmd+L` to toggle Hebrew/English, `Ctrl+G` for Somatic Guide) and shares the widescreen two-column Compose architecture.
- **Step-by-Step Export & Packaging Guide (`/DESKTOP_BUILD_GUIDE.md`)**:
  - Clear instructions on how to export the project ZIP from AI Studio and run `./gradlew run` or `./gradlew packageDistributionForCurrentOs` on Windows or Mac to generate your standalone desktop executable.
