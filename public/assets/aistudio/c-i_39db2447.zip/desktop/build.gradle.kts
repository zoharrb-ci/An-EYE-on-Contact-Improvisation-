import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
  kotlin("multiplatform") version "2.0.21"
  id("org.jetbrains.compose") version "1.7.1"
  id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
}

group = "com.aistudio.contactways"
version = "1.0.0"

kotlin {
  jvm {
    withJava()
  }
  sourceSets {
    val jvmMain by getting {
      // Share model, repository, theme, components, screens, and viewmodel with the Android app
      kotlin.srcDir("../app/src/main/java/com/example/data")
      kotlin.srcDir("../app/src/main/java/com/example/ui")
      resources.srcDir("../app/src/main/res/drawable")

      dependencies {
        implementation(compose.desktop.currentOs)
        implementation(compose.material3)
        implementation(compose.materialIconsExtended)
        implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.9.0")
        implementation("org.jetbrains.androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
      }
    }
  }
}

compose.desktop {
  application {
    mainClass = "com.example.desktop.MainKt"

    nativeDistributions {
      targetFormats(
        TargetFormat.Dmg, // macOS installer
        TargetFormat.Msi, // Windows installer
        TargetFormat.Exe, // Windows standalone executable
        TargetFormat.Deb  // Linux Debian/Ubuntu package
      )
      packageName = "Contact Ways"
      packageVersion = "1.0.0"
      description = "Contact Ways (ci-eye) — Bilingual Somatic Reflection & Contact Improvisation Desktop Suite"
      vendor = "Contact Ways Studio"

      windows {
        menuGroup = "Contact Ways"
        shortcut = true
        upgradeUuid = "07396619-d30f-4179-9a9f-c89e9e166710"
      }
      macOS {
        bundleID = "com.aistudio.contactways.desktop"
        dockName = "Contact Ways"
      }
      linux {
        packageName = "contact-ways"
        shortcut = true
      }
    }
  }
}
