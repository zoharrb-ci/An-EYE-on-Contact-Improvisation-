package com.example.desktop

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isMetaPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPlacement
import androidx.compose.ui.window.WindowPosition
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import com.example.ContactWaysMainApp
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.theme.AppLanguage
import com.example.ui.theme.ContactWaysTheme
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.ContactWaysViewModel

/**
 * Contact Ways — Native Desktop Application Entry Point (Windows / macOS / Linux)
 *
 * Keyboard Shortcuts:
 * - F11: Toggle Full-Screen Window Placement
 * - Ctrl+L / Cmd+L: Toggle Bilingual Language (Hebrew RTL <-> English LTR)
 * - Ctrl+N / Cmd+N: Open 6-Axis New Reflection Tab
 * - Ctrl+G / Cmd+G: Open Somatic Info & Guidance Modal
 */
fun main() = application {
  val viewModel = remember {
    ContactWaysViewModel().apply {
      detectAndApplyDeviceLocality(null)
      // Open directly in widescreen desktop mode on desktop computers
      enterDesktopWidescreenPreview()
    }
  }

  val appLanguage by viewModel.appLanguage.collectAsState()
  val isFullScreen by viewModel.isFullScreenMode.collectAsState()

  val windowState = rememberWindowState(
    placement = if (isFullScreen) WindowPlacement.Fullscreen else WindowPlacement.Floating,
    position = WindowPosition(Alignment.Center),
    size = DpSize(1360.dp, 860.dp)
  )

  val windowTitle = if (appLanguage == AppLanguage.HE) {
    "Contact Ways — הדיאלוג הנע (ci-eye) • מהדורת שולחן עבודה"
  } else {
    "Contact Ways — ${com.example.ui.theme.trLang(appLanguage, "הדיאלוג הנע • ci-eye", "Moving Dialogue • ci-eye")}"
  }

  Window(
    onCloseRequest = ::exitApplication,
    state = windowState,
    title = windowTitle,
    onPreviewKeyEvent = { event ->
      if (event.type == KeyEventType.KeyDown) {
        val ctrlOrCmd = event.isCtrlPressed || event.isMetaPressed
        when {
          event.key == Key.F11 -> {
            viewModel.toggleFullScreenMode()
            windowState.placement =
              if (windowState.placement == WindowPlacement.Fullscreen) WindowPlacement.Floating
              else WindowPlacement.Fullscreen
            true
          }
          ctrlOrCmd && event.key == Key.L -> {
            viewModel.toggleLanguage()
            true
          }
          ctrlOrCmd && event.key == Key.N -> {
            viewModel.selectTab(AppNavTab.REFLECTION)
            true
          }
          ctrlOrCmd && event.key == Key.G -> {
            viewModel.openGuideTopic(SomaticGuideTopic.GUIDE_APP_OVERVIEW)
            true
          }
          else -> false
        }
      } else {
        false
      }
    }
  ) {
    ContactWaysTheme {
      CompositionLocalProvider(
        LocalAppLanguage provides appLanguage,
        LocalLayoutDirection provides appLanguage.layoutDirection
      ) {
        ContactWaysMainApp(viewModel = viewModel)
      }
    }
  }
}
