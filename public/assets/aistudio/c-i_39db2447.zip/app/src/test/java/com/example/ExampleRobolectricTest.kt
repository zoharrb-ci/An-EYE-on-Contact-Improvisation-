package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.ContactWaysRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Contact Ways", appName)
  }

  @Test
  fun `verify repository initial data`() {
    val repository = ContactWaysRepository()
    assertTrue(repository.records.value.isNotEmpty())
    assertTrue(repository.inquiries.value.isNotEmpty())
    assertTrue(repository.recommendations.size == 6)
    assertNotNull(repository.dancerProfile.value)
    assertTrue(repository.somaticProgress.value.overallIndex > 0f)
  }

  @Test
  fun `verify 6-axis reflection updates somatic progress`() {
    val viewModel = com.example.ui.viewmodel.ContactWaysViewModel()
    val initialCount = viewModel.filteredRecords.value.size
    viewModel.saveNewRecord(
      title = "רפלקציית בדיקה",
      partner = "דנה",
      jamName = "ג'אם שישי",
      durationMinutes = 60,
      pillar = "שיתוף משקל",
      contactPoints = listOf("גב אל גב"),
      weightShare = 9.5f,
      attunement = 9.0f,
      boundaryClarity = 9.2f,
      fallingMomentum = 8.8f,
      grounding = 9.4f,
      tactileAttention = 9.1f,
      twoRiversState = "שני הנהרות (מאוזן)",
      reflectionNotes = "הערת רפלקציה מלאה על ששת הצירים",
      keyTakeaway = "נשימה לתוך נקודת המגע",
      navigateToRecordsOnSave = true
    )
    assertEquals(com.example.ui.viewmodel.AppNavTab.RECORDS, viewModel.currentTab.value)
    assertNotNull(viewModel.selectedRecord.value)
    assertEquals(9.5f, viewModel.selectedRecord.value?.weightSharingLevel)
    assertEquals(8.8f, viewModel.selectedRecord.value?.fallingMomentumLevel)
    assertEquals(9.4f, viewModel.selectedRecord.value?.groundingLevel)
    assertEquals(9.1f, viewModel.selectedRecord.value?.tactileAttentionLevel)
    assertTrue(viewModel.somaticProgress.value.overallIndex > 0f)
    assertTrue(initialCount >= 0)
  }

  @Test
  fun `verify desktop fullscreen and guide topic state`() {
    val viewModel = com.example.ui.viewmodel.ContactWaysViewModel()
    assertEquals(false, viewModel.isFullScreenMode.value)
    viewModel.toggleFullScreenMode()
    assertEquals(true, viewModel.isFullScreenMode.value)

    viewModel.toggleDesktopMode(false)
    assertEquals(true, viewModel.isDesktopModeOverride.value)

    viewModel.openGuideTopic(com.example.ui.components.SomaticGuideTopic.AXIS_WEIGHT_SHARING)
    assertEquals(
      com.example.ui.components.SomaticGuideTopic.AXIS_WEIGHT_SHARING,
      viewModel.activeGuideTopic.value
    )
    viewModel.closeGuideTopic()
    assertEquals(null, viewModel.activeGuideTopic.value)
  }

  @Test
  fun `verify bilingual language switching`() {
    val viewModel = com.example.ui.viewmodel.ContactWaysViewModel()
    assertEquals(com.example.ui.theme.AppLanguage.HE, viewModel.appLanguage.value)
    assertEquals("רפלקציה חדשה", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))

    viewModel.toggleLanguage()
    assertEquals(com.example.ui.theme.AppLanguage.EN, viewModel.appLanguage.value)
    assertEquals("New Reflection", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))
  }

  @Test
  fun `verify israel locality rule and 10 languages support`() {
    val viewModel = com.example.ui.viewmodel.ContactWaysViewModel()

    // When in Israel locality, Hebrew + 9 international languages = 10 languages
    viewModel.setIsraelLocalityOverride(true)
    assertTrue(viewModel.availableLanguages.value.contains(com.example.ui.theme.AppLanguage.HE))
    assertEquals(10, viewModel.availableLanguages.value.size)

    // When outside Israel, Hebrew is NOT offered (9 languages: EN, IT, DE, ES, UK, PT, RU, KO, JA)
    viewModel.setIsraelLocalityOverride(false)
    assertTrue(!viewModel.availableLanguages.value.contains(com.example.ui.theme.AppLanguage.HE))
    assertEquals(9, viewModel.availableLanguages.value.size)

    // Verify Italian, German, Spanish, Ukrainian, Portuguese, Russian, Korean, Japanese translations
    viewModel.setLanguage(com.example.ui.theme.AppLanguage.IT)
    assertEquals("Nuova Riflessione", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))

    viewModel.setLanguage(com.example.ui.theme.AppLanguage.DE)
    assertEquals("Neue Reflexion", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))

    viewModel.setLanguage(com.example.ui.theme.AppLanguage.ES)
    assertEquals("Nueva Reflexión", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))

    viewModel.setLanguage(com.example.ui.theme.AppLanguage.UK)
    assertEquals("Нова Рефлексія", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))

    viewModel.setLanguage(com.example.ui.theme.AppLanguage.PT)
    assertEquals("Nova Reflexão", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))

    viewModel.setLanguage(com.example.ui.theme.AppLanguage.RU)
    assertEquals("Новая Рефлексия", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))

    viewModel.setLanguage(com.example.ui.theme.AppLanguage.KO)
    assertEquals("새 성찰", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))

    viewModel.setLanguage(com.example.ui.theme.AppLanguage.JA)
    assertEquals("新しいリフレクション", com.example.ui.viewmodel.AppNavTab.REFLECTION.title(viewModel.appLanguage.value))
  }
}
