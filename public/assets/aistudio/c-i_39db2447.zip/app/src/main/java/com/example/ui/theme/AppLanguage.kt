package com.example.ui.theme

import android.content.res.Resources
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale
import java.util.TimeZone

enum class AppLanguage(
  val code: String,
  val displayLabel: String,
  val nativeCountry: String,
  val toggleBadge: String,
  val flagEmoji: String,
  val layoutDirection: LayoutDirection,
  val israelOnly: Boolean = false
) {
  HE(
    code = "he",
    displayLabel = "עברית",
    nativeCountry = "ישראל (IL)",
    toggleBadge = "עב",
    flagEmoji = "🇮🇱",
    layoutDirection = LayoutDirection.Rtl,
    israelOnly = true
  ),
  EN(
    code = "en",
    displayLabel = "English",
    nativeCountry = "International",
    toggleBadge = "EN",
    flagEmoji = "🇬🇧",
    layoutDirection = LayoutDirection.Ltr
  ),
  IT(
    code = "it",
    displayLabel = "Italiano",
    nativeCountry = "Italia",
    toggleBadge = "IT",
    flagEmoji = "🇮🇹",
    layoutDirection = LayoutDirection.Ltr
  ),
  DE(
    code = "de",
    displayLabel = "Deutsch",
    nativeCountry = "Deutschland / DACH",
    toggleBadge = "DE",
    flagEmoji = "🇩🇪",
    layoutDirection = LayoutDirection.Ltr
  ),
  ES(
    code = "es",
    displayLabel = "Español",
    nativeCountry = "España / LatAm",
    toggleBadge = "ES",
    flagEmoji = "🇪🇸",
    layoutDirection = LayoutDirection.Ltr
  ),
  UK(
    code = "uk",
    displayLabel = "Українська",
    nativeCountry = "Україна",
    toggleBadge = "UA",
    flagEmoji = "🇺🇦",
    layoutDirection = LayoutDirection.Ltr
  ),
  PT(
    code = "pt",
    displayLabel = "Português",
    nativeCountry = "Portugal / Brasil",
    toggleBadge = "PT",
    flagEmoji = "🇵🇹",
    layoutDirection = LayoutDirection.Ltr
  ),
  RU(
    code = "ru",
    displayLabel = "Русский",
    nativeCountry = "Русскоязычный",
    toggleBadge = "RU",
    flagEmoji = "🇷🇺",
    layoutDirection = LayoutDirection.Ltr
  ),
  KO(
    code = "ko",
    displayLabel = "한국어",
    nativeCountry = "대한민국 (Korea)",
    toggleBadge = "KO",
    flagEmoji = "🇰🇷",
    layoutDirection = LayoutDirection.Ltr
  ),
  JA(
    code = "ja",
    displayLabel = "日本語",
    nativeCountry = "日本 (Japan)",
    toggleBadge = "JA",
    flagEmoji = "🇯🇵",
    layoutDirection = LayoutDirection.Ltr
  );

  companion object {
    /**
     * Returns the list of languages offered to the user based on device locality.
     * Hebrew (HE) is offered ONLY when the device locality is Israel (IL).
     */
    fun availableLanguages(isIsraelLocality: Boolean): List<AppLanguage> {
      return entries.filter { !it.israelOnly || isIsraelLocality }
    }
  }
}

data class DeviceLocalityInfo(
  val languageCode: String,
  val countryCode: String,
  val timeZoneId: String,
  val localeTag: String,
  val isIsraelDeviceLocality: Boolean
)

object DeviceLocalityDetector {
  private val israelTimeZones = setOf(
    "Asia/Jerusalem",
    "Asia/Tel_Aviv",
    "Israel",
    "Asia/Hebron"
  )

  fun detectDeviceLocality(): DeviceLocalityInfo {
    val defaultLocale = Locale.getDefault()
    val tzId = TimeZone.getDefault().id ?: ""

    var foundIsraelInSystemLocales = false
    var primaryLocale = defaultLocale
    try {
      val localeList = Resources.getSystem().configuration.locales
      if (!localeList.isEmpty) {
        primaryLocale = localeList[0]
        for (i in 0 until localeList.size()) {
          val loc = localeList[i]
          if (loc.country.equals("IL", ignoreCase = true) ||
            loc.language.equals("he", ignoreCase = true) ||
            loc.language.equals("iw", ignoreCase = true)
          ) {
            foundIsraelInSystemLocales = true
          }
        }
      }
    } catch (_: Throwable) {
      // Fallback for JVM Desktop or unit test environments
    }

    val langCode = primaryLocale.language.lowercase()
    val countryCode = primaryLocale.country.uppercase()
    val isIsrael = foundIsraelInSystemLocales ||
      countryCode == "IL" ||
      langCode == "he" ||
      langCode == "iw" ||
      tzId in israelTimeZones

    val effectiveCountry = if (countryCode.isNotBlank()) countryCode else if (isIsrael) "IL" else "INTL"
    return DeviceLocalityInfo(
      languageCode = langCode,
      countryCode = effectiveCountry,
      timeZoneId = tzId,
      localeTag = primaryLocale.toLanguageTag(),
      isIsraelDeviceLocality = isIsrael
    )
  }

  /**
   * Selects the best initial AppLanguage matching the device's locale and locality rules:
   * - Hebrew (HE) is selected only if isIsraelLocality == true and locale is Hebrew/Israel.
   * - Italian (IT), German (DE), Spanish (ES), Ukrainian (UK), Portuguese (PT),
   *   Russian (RU), Korean (KO), Japanese (JA) are selected when the device language/country matches them.
   * - Otherwise defaults to HE when in Israel, or EN when outside Israel.
   */
  fun detectInitialLanguage(localityInfo: DeviceLocalityInfo = detectDeviceLocality()): AppLanguage {
    val lang = localityInfo.languageCode
    val country = localityInfo.countryCode

    return when {
      lang == "it" || country == "IT" -> AppLanguage.IT
      lang == "de" || country in setOf("DE", "AT", "CH") -> AppLanguage.DE
      lang == "es" || country in setOf("ES", "MX", "AR", "CO", "CL", "PE") -> AppLanguage.ES
      lang == "uk" || country == "UA" -> AppLanguage.UK
      lang == "pt" || country in setOf("PT", "BR") -> AppLanguage.PT
      lang == "ru" || country == "RU" -> AppLanguage.RU
      lang == "ko" || country == "KR" -> AppLanguage.KO
      lang == "ja" || country == "JP" -> AppLanguage.JA
      localityInfo.isIsraelDeviceLocality -> AppLanguage.HE
      else -> AppLanguage.EN
    }
  }
}

val LocalAppLanguage = compositionLocalOf { AppLanguage.HE }

@Composable
@ReadOnlyComposable
fun tr(he: String, en: String): String {
  return MultilingualTranslations.translate(LocalAppLanguage.current, he, en)
}

fun trLang(lang: AppLanguage, he: String, en: String): String {
  return MultilingualTranslations.translate(lang, he, en)
}
