package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo & Violet tones
val SomaticPrimary = Color(0xFF4F46E5) // Indigo 600
val SomaticPrimaryLight = Color(0xFF6366F1) // Indigo 500
val SomaticPrimaryDark = Color(0xFF3730A3) // Indigo 800
val SomaticOnPrimary = Color(0xFFFFFFFF)

// Earth & Grounding accents
val GroundAmber = Color(0xFFD97706) // Amber 600
val EarthSage = Color(0xFF059669) // Emerald 600
val SoftClay = Color(0xFFB45309) // Warm terracotta
val VioletGlow = Color(0xFF7C3AED) // Purple 600

// Backgrounds & Surfaces (Bright Light Skin)
val LightBackground = Color(0xFFFBFDFF) // Crisp Airy Sky-White
val LightSurface = Color(0xFFFFFFFF) // Pure White
val LightSurfaceVariant = Color(0xFFF0F7FF) // Soft Sky Tint
val LightBorder = Color(0xFFDCE8F5) // Soft Sky Border
val LightTextPrimary = Color(0xFF1E293B) // Clean Slate 800
val LightTextSecondary = Color(0xFF475569) // Slate 600
val LightTextTertiary = Color(0xFF94A3B8) // Slate 400

// Fallback tokens mapped to Light Skin so dark surfaces never appear
val DarkBackground = LightBackground
val DarkSurface = LightSurface
val DarkSurfaceVariant = LightSurfaceVariant
val DarkBorder = LightBorder
val DarkTextPrimary = LightTextPrimary
val DarkTextSecondary = LightTextSecondary
val DarkTextTertiary = LightTextTertiary

// Semantic Pillars Colors
val PillarSmallDanceColor = Color(0xFF0D9488) // Teal
val PillarWeightShareColor = Color(0xFFE11D48) // Rose
val PillarBoundariesColor = Color(0xFFD97706) // Amber
val PillarFallingColor = Color(0xFF4F46E5) // Indigo
val PillarJamCommunityColor = Color(0xFF7C3AED) // Purple
