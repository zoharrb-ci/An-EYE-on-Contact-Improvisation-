package com.example.ui.theme

/**
 * Multilingual translation engine supporting all 10 languages:
 * - HE (עברית - offered only when device locality is Israel)
 * - EN (English)
 * - IT (Italiano)
 * - DE (Deutsch)
 * - ES (Español)
 * - UK (Українська)
 * - PT (Português)
 * - RU (Русский)
 * - KO (한국어)
 * - JA (日本語)
 */
object MultilingualTranslations {

  data class LangPack(
    val it: String,
    val de: String,
    val es: String,
    val uk: String,
    val pt: String,
    val ru: String,
    val ko: String,
    val ja: String
  )

  private val byEnglishKey: Map<String, LangPack> = mapOf(
    // Navigation Tabs
    "Home" to LangPack("Home", "Start", "Inicio", "Головна", "Início", "Главная", "홈", "ホーム"),
    "Records" to LangPack("Diario", "Einträge", "Registros", "Записи", "Registos", "Записи", "기록", "記録"),
    "New Reflection" to LangPack(
      "Nuova Riflessione",
      "Neue Reflexion",
      "Nueva Reflexión",
      "Нова Рефлексія",
      "Nova Reflexão",
      "Новая Рефлексия",
      "새 성찰",
      "新しいリフレクション"
    ),
    "Inquiries" to LangPack("Indagini", "Impulse", "Indagaciones", "Бесіди", "Diálogos", "Беседы", "탐구", "対話"),
    "Progress" to LangPack("Progressi", "Fortschritt", "Progreso", "Прогрес", "Progresso", "Прогресс", "진행도", "進捗"),
    "Profile" to LangPack("Profilo", "Profil", "Perfil", "Профіль", "Perfil", "Профиль", "프로필", "プロフィール"),

    // 6 Somatic Axes - Titles
    "Somatic Attunement" to LangPack(
      "Sintonizzazione Somatica",
      "Somatische Einstimmung",
      "Sintonización Somática",
      "Соматичне Співналаштування",
      "Sintonização Somática",
      "Соматическая Сонастройка",
      "소마틱 동조 (경청)",
      "ソマティック・アチューンメント"
    ),
    "Weight Sharing" to LangPack(
      "Condivisione del Peso",
      "Gewichtsteilung",
      "Peso Compartido",
      "Розподіл Ваги",
      "Partilha de Peso",
      "Разделение Веса",
      "무게 공유 (웨이트 쉐어링)",
      "ウェイト・シェアリング"
    ),
    "Boundaries & Consent" to LangPack(
      "Confini e Consenso",
      "Grenzen & Konsens",
      "Límites y Consentimiento",
      "Межі та Згода",
      "Limites e Consentimento",
      "Границы и Согласие",
      "경계와 동의",
      "境界線と同意"
    ),
    "Falling & Momentum" to LangPack(
      "Caduta e Slancio",
      "Fallen & Schwung",
      "Caída e Impulso",
      "Падіння та Імпульс",
      "Queda e Impulso",
      "Падение и Импульс",
      "낙하와 모멘텀",
      "落下とモメンタム"
    ),
    "Grounding (Small Dance)" to LangPack(
      "Radicamento (Small Dance)",
      "Erdung (Small Dance)",
      "Enraizamiento (Small Dance)",
      "Заземлення (Малий Танець)",
      "Enraizamento (Small Dance)",
      "Заземление (Малый Танец)",
      "그라운딩 (스몰 댄스)",
      "グラウンディング (スモールダンス)"
    ),
    "Tactile Attention" to LangPack(
      "Attenzione Tattile",
      "Taktile Aufmerksamkeit",
      "Atención Táctil",
      "Тактильна Увага",
      "Atenção Tátil",
      "Тактильное Внимание",
      "촉각적 주의",
      "触覚的注意"
    ),

    // 6 Somatic Axes - Short Labels
    "Attunement" to LangPack("Ascolto", "Resonanz", "Escucha", "Слухання", "Escuta", "Слушание", "경청", "共鳴"),
    "Weight" to LangPack("Peso", "Gewicht", "Peso", "Вага", "Peso", "Вес", "무게", "重み"),
    "Boundaries" to LangPack("Confini", "Grenzen", "Límites", "Межі", "Limites", "Границы", "경계", "境界"),
    "Momentum" to LangPack("Slancio", "Schwung", "Impulso", "Імпульс", "Impulso", "Импульс", "모멘텀", "勢い"),
    "Grounding" to LangPack("Radicamento", "Erdung", "Tierra", "Опора", "Raiz", "Опора", "접지", "接地"),
    "Tactile" to LangPack("Tatto", "Taktil", "Tacto", "Дотик", "Tato", "Касание", "촉각", "触覚"),

    // 6 Somatic Axes - Subtitles
    "Sensitivity & real-time resonance with your partner's movement" to LangPack(
      "Sensibilità e risonanza in tempo reale con il movimento del partner",
      "Sensibilität & Echtzeit-Resonanz mit der Bewegung des Partners",
      "Sensibilidad y resonancia en tiempo real con el movimiento de tu pareja",
      "Чутливість і резонанс у реальному часі з рухом партнера",
      "Sensibilidade e ressonância em tempo real com o movimento do parceiro",
      "Чуткость и резонанс в реальном времени с движением партнёра",
      "파트너의 움직임에 대한 실시간 감각적 공명",
      "パートナーの動きとのリアルタイムな共鳴と感受性"
    ),
    "Mutual leaning, counter-balance & shared center of gravity" to LangPack(
      "Appoggio reciproco, controbilanciamento e baricentro condiviso",
      "Gegenseitiges Lehnen, Gegengewicht & gemeinsamer Schwerpunkt",
      "Apoyo mutuo, contrapeso y centro de gravedad compartido",
      "Взаємне спирання, противага та спільний центр тяжіння",
      "Apoio mútuo, contrapeso e centro de gravidade partilhado",
      "Взаимная опора, контрбаланс и общий центр тяжести",
      "상호 기대기, 카운터밸런스 및 공유된 무게중심",
      "相互の寄りかかり、カウンターバランス、共有された重心"
    ),
    "Clarity in signaling 'No' & full 'Yes' (Two Rivers practice)" to LangPack(
      "Chiarezza nel segnalare 'No' e pieno 'Sì' (pratica dei Due Fiumi)",
      "Klarheit beim Signalisieren von 'Nein' & vollem 'Ja' (Zwei-Flüsse-Praxis)",
      "Claridad al señalar 'No' y 'Sí' pleno (práctica de los Dos Ríos)",
      "Чіткість у позначенні 'Ні' та повного 'Так' (практика Двох Річок)",
      "Clareza ao sinalizar 'Não' e 'Sim' pleno (prática dos Dois Rios)",
      "Ясность в обозначении «Нет» и полного «Да» (практика Двух Рек)",
      "'아니오'와 온전한 '예'를 명확히 표현하기 (두 개의 강 실습)",
      "「No」と完全な「Yes」を明確に伝える（二つの川の実践）"
    ),
    "Riding gravity through spirals & softening floor contact" to LangPack(
      "Seguire la gravità attraverso spirali e ammorbidire il contatto col suolo",
      "Mit der Schwerkraft durch Spiralen gleiten & Bodenkontakt weich gestalten",
      "Fluir con la gravedad en espirales y suavizar el contacto con el suelo",
      "Рух за гравітацією через спіралі та м'який контакт із підлогою",
      "Fluir com a gravidade em espirais e suavizar o contato com o chão",
      "Следование гравитации через спирали и мягкий контакт с полом",
      "나선을 통해 중력을 타고 바닥과의 접촉을 부드럽게 하기",
      "スパイラルで重力に乗り、床との接触を柔らかくする"
    ),
    "Skeletal alignment & trusting gravity in quiet standing" to LangPack(
      "Allineamento scheletrico e fiducia nella gravità in piedi",
      "Skelettausrichtung & Vertrauen in die Schwerkraft im Stehen",
      "Alineación esquelética y confianza en la gravedad en pie",
      "Вирівнювання скелета та довіра гравітації у спокійному стоянні",
      "Alinhamento esquelético e confiança na gravidade em pé",
      "Выстраивание скелета и доверие гравитации в спокойном стоянии",
      "조용히 서 있는 상태에서 골격 정렬과 중력에 대한 신뢰",
      "静かな立ち姿での骨格のアライメントと重力への信頼"
    ),
    "360° multi-directional listening through skin & space" to LangPack(
      "Ascolto multidirezionale a 360° attraverso la pelle e lo spazio",
      "360° multidirektionales Lauschen über Haut und Raum",
      "Escucha multidireccional 360° a través de la piel y el espacio",
      "Багатовимірне слухання 360° через шкіру та простір",
      "Escuta multidirecional 360° através da pele e do espaço",
      "Многомерное слушание на 360° через кожу и пространство",
      "피부와 공간을 통한 360° 다방향 감각 경청",
      "皮膚と空間を通じた360°全方向のリスニング"
    ),

    // View Modes
    "Rich Cards" to LangPack("Schede Ricche", "Kartenansicht", "Tarjetas", "Картки", "Cartões", "Карточки", "카드 보기", "カード表示"),
    "Timeline" to LangPack("Cronologia", "Zeitachse", "Cronología", "Хронологія", "Cronologia", "Хронология", "타임라인", "タイムライン"),
    "By Pillar" to LangPack("Per Pilastro", "Nach Säulen", "Por Pilar", "За Осями", "Por Pilar", "По Осям", "주제별", "テーマ別"),
    "Compact List" to LangPack("Lista Compatta", "Kompaktliste", "Compacto", "Компактно", "Lista Compacta", "Компактно", "간략 목록", "コンパクト"),
    "Chat Thread" to LangPack("Dialogo Chat", "Chat-Dialog", "Diálogo Chat", "Діалог Чату", "Chat", "Диалог Чата", "채팅 대화", "チャット"),
    "Q&A Accordion" to LangPack("Domande & Risposte", "Fragen & Antworten", "Preguntas y Resp.", "Питання й Відповіді", "Perguntas e Resp.", "Вопросы и Ответы", "질문과 답변", "Q&A"),
    "Key Insights" to LangPack("Intuizioni Chiave", "Erkenntnisse", "Ideas Clave", "Ключові Інсайти", "Ideias-Chave", "Ключевые Инсайты", "핵심 통찰", " 핵심インサイト"),
    "Flashcards" to LangPack("Schede Studio", "Lernkarten", "Tarjetas Estudio", "Флеш-картки", "Cartões de Estudo", "Флеш-карточки", "플래시카드", "フラッシュカード"),

    // TopBar & Global Controls
    "Mobile View" to LangPack("Vista Mobile", "Mobilansicht", "Vista Móvil", "Мобільний", "Vista Móvel", "Мобильный", "모바일 화면", "モバイル表示"),
    "Desktop View" to LangPack("Vista Desktop", "Desktop-Ansicht", "Vista PC", "Десктоп", "Vista PC", "Вид ПК", "데스크톱 화면", "PC表示"),
    "Mobile" to LangPack("Mobile", "Mobil", "Móvil", "Мобільний", "Móvel", "Мобильный", "모바일", "モバイル"),
    "Desktop" to LangPack("Desktop", "Desktop", "Escritorio", "Комп'ютер", "Desktop", "Компьютер", "데스크톱", "デスクトップ"),
    "Full Screen" to LangPack("Schermo Intero", "Vollbild", "Pantalla Completa", "Повний Екран", "Ecrã Inteiro", "Полный Экран", "전체 화면", "全画面"),
    "Exit Full Screen" to LangPack(
      "Esci da Schermo Intero",
      "Vollbild beenden",
      "Salir de Pantalla Completa",
      "Вийти з Повного Екрана",
      "Sair do Ecrã Inteiro",
      "Выйти из Полного Экрана",
      "전체 화면 종료",
      "全画面を終了"
    ),
    "Desktop Widescreen • ci-eye" to LangPack(
      "Schermo Panoramico Desktop • ci-eye",
      "Desktop-Breitbild • ci-eye",
      "Pantalla Panorámica PC • ci-eye",
      "Широкий Екран ПК • ci-eye",
      "Ecrã Panorâmico PC • ci-eye",
      "Широкий Экран ПК • ci-eye",
      "데스크톱 와이드 화면 • ci-eye",
      "デスクトップ・ワイド画面 • ci-eye"
    ),
    "Moving Dialogue • ci-eye" to LangPack(
      "Il Dialogo in Movimento • ci-eye",
      "Bewegter Dialog • ci-eye",
      "El Diálogo en Movimiento • ci-eye",
      "Рухомий Діалог • ci-eye",
      "O Diálogo em Movimento • ci-eye",
      "Движущийся Диалог • ci-eye",
      "움직이는 대화 • ci-eye",
      "動く対話 • ci-eye"
    ),

    // Weight Transfer Intro Screen
    "Phase 1: Somatic Listening & Approaching Center" to LangPack(
      "Fase 1: Ascolto Somatico e Avvicinamento al Centro",
      "Phase 1: Somatisches Lauschen & Annäherung an die Mitte",
      "Fase 1: Escucha Somática y Acercamiento al Centro",
      "Фаза 1: Соматичне слухання та наближення до центру",
      "Fase 1: Escuta Somática e Aproximação ao Centro",
      "Фаза 1: Соматическое слушание и сближение с центром",
      "1단계: 소마틱 경청과 중심으로 다가서기",
      "フェーズ1：ソマティックな傾聴と中心への接近"
    ),
    "Phase 2: Rolling Point of Contact & Mutual Lean" to LangPack(
      "Fase 2: Punto di Contatto Mobile e Appoggio Reciproco",
      "Fase 2: Rollender Kontaktpunkt & Gegenseitiges Lehnen",
      "Fase 2: Punto de Contacto Rodante e Inclinación Mutua",
      "Фаза 2: Рухома точка контакту та взаємний нахил",
      "Fase 2: Ponto de Contato Rolante e Apoio Mútuo",
      "Фаза 2: Перетекающая точка контакта и взаимный наклон",
      "2단계: 구르는 접촉점과 상호 기대기",
      "フェーズ2：転がるコンタクトポイントと相互の寄りかかり"
    ),
    "Phase 3: Full Weight Sharing & Dynamic Counterbalance" to LangPack(
      "Fase 3: Condivisione Piena del Peso e Controbilanciamento",
      "Fase 3: Volle Gewichtsteilung & Dynamisches Gegengewicht",
      "Fase 3: Peso Compartido Pleno y Contrapeso Dinámico",
      "Фаза 3: Повний розподіл ваги та динамічна рівновага",
      "Fase 3: Partilha Plena de Peso e Contrapeso Dinâmico",
      "Фаза 3: Полная передача веса и динамический баланс",
      "3단계: 온전한 무게 공유와 역동적 균형",
      "フェーズ3：完全なウェイトシェアとダイナミックな均衡"
    ),
    "The Moving Dialogue: Exploring Touch, Momentum & Shared Weight" to LangPack(
      "Il Dialogo in Movimento: Esplorare Tocco, Slancio e Peso Condiviso",
      "Der Bewegte Dialog: Berührung, Schwung & Geteiltes Gewicht",
      "El Diálogo en Movimiento: Explorando Tacto, Impulso y Peso Compartido",
      "Рухомий Діалог: Дослідження дотику, імпульсу та спільної ваги",
      "O Diálogo em Movimento: Explorando Toque, Impulso e Peso Partilhado",
      "Движущийся Диалог: Исследование прикосновения, импульса и общего веса",
      "움직이는 대화: 접촉, 모멘텀, 그리고 공유된 무게의 탐구",
      "動く対話：触れ合い、モメンタム、共有された重みの探求"
    ),
    "A somatic reflection & self-inquiry suite for Contact Improvisation dancers. Track weight transfers, rolling points of contact, boundaries, and non-verbal attunement." to LangPack(
      "Una suite di riflessione somatica per danzatori di Contact Improvisation. Traccia trasferimenti di peso, punti di contatto, confini e ascolto non verbale.",
      "Eine somatische Reflexions-Suite für Contact-Improvisation-Tänzer. Verfolge Gewichtstransfers, Kontaktpunkte, Grenzen und nonverbale Einstimmung.",
      "Una suite de reflexión somática para bailarines de Contact Improvisation. Registra transferencias de peso, puntos de contacto, límites y escucha no verbal.",
      "Простір соматичної рефлексії для танцівників контактної імпровізації. Відстежуйте передачу ваги, точки контакту, межі та невербальне слухання.",
      "Uma suíte de reflexão somática para bailarinos de Contact Improvisation. Acompanhe transferências de peso, pontos de contato, limites e escuta não-verbal.",
      "Пространство соматической рефлексии для танцоров контактной импровизации. Отслеживайте передачу веса, точки контакта, границы и невербальное слушание.",
      "컨택트 임프로비제이션 댄서를 위한 소마틱 성찰 및 자기 탐구 앱입니다. 무게 이동, 접촉점, 경계, 비언어적 동조를 기록하세요.",
      "コンタクト・インプロヴィゼーション実践者のためのソマティック内省スイート。重心の移動、接触点、境界線、非言語の共鳴を記録します。"
    ),
    "Why Contact Ways? Somatic Rationale & Features" to LangPack(
      "Perché Contact Ways? Principi Somatici e Funzioni",
      "Warum Contact Ways? Somatische Grundlagen & Funktionen",
      "¿Por qué Contact Ways? Fundamentos Somáticos y Funciones",
      "Чому Contact Ways? Соматична основа та можливості",
      "Porquê Contact Ways? Fundamentos Somáticos e Recursos",
      "Почему Contact Ways? Соматический подход и возможности",
      "왜 Contact Ways인가요? 소마틱 배경과 기능 안내",
      "Contact Waysとは？ソマティックな背景と機能"
    ),
    "Animation complete — Tap anywhere to enter the app" to LangPack(
      "Animazione completata — Tocca lo schermo per entrare nell'app",
      "Animation beendet — Tippe auf den Bildschirm, um zu starten",
      "Animación completa — Toca la pantalla para entrar a la app",
      "Анімацію завершено — Торкніться екрана, щоб увійти",
      "Animação concluída — Toque no ecrã para entrar na aplicação",
      "Анимация завершена — Нажмите на экран, чтобы войти в приложение",
      "애니메이션 완료 — 화면을 탭하여 앱으로 들어가기",
      "アニメーション完了 — 画面をタップしてアプリへ"
    ),
    "Replay" to LangPack("Riproduci", "Wiederholen", "Repetir", "Повторити", "Repetir", "Повторить", "다시 재생", "リプレイ"),
    "Enter App (Mobile)" to LangPack(
      "Entra nell'App (Mobile)",
      "App öffnen (Mobil)",
      "Entrar a la App (Móvil)",
      "Увійти в додаток (Мобільний)",
      "Entrar na App (Móvel)",
      "Войти в приложение (Мобильный)",
      "앱 시작하기 (모바일)",
      "アプリに入る（モバイル）"
    ),
    "🖥️ Open in Desktop Widescreen Mode (Landscape 16:9 + Side Rail)" to LangPack(
      "🖥️ Apri in Modalità Desktop Panoramica (16:9 + Barra Laterale)",
      "🖥️ Im Desktop-Breitbildmodus öffnen (16:9 + Seitenleiste)",
      "🖥️ Abrir en Modo Escritorio Panorámico (16:9 + Barra Lateral)",
      "🖥️ Відкрити в режимі широкого екрана ПК (16:9 + Бічна панель)",
      "🖥️ Abrir em Modo Desktop Panorâmico (16:9 + Barra Lateral)",
      "🖥️ Открыть в широкоэкранном режиме ПК (16:9 + Боковая панель)",
      "🖥️ 데스크톱 와이드 화면 모드로 열기 (가로 16:9 + 사이드바)",
      "🖥️ デスクトップ・ワイド画面モードで開く（16:9 + サイドバー）"
    ),

    // Home Screen
    "Weight Flow" to LangPack("Flusso Peso", "Gewichtsfluss", "Flujo de Peso", "Рух Ваги", "Fluxo de Peso", "Поток Веса", "무게 흐름", "重みの流れ"),
    "Log a New 6-Axis Dance Reflection" to LangPack(
      "Registra una Nuova Riflessione sui 6 Assi",
      "Neue 6-Achsen-Tanzreflexion erfassen",
      "Registrar Nueva Reflexión de 6 Ejes",
      "Записати нову рефлексію за 6 осями",
      "Registar Nova Reflexão nos 6 Eixos",
      "Записать новую рефлексию по 6 осям",
      "6개 축으로 새로운 춤 성찰 기록하기",
      "6つの軸で新しいダンス・リフレクションを記録"
    ),
    "6 Movement Axes" to LangPack(
      "I 6 Assi del Movimento",
      "Die 6 Bewegungsachsen",
      "Los 6 Ejes del Movimiento",
      "6 Осей Руху",
      "Os 6 Eixos do Movimento",
      "6 Осей Движения",
      "6가지 움직임 축",
      "6つのムーブメント軸"
    ),
    "Full Progress ›" to LangPack(
      "Tutti i Progressi ›",
      "Gesamter Fortschritt ›",
      "Progreso Completo ›",
      "Весь Прогрес ›",
      "Progresso Completo ›",
      "Весь Прогресс ›",
      "전체 진행도 ›",
      "すべての進捗 ›"
    ),
    "Somatic Practice Recommendations" to LangPack(
      "Pratiche Somatiche Consigliate",
      "Somatische Praxisempfehlungen",
      "Recomendaciones de Práctica Somática",
      "Рекомендації для соматичної практики",
      "Recomendações de Prática Somática",
      "Рекомендации для соматической практики",
      "추천 소마틱 실습",
      "おすすめのソマティック実践"
    ),
    "Tap any card to open its somatic guide & practice" to LangPack(
      "Tocca una scheda per aprire la guida e la pratica somatica",
      "Tippe auf eine Karte, um Anleitung & Praxis zu öffnen",
      "Toca cualquier tarjeta para abrir su guía y práctica somática",
      "Торкніться картки, щоб відкрити опис і практику",
      "Toque num cartão para abrir o guia e a prática somática",
      "Нажмите на карточку, чтобы открыть описание и практику",
      "카드를 탭하여 소마틱 가이드와 실습을 열어보세요",
      "カードをタップしてガイドと実践を開く"
    ),
    "Recent Reflections" to LangPack(
      "Riflessioni Recenti",
      "Letzte Reflexionen",
      "Reflexiones Recientes",
      "Останні Записи",
      "Reflexões Recentes",
      "Последние Записи",
      "최근 성찰 기록",
      "最近の記録"
    ),

    // New Reflection Screen
    "New Dance Reflection across 6 Axes" to LangPack(
      "Nuova Riflessione di Danza sui 6 Assi",
      "Neue Tanzreflexion über 6 Achsen",
      "Nueva Reflexión de Danza en 6 Ejes",
      "Нова рефлексія танцю за 6 осями",
      "Nova Reflexão de Dança nos 6 Eixos",
      "Новая рефлексия танца по 6 осям",
      "6개 축을 통한 새로운 춤 성찰",
      "6つの軸による新しいダンス・リフレクション"
    ),
    "Rate each movement axis (1–10) and observe your somatic profile take shape in real time" to LangPack(
      "Valuta ogni asse del movimento (1–10) e osserva il tuo profilo somatico in tempo reale",
      "Bewerte jede Bewegungsachse (1–10) und beobachte dein somatisches Profil in Echtzeit",
      "Califica cada eje de movimiento (1–10) y observa tu perfil somático en tiempo real",
      "Оцініть кожну вісь руху (1–10) і спостерігайте за соматичним радаром наживо",
      "Avalie cada eixo de movimento (1–10) e observe o seu perfil somático em tempo real",
      "Оцените каждую ось движения (1–10) и наблюдайте за соматическим радаром в реальном времени",
      "각 움직임 축(1–10)을 평가하고 실시간으로 형성되는 소마틱 레이더를 확인하세요",
      "各ムーブメント軸（1〜10）を評価し、リアルタイムで変化するソマティック・レーダーを確認"
    ),
    "Full 6-Axes Guide" to LangPack(
      "Guida ai 6 Assi",
      "Leitfaden der 6 Achsen",
      "Guía de los 6 Ejes",
      "Гід по 6 осях",
      "Guia dos 6 Eixos",
      "Гид по 6 осям",
      "6개 축 전체 가이드",
      "6軸ガイド"
    ),
    "Reflection Saved to Your Movement Journal!" to LangPack(
      "Riflessione Salvata nel Diario del Movimento!",
      "Reflexion im Bewegungstagebuch gespeichert!",
      "¡Reflexión Guardada en tu Diario de Movimiento!",
      "Рефлексію збережено у щоденник руху!",
      "Reflexão Guardada no Diário de Movimento!",
      "Рефлексия сохранена в дневник движения!",
      "성찰이 움직임 저널에 저장되었습니다!",
      "リフレクションがムーブメント日記に保存されました！"
    ),
    "Save 6-Axis Reflection to Journal" to LangPack(
      "Salva Riflessione a 6 Assi nel Diario",
      "6-Achsen-Reflexion im Tagebuch speichern",
      "Guardar Reflexión de 6 Ejes en el Diario",
      "Зберегти рефлексію за 6 осями в щоденник",
      "Guardar Reflexão de 6 Eixos no Diário",
      "Сохранить рефлексию по 6 осям в дневник",
      "6개 축 성찰을 저널에 저장",
      "6軸リフレクションを日記に保存"
    ),
    "Save & View in Journal" to LangPack(
      "Salva e Apri nel Diario",
      "Speichern & im Tagebuch ansehen",
      "Guardar y Ver en el Diario",
      "Зберегти та переглянути в щоденнику",
      "Guardar e Ver no Diário",
      "Сохранить и открыть в дневнике",
      "저장 후 저널에서 보기",
      "保存して日記で表示"
    ),

    // Records Screen
    "Movement Journal" to LangPack(
      "Diario del Movimento",
      "Bewegungstagebuch",
      "Diario de Movimiento",
      "Щоденник Руху",
      "Diário de Movimento",
      "Дневник Движения",
      "움직임 저널",
      "ムーブメント日記"
    ),
    "Display Mode:" to LangPack(
      "Modalità di Visualizzazione:",
      "Anzeigemodus:",
      "Modo de Vista:",
      "Режим відображення:",
      "Modo de Exibição:",
      "Режим отображения:",
      "표시 모드:",
      "表示モード："
    ),
    "All" to LangPack("Tutti", "Alle", "Todos", "Усі", "Todos", "Все", "전체", "すべて"),

    // Progress Screen
    "Somatic Progress & Radar" to LangPack(
      "Progressi Somatici e Radar",
      "Somatischer Fortschritt & Radar",
      "Progreso Somático y Radar",
      "Соматичний Прогрес і Радар",
      "Progresso Somático e Radar",
      "Соматический Прогресс и Радар",
      "소마틱 진행도 및 레이더",
      "ソマティック進捗＆レーダー"
    ),
    "6-Axis Somatic Radar" to LangPack(
      "Radar Somatico a 6 Assi",
      "6-Achsen Somatisches Radar",
      "Radar Somático de 6 Ejes",
      "6-Осьовий Соматичний Радар",
      "Radar Somático de 6 Eixos",
      "6-Осевой Соматический Радар",
      "6축 소마틱 레이더",
      "6軸ソマティック・レーダー"
    ),
    "Tap the ⓘ button next to any axis below for its somatic explanation" to LangPack(
      "Tocca il pulsante ⓘ accanto a qualsiasi asse per la spiegazione somatica",
      "Tippe auf ⓘ neben einer Achse für die somatische Erklärung",
      "Toca el botón ⓘ junto a cualquier eje para ver su explicación somática",
      "Натисніть ⓘ біля будь-якої осі для соматичного пояснення",
      "Toque no botão ⓘ ao lado de qualquer eixo para ver a explicação somática",
      "Нажмите ⓘ рядом с любой осью для подробного соматического объяснения",
      "각 축 옆의 ⓘ 버튼을 눌러 소마틱 설명을 확인하세요",
      "各軸の横にある ⓘ ボタンをタップすると解説が表示されます"
    ),

    // Profile Screen
    "Edit profile" to LangPack(
      "Modifica profilo",
      "Profil bearbeiten",
      "Editar perfil",
      "Редагувати профіль",
      "Editar perfil",
      "Редактировать профиль",
      "프로필 편집",
      "プロフィール編集"
    ),
    "Default Display Preferences" to LangPack(
      "Preferenze di Visualizzazione Predefinite",
      "Standard-Anzeigeeinstellungen",
      "Preferencias de Vista Predeterminadas",
      "Налаштування режиму перегляду",
      "Preferências de Exibição Padrão",
      "Настройки режима отображения",
      "기본 표시 모드 설정",
      "デフォルト表示モード設定"
    ),
    "Personal Boundaries & 'Two Rivers'" to LangPack(
      "Confini Personali e 'Due Fiumi'",
      "Persönliche Grenzen & 'Zwei Flüsse'",
      "Límites Personales y 'Dos Ríos'",
      "Особисті межі та 'Дві Річки'",
      "Limites Pessoais e 'Dois Rios'",
      "Личные границы и «Две Реки»",
      "개인의 경계와 '두 개의 강'",
      "個人の境界線と「二つの川」"
    ),
    "Active Movement Intentions" to LangPack(
      "Intenzioni di Movimento Attive",
      "Aktive Bewegungsintentionen",
      "Intenciones de Movimiento Activas",
      "Активні наміри в практиці",
      "Intenções de Movimento Ativas",
      "Активные намерения в практике",
      "현재의 움직임 의도",
      "現在のムーブメント意図"
    )
  )

  fun translate(lang: AppLanguage, he: String, en: String): String {
    return when (lang) {
      AppLanguage.HE -> he
      AppLanguage.EN -> en
      else -> translateInternational(en, lang)
    }
  }

  private fun translateInternational(en: String, lang: AppLanguage): String {
    // 1. Direct lookup in dictionary
    byEnglishKey[en]?.let { pack ->
      return when (lang) {
        AppLanguage.IT -> pack.it
        AppLanguage.DE -> pack.de
        AppLanguage.ES -> pack.es
        AppLanguage.UK -> pack.uk
        AppLanguage.PT -> pack.pt
        AppLanguage.RU -> pack.ru
        AppLanguage.KO -> pack.ko
        AppLanguage.JA -> pack.ja
        else -> en
      }
    }

    // 2. Dynamic pattern translations (Welcome, Somatic Index, Zoom, All Records, etc.)
    if (en.startsWith("Welcome, ")) {
      val name = en.removePrefix("Welcome, ")
      return when (lang) {
        AppLanguage.IT -> "Benvenuto/a, $name"
        AppLanguage.DE -> "Willkommen, $name"
        AppLanguage.ES -> "Bienvenido/a, $name"
        AppLanguage.UK -> "Вітаємо, $name"
        AppLanguage.PT -> "Bem-vindo/a, $name"
        AppLanguage.RU -> "Добро пожаловать, $name"
        AppLanguage.KO -> "환영합니다, $name"
        AppLanguage.JA -> "ようこそ、$name"
        else -> en
      }
    }

    if (en.startsWith("Somatic Index: ")) {
      return en
        .replace("Somatic Index:", when (lang) {
          AppLanguage.IT -> "Indice Somatico:"
          AppLanguage.DE -> "Somatischer Index:"
          AppLanguage.ES -> "Índice Somático:"
          AppLanguage.UK -> "Соматичний індекс:"
          AppLanguage.PT -> "Índice Somático:"
          AppLanguage.RU -> "Соматический индекс:"
          AppLanguage.KO -> "소마틱 지수:"
          AppLanguage.JA -> "ソマティック指数:"
          else -> "Somatic Index:"
        })
        .replace("-week streak", when (lang) {
          AppLanguage.IT -> " settimane consecutive"
          AppLanguage.DE -> " Wochen in Folge"
          AppLanguage.ES -> " semanas seguidas"
          AppLanguage.UK -> " тижн. поспіль"
          AppLanguage.PT -> " semanas seguidas"
          AppLanguage.RU -> " нед. подряд"
          AppLanguage.KO -> "주 연속"
          AppLanguage.JA -> "週連続"
          else -> "-week streak"
        })
    }

    if (en.startsWith("Zoom ")) {
      val pct = en.removePrefix("Zoom ")
      return when (lang) {
        AppLanguage.UK -> "Масштаб $pct"
        AppLanguage.RU -> "Масштаб $pct"
        AppLanguage.KO -> "배율 $pct"
        AppLanguage.JA -> "ズーム $pct"
        else -> "Zoom $pct"
      }
    }

    if (en.startsWith("All Records (")) {
      val rest = en.removePrefix("All Records ")
      return when (lang) {
        AppLanguage.IT -> "Tutti i Registri $rest"
        AppLanguage.DE -> "Alle Einträge $rest"
        AppLanguage.ES -> "Todos los Registros $rest"
        AppLanguage.UK -> "Усі записи $rest"
        AppLanguage.PT -> "Todos os Registos $rest"
        AppLanguage.RU -> "Все записи $rest"
        AppLanguage.KO -> "전체 기록 $rest"
        AppLanguage.JA -> "すべての記録 $rest"
        else -> en
      }
    }

    if (en.startsWith("Select a Guided Inquiry Topic")) {
      val rest = en.removePrefix("Select a Guided Inquiry Topic")
      return when (lang) {
        AppLanguage.IT -> "Seleziona un Tema di Indagine Guidata$rest"
        AppLanguage.DE -> "Wähle ein geführtes Untersuchungsthema$rest"
        AppLanguage.ES -> "Selecciona un Tema de Indagación Guiada$rest"
        AppLanguage.UK -> "Оберіть тему керованого дослідження$rest"
        AppLanguage.PT -> "Selecione um Tópico de Investigação Guiada$rest"
        AppLanguage.RU -> "Выберите тему направленного исследования$rest"
        AppLanguage.KO -> "안내형 탐구 주제를 선택하세요$rest"
        AppLanguage.JA -> "ガイド付き対話トピックを選択$rest"
        else -> en
      }
    }

    if (en.endsWith(" replies")) {
      val count = en.removeSuffix(" replies")
      return when (lang) {
        AppLanguage.IT -> "$count risposte"
        AppLanguage.DE -> "$count Antworten"
        AppLanguage.ES -> "$count respuestas"
        AppLanguage.UK -> "$count відповідей"
        AppLanguage.PT -> "$count respostas"
        AppLanguage.RU -> "$count ответов"
        AppLanguage.KO -> "답글 ${count}개"
        AppLanguage.JA -> "${count}件の返信"
        else -> en
      }
    }

    // 3. Common somatic terminology replacement for longer descriptions & guides
    var result = en
    val replacements: List<Pair<String, String>> = when (lang) {
      AppLanguage.IT -> listOf(
        "Weight Sharing" to "Condivisione del Peso",
        "Somatic Attunement" to "Sintonizzazione Somatica",
        "Boundaries & Consent" to "Confini e Consenso",
        "Falling & Momentum" to "Caduta e Slancio",
        "Grounding" to "Radicamento",
        "Tactile Attention" to "Attenzione Tattile",
        "The Small Dance" to "La Piccola Danza (Small Dance)",
        "Two Rivers" to "Due Fiumi"
      )
      AppLanguage.DE -> listOf(
        "Weight Sharing" to "Gewichtsteilung",
        "Somatic Attunement" to "Somatische Einstimmung",
        "Boundaries & Consent" to "Grenzen & Konsens",
        "Falling & Momentum" to "Fallen & Schwung",
        "Grounding" to "Erdung",
        "Tactile Attention" to "Taktile Aufmerksamkeit",
        "The Small Dance" to "Der Kleine Tanz (Small Dance)",
        "Two Rivers" to "Zwei Flüsse"
      )
      AppLanguage.ES -> listOf(
        "Weight Sharing" to "Peso Compartido",
        "Somatic Attunement" to "Sintonización Somática",
        "Boundaries & Consent" to "Límites y Consentimiento",
        "Falling & Momentum" to "Caída e Impulso",
        "Grounding" to "Enraizamiento",
        "Tactile Attention" to "Atención Táctil",
        "The Small Dance" to "La Pequeña Danza (Small Dance)",
        "Two Rivers" to "Dos Ríos"
      )
      AppLanguage.UK -> listOf(
        "Weight Sharing" to "Розподіл ваги",
        "Somatic Attunement" to "Соматичне співналаштування",
        "Boundaries & Consent" to "Межі та згода",
        "Falling & Momentum" to "Падіння та імпульс",
        "Grounding" to "Заземлення",
        "Tactile Attention" to "Тактильна увага",
        "The Small Dance" to "Малий танець (Small Dance)",
        "Two Rivers" to "Дві річки"
      )
      AppLanguage.PT -> listOf(
        "Weight Sharing" to "Partilha de Peso",
        "Somatic Attunement" to "Sintonização Somática",
        "Boundaries & Consent" to "Limites e Consentimento",
        "Falling & Momentum" to "Queda e Impulso",
        "Grounding" to "Enraizamento",
        "Tactile Attention" to "Atenção Tátil",
        "The Small Dance" to "A Pequena Dança (Small Dance)",
        "Two Rivers" to "Dois Rios"
      )
      AppLanguage.RU -> listOf(
        "Weight Sharing" to "Разделение веса",
        "Somatic Attunement" to "Соматическая сонастройка",
        "Boundaries & Consent" to "Границы и согласие",
        "Falling & Momentum" to "Падение и импульс",
        "Grounding" to "Заземление",
        "Tactile Attention" to "Тактильное внимание",
        "The Small Dance" to "Малый танец (Small Dance)",
        "Two Rivers" to "Две реки"
      )
      AppLanguage.KO -> listOf(
        "Weight Sharing" to "무게 공유",
        "Somatic Attunement" to "소마틱 동조",
        "Boundaries & Consent" to "경계와 동의",
        "Falling & Momentum" to "낙하와 모멘텀",
        "Grounding" to "그라운딩",
        "Tactile Attention" to "촉각적 주의",
        "The Small Dance" to "스몰 댄스(Small Dance)",
        "Two Rivers" to "두 개의 강"
      )
      AppLanguage.JA -> listOf(
        "Weight Sharing" to "ウェイト・シェアリング",
        "Somatic Attunement" to "ソマティック・アチューンメント",
        "Boundaries & Consent" to "境界線と同意",
        "Falling & Momentum" to "落下とモメンタム",
        "Grounding" to "グラウンディング",
        "Tactile Attention" to "触覚的注意",
        "The Small Dance" to "スモールダンス (Small Dance)",
        "Two Rivers" to "二つの川"
      )
      else -> emptyList()
    }
    for ((src, dst) in replacements) {
      result = result.replace(src, dst)
    }
    return result
  }
}
