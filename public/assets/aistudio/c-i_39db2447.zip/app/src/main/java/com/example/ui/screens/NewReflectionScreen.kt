package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SomaticAxisType
import com.example.ui.components.InfoGuideButton
import com.example.ui.components.LogoBlue
import com.example.ui.components.LogoOrange
import com.example.ui.components.LogoSoftSky
import com.example.ui.components.LogoTeal
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.components.SomaticLogoIcon
import com.example.ui.components.getAxisAccentColor
import com.example.ui.components.getAxisGuideTopic
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr
import com.example.ui.viewmodel.ContactWaysViewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NewReflectionScreen(
  viewModel: ContactWaysViewModel,
  isDesktopMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  // 6 Somatic Radar Axes state (1..10)
  var attunementRating by remember { mutableFloatStateOf(8.5f) }
  var weightShareRating by remember { mutableFloatStateOf(8.0f) }
  var boundaryRating by remember { mutableFloatStateOf(9.0f) }
  var fallingMomentumRating by remember { mutableFloatStateOf(8.2f) }
  var groundingRating by remember { mutableFloatStateOf(8.8f) }
  var tactileAttentionRating by remember { mutableFloatStateOf(8.5f) }

  // Dance context fields
  var title by remember { mutableStateOf("") }
  var partner by remember { mutableStateOf("") }
  var jamName by remember { mutableStateOf("") }
  var durationMinutes by remember { mutableIntStateOf(75) }

  val allContactPoints = listOf(
    "אגן ומרכז" to "Pelvis & Center",
    "גב אל גב" to "Back to Back",
    "שכמות וכתפיים" to "Shoulder Blades",
    "צלעות" to "Ribcage",
    "משטח הרצפה" to "Floor Surface",
    "כפות רגליים" to "Soles of Feet",
    "מגע קל בידיים" to "Light Hand Contact",
    "ראש וצוואר" to "Head & Neck"
  )
  val selectedContactPoints = remember { mutableStateListOf("אגן ומרכז", "שכמות וכתפיים") }

  var twoRiversMode by remember { mutableStateOf("מגע בכל מקום (מבוסס אמון)") }
  val twoRiversOptions = listOf(
    "מגע בכל מקום (מבוסס אמון)" to "Trust-based Full Contact",
    "מגע עדין בלבד" to "Gentle Contact Only",
    "עצירה / סימון גבול" to "Pause / Boundary Signal"
  )

  var reflectionNotes by remember { mutableStateOf("") }
  var keyTakeaway by remember { mutableStateOf("") }

  // Determine dominant pillar automatically from highest rated axis
  val dominantPillar = remember(
    attunementRating,
    weightShareRating,
    boundaryRating,
    fallingMomentumRating,
    groundingRating,
    tactileAttentionRating
  ) {
    val pairs = listOf(
      "הקשבה סומטית" to attunementRating,
      "שיתוף משקל" to weightShareRating,
      "גבולות והסכמה" to boundaryRating,
      "נפילה ומומנטום" to fallingMomentumRating,
      "הריקוד הקטן" to groundingRating,
      "תשומת לב עורית" to tactileAttentionRating
    )
    pairs.maxByOrNull { it.second }?.first ?: "שיתוף משקל"
  }

  val onResetForm = {
    attunementRating = 8.5f
    weightShareRating = 8.0f
    boundaryRating = 9.0f
    fallingMomentumRating = 8.2f
    groundingRating = 8.8f
    tactileAttentionRating = 8.5f
    title = ""
    partner = ""
    jamName = ""
    reflectionNotes = ""
    keyTakeaway = ""
  }

  val onSaveForm = {
    viewModel.saveNewRecord(
      title = title,
      partner = partner,
      jamName = jamName,
      durationMinutes = durationMinutes,
      pillar = dominantPillar,
      contactPoints = selectedContactPoints.toList(),
      weightShare = weightShareRating,
      attunement = attunementRating,
      boundaryClarity = boundaryRating,
      fallingMomentum = fallingMomentumRating,
      grounding = groundingRating,
      tactileAttention = tactileAttentionRating,
      twoRiversState = twoRiversMode,
      reflectionNotes = reflectionNotes,
      keyTakeaway = keyTakeaway,
      navigateToRecordsOnSave = true
    )
  }

  if (isDesktopMode) {
    // TWO-COLUMN DESKTOP / WIDESCREEN LAYOUT
    Row(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp, vertical = 12.dp)
        .testTag("new_reflection_screen"),
      horizontalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      // First Pane (42%): Sticky Radar Preview + Session Context + Save Actions
      Column(
        modifier = Modifier
          .weight(0.42f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        RadarPreviewCard(
          attunement = attunementRating,
          weightShare = weightShareRating,
          boundaries = boundaryRating,
          falling = fallingMomentumRating,
          grounding = groundingRating,
          tactile = tactileAttentionRating,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        SessionDetailsAndTwoRiversCard(
          title = title,
          onTitleChange = { title = it },
          partner = partner,
          onPartnerChange = { partner = it },
          jamName = jamName,
          onJamNameChange = { jamName = it },
          durationMinutes = durationMinutes,
          onDurationChange = { durationMinutes = it },
          allContactPoints = allContactPoints,
          selectedContactPoints = selectedContactPoints,
          twoRiversMode = twoRiversMode,
          twoRiversOptions = twoRiversOptions,
          onTwoRiversChange = { twoRiversMode = it },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        SaveAndResetButtonsRow(
          onReset = onResetForm,
          onSave = onSaveForm
        )
        Spacer(modifier = Modifier.height(24.dp))
      }

      // Second Pane (58%): 6 Axis Sliders with Info Buttons + Reflection Notes
      Column(
        modifier = Modifier
          .weight(0.58f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        SixAxesSlidersCard(
          attunementRating = attunementRating,
          onAttunementChange = { attunementRating = it },
          weightShareRating = weightShareRating,
          onWeightShareChange = { weightShareRating = it },
          boundaryRating = boundaryRating,
          onBoundaryChange = { boundaryRating = it },
          fallingMomentumRating = fallingMomentumRating,
          onFallingMomentumChange = { fallingMomentumRating = it },
          groundingRating = groundingRating,
          onGroundingChange = { groundingRating = it },
          tactileAttentionRating = tactileAttentionRating,
          onTactileAttentionChange = { tactileAttentionRating = it },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        ReflectionNotesCard(
          reflectionNotes = reflectionNotes,
          onReflectionNotesChange = { reflectionNotes = it },
          keyTakeaway = keyTakeaway,
          onKeyTakeawayChange = { keyTakeaway = it },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  } else {
    // MOBILE SINGLE-COLUMN LAYOUT
    LazyColumn(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
        .testTag("new_reflection_screen"),
      contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        RadarPreviewCard(
          attunement = attunementRating,
          weightShare = weightShareRating,
          boundaries = boundaryRating,
          falling = fallingMomentumRating,
          grounding = groundingRating,
          tactile = tactileAttentionRating,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        SixAxesSlidersCard(
          attunementRating = attunementRating,
          onAttunementChange = { attunementRating = it },
          weightShareRating = weightShareRating,
          onWeightShareChange = { weightShareRating = it },
          boundaryRating = boundaryRating,
          onBoundaryChange = { boundaryRating = it },
          fallingMomentumRating = fallingMomentumRating,
          onFallingMomentumChange = { fallingMomentumRating = it },
          groundingRating = groundingRating,
          onGroundingChange = { groundingRating = it },
          tactileAttentionRating = tactileAttentionRating,
          onTactileAttentionChange = { tactileAttentionRating = it },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        ReflectionNotesCard(
          reflectionNotes = reflectionNotes,
          onReflectionNotesChange = { reflectionNotes = it },
          keyTakeaway = keyTakeaway,
          onKeyTakeawayChange = { keyTakeaway = it },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        SessionDetailsAndTwoRiversCard(
          title = title,
          onTitleChange = { title = it },
          partner = partner,
          onPartnerChange = { partner = it },
          jamName = jamName,
          onJamNameChange = { jamName = it },
          durationMinutes = durationMinutes,
          onDurationChange = { durationMinutes = it },
          allContactPoints = allContactPoints,
          selectedContactPoints = selectedContactPoints,
          twoRiversMode = twoRiversMode,
          twoRiversOptions = twoRiversOptions,
          onTwoRiversChange = { twoRiversMode = it },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        SaveAndResetButtonsRow(
          onReset = onResetForm,
          onSave = onSaveForm
        )
      }
    }
  }
}

@Composable
private fun RadarPreviewCard(
  attunement: Float,
  weightShare: Float,
  boundaries: Float,
  falling: Float,
  grounding: Float,
  tactile: Float,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = tr("מילוי רפלקציה לפי 6 הצירים", "6-Axis Somatic Dance Reflection"),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = tr(
              "הזז/י את הסליידרים או לחץ/י על ⓘ להסבר על כל פרמטר",
              "Adjust the sliders or tap ⓘ next to any axis for somatic guidance"
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        InfoGuideButton(
          topic = SomaticGuideTopic.PARAM_LIVE_RADAR,
          onOpenGuide = onOpenGuide,
          label = tr("איך מדרגים?", "How to rate?")
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      LiveReflectionRadarPreview(
        attunement = attunement,
        weightShare = weightShare,
        boundaries = boundaries,
        falling = falling,
        grounding = grounding,
        tactile = tactile
      )
    }
  }
}

@Composable
private fun SixAxesSlidersCard(
  attunementRating: Float,
  onAttunementChange: (Float) -> Unit,
  weightShareRating: Float,
  onWeightShareChange: (Float) -> Unit,
  boundaryRating: Float,
  onBoundaryChange: (Float) -> Unit,
  fallingMomentumRating: Float,
  onFallingMomentumChange: (Float) -> Unit,
  groundingRating: Float,
  onGroundingChange: (Float) -> Unit,
  tactileAttentionRating: Float,
  onTactileAttentionChange: (Float) -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = tr("דירוג ששת צירי המכ״ם הסומטי (1–10)", "Rate the 6 Somatic Radar Axes (1–10)"),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = tr("לחץ על ⓘ להדרכה", "Tap ⓘ for guide"),
          style = MaterialTheme.typography.labelSmall,
          color = SomaticPrimary,
          fontWeight = FontWeight.SemiBold
        )
      }

      AxisSliderRow(
        axisType = SomaticAxisType.ATTUNEMENT,
        value = attunementRating,
        onValueChange = onAttunementChange,
        onOpenGuide = onOpenGuide,
        testTag = "slider_attunement"
      )

      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

      AxisSliderRow(
        axisType = SomaticAxisType.WEIGHT_SHARING,
        value = weightShareRating,
        onValueChange = onWeightShareChange,
        onOpenGuide = onOpenGuide,
        testTag = "slider_weight_sharing"
      )

      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

      AxisSliderRow(
        axisType = SomaticAxisType.BOUNDARIES,
        value = boundaryRating,
        onValueChange = onBoundaryChange,
        onOpenGuide = onOpenGuide,
        testTag = "slider_boundaries"
      )

      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

      AxisSliderRow(
        axisType = SomaticAxisType.FALLING_MOMENTUM,
        value = fallingMomentumRating,
        onValueChange = onFallingMomentumChange,
        onOpenGuide = onOpenGuide,
        testTag = "slider_falling_momentum"
      )

      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

      AxisSliderRow(
        axisType = SomaticAxisType.GROUNDING,
        value = groundingRating,
        onValueChange = onGroundingChange,
        onOpenGuide = onOpenGuide,
        testTag = "slider_grounding"
      )

      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

      AxisSliderRow(
        axisType = SomaticAxisType.TACTILE_ATTENTION,
        value = tactileAttentionRating,
        onValueChange = onTactileAttentionChange,
        onOpenGuide = onOpenGuide,
        testTag = "slider_tactile_attention"
      )
    }
  }
}

@Composable
private fun ReflectionNotesCard(
  reflectionNotes: String,
  onReflectionNotesChange: (String) -> Unit,
  keyTakeaway: String,
  onKeyTakeawayChange: (String) -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = tr("הערת רפלקציה ותובנה כללית", "Reflection Notes & Key Takeaway"),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        InfoGuideButton(
          topic = SomaticGuideTopic.PARAM_REFLECTION_NOTES,
          onOpenGuide = onOpenGuide,
          label = tr("הסבר", "Guide")
        )
      }

      OutlinedTextField(
        value = reflectionNotes,
        onValueChange = onReflectionNotesChange,
        label = { Text(tr("רפלקציה טקסטואלית על הריקוד", "Written Reflection on the Dance")) },
        placeholder = {
          Text(
            tr(
              "איך הרגיש המפגש? מה קרה בנקודות העברת המשקל והגבולות?",
              "How did the encounter feel? What happened during weight transfers and boundaries?"
            )
          )
        },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("reflection_notes_input"),
        minLines = 3,
        shape = RoundedCornerShape(14.dp)
      )

      OutlinedTextField(
        value = keyTakeaway,
        onValueChange = onKeyTakeawayChange,
        label = { Text(tr("תובנה מרכזית לקחת הלאה", "Key Takeaway for Your Next Jam")) },
        placeholder = {
          Text(
            tr(
              "לדוגמה: כששחררתי את הכתפיים, שיתוף המשקל הפך קל וזורם...",
              "E.g., When I softened my shoulder blades, weight sharing became effortless..."
            )
          )
        },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("reflection_takeaway_input"),
        minLines = 2,
        shape = RoundedCornerShape(14.dp)
      )
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SessionDetailsAndTwoRiversCard(
  title: String,
  onTitleChange: (String) -> Unit,
  partner: String,
  onPartnerChange: (String) -> Unit,
  jamName: String,
  onJamNameChange: (String) -> Unit,
  durationMinutes: Int,
  onDurationChange: (Int) -> Unit,
  allContactPoints: List<Pair<String, String>>,
  selectedContactPoints: MutableList<String>,
  twoRiversMode: String,
  twoRiversOptions: List<Pair<String, String>>,
  onTwoRiversChange: (String) -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = tr("פרטי הריקוד ונקודות מגע", "Session Details & Contact Points"),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        InfoGuideButton(
          topic = SomaticGuideTopic.PARAM_CONTACT_POINTS,
          onOpenGuide = onOpenGuide,
          label = tr("הסבר", "Guide")
        )
      }

      OutlinedTextField(
        value = title,
        onValueChange = onTitleChange,
        label = { Text(tr("כותרת הרשומה (אופציונלי)", "Session Title (Optional)")) },
        placeholder = { Text(tr("לדוגמה: ג׳אם סופ״ש — מפגש גב ואגן", "E.g., Weekend Jam — Back & Pelvis Dialogue")) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("reflection_title_input"),
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = partner,
          onValueChange = onPartnerChange,
          label = { Text(tr("פרטנר/ית", "Partner")) },
          placeholder = { Text(tr("שם או סולו", "Name or Solo")) },
          modifier = Modifier.weight(1f),
          singleLine = true,
          shape = RoundedCornerShape(14.dp)
        )
        OutlinedTextField(
          value = jamName,
          onValueChange = onJamNameChange,
          label = { Text(tr("ג׳אם / סטודיו", "Jam / Studio")) },
          placeholder = { Text(tr("מיקום", "Location")) },
          modifier = Modifier.weight(1f),
          singleLine = true,
          shape = RoundedCornerShape(14.dp)
        )
      }

      // Duration
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = tr("משך הריקוד / הג׳אם:", "Dance / Jam Duration:"),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = tr("$durationMinutes דקות", "$durationMinutes min"),
            style = MaterialTheme.typography.labelLarge,
            color = SomaticPrimary,
            fontWeight = FontWeight.Bold
          )
        }
        Slider(
          value = durationMinutes.toFloat(),
          onValueChange = { onDurationChange(it.toInt()) },
          valueRange = 15f..180f,
          steps = 10,
          colors = SliderDefaults.colors(
            thumbColor = SomaticPrimary,
            activeTrackColor = SomaticPrimary
          )
        )
      }

      // Contact Points
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = tr("נקודות מגע מרכזיות בריקוד:", "Primary Body Contact Points:"),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold
          )
          InfoGuideButton(
            topic = SomaticGuideTopic.PARAM_CONTACT_POINTS,
            onOpenGuide = onOpenGuide
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          allContactPoints.forEach { (ptHe, ptEn) ->
            val isSelected = selectedContactPoints.contains(ptHe)
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) LogoBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
              border = if (isSelected) BorderStroke(1.dp, LogoBlue) else null,
              modifier = Modifier.clickable {
                if (isSelected) selectedContactPoints.remove(ptHe) else selectedContactPoints.add(ptHe)
              }
            ) {
              Text(
                text = tr(ptHe, ptEn),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) LogoBlue else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
        }
      }

      // Two Rivers Boundary State with Info Button
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = tr("מצב גבולות (תרגיל שני הנהרות):", "Boundary State (Two Rivers Exercise):"),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold
          )
          InfoGuideButton(
            topic = SomaticGuideTopic.PARAM_TWO_RIVERS,
            onOpenGuide = onOpenGuide,
            tint = GroundAmber
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          twoRiversOptions.forEach { (optHe, optEn) ->
            val isSelected = twoRiversMode == optHe
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) SomaticPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
              border = if (isSelected) BorderStroke(1.dp, SomaticPrimary) else null,
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onTwoRiversChange(optHe) }
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = tr(optHe, optEn),
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) SomaticPrimary else MaterialTheme.colorScheme.onSurface
                )
                if (isSelected) {
                  Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = SomaticPrimary,
                    modifier = Modifier.size(16.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SaveAndResetButtonsRow(
  onReset: () -> Unit,
  onSave: () -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    OutlinedButton(
      onClick = onReset,
      shape = RoundedCornerShape(14.dp),
      modifier = Modifier.weight(0.35f)
    ) {
      Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text(tr("איפוס", "Reset"))
    }

    Button(
      onClick = onSave,
      colors = ButtonDefaults.buttonColors(containerColor = LogoOrange),
      shape = RoundedCornerShape(14.dp),
      modifier = Modifier
        .weight(0.65f)
        .testTag("submit_reflection_button")
    ) {
      Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = tr("שמור רפלקציה ביומן", "Save Reflection to Journal"),
        fontWeight = FontWeight.Bold,
        color = Color.White
      )
    }
  }
}

@Composable
private fun AxisSliderRow(
  axisType: SomaticAxisType,
  value: Float,
  onValueChange: (Float) -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit,
  testTag: String
) {
  val lang = LocalAppLanguage.current
  val accentColor = getAxisAccentColor(axisType)
  val formattedScore = ((value * 10f).roundToInt() / 10f).toString()
  val guideTopic = getAxisGuideTopic(axisType)

  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        SomaticLogoIcon(
          axisType = axisType,
          size = 42.dp
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = axisType.title(lang),
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.width(6.dp))
            InfoGuideButton(
              topic = guideTopic,
              onOpenGuide = onOpenGuide,
              tint = accentColor
            )
          }
          Text(
            text = axisType.subtitle(lang),
            style = MaterialTheme.typography.bodySmall,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Surface(
        shape = RoundedCornerShape(10.dp),
        color = accentColor.copy(alpha = 0.14f)
      ) {
        Text(
          text = "$formattedScore / 10",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = accentColor,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
      }
    }

    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = 1f..10f,
      steps = 17,
      colors = SliderDefaults.colors(
        thumbColor = accentColor,
        activeTrackColor = accentColor,
        inactiveTrackColor = accentColor.copy(alpha = 0.2f)
      ),
      modifier = Modifier
        .fillMaxWidth()
        .testTag(testTag)
    )
  }
}

@Composable
private fun LiveReflectionRadarPreview(
  attunement: Float,
  weightShare: Float,
  boundaries: Float,
  falling: Float,
  grounding: Float,
  tactile: Float
) {
  val lang = LocalAppLanguage.current
  val axes = listOf(
    Triple(SomaticAxisType.ATTUNEMENT.shortLabel(lang), attunement, LogoBlue),
    Triple(SomaticAxisType.WEIGHT_SHARING.shortLabel(lang), weightShare, LogoOrange),
    Triple(SomaticAxisType.BOUNDARIES.shortLabel(lang), boundaries, GroundAmber),
    Triple(SomaticAxisType.FALLING_MOMENTUM.shortLabel(lang), falling, SomaticPrimary),
    Triple(SomaticAxisType.GROUNDING.shortLabel(lang), grounding, LogoTeal),
    Triple(SomaticAxisType.TACTILE_ATTENTION.shortLabel(lang), tactile, Color(0xFF7C3AED))
  )

  val avgScore = ((attunement + weightShare + boundaries + falling + grounding + tactile) / 6f * 10f).roundToInt()

  Surface(
    shape = RoundedCornerShape(18.dp),
    color = LogoSoftSky.copy(alpha = 0.55f),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = tr("תצוגת מכ״ם חיה לריקוד הנוכחי", "Live 6-Axis Radar Preview"),
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = LogoBlue
        )
        Surface(
          shape = RoundedCornerShape(50),
          color = LogoOrange.copy(alpha = 0.16f)
        ) {
          Text(
            text = tr("איזון כולל: $avgScore%", "Overall Balance: $avgScore%"),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = LogoOrange,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
      }

      Box(
        modifier = Modifier.size(195.dp),
        contentAlignment = Alignment.Center
      ) {
        Canvas(modifier = Modifier.size(175.dp)) {
          val cx = size.width / 2f
          val cy = size.height / 2f
          val radius = (size.minDimension / 2f) * 0.70f
          val count = axes.size
          val step = (2 * PI / count).toFloat()
          val gridColor = LogoBlue.copy(alpha = 0.25f)

          for (lvl in 1..3) {
            val r = radius * (lvl / 3f)
            val web = Path()
            for (i in 0 until count) {
              val a = -PI.toFloat() / 2f + i * step
              val x = cx + r * cos(a)
              val y = cy + r * sin(a)
              if (i == 0) web.moveTo(x, y) else web.lineTo(x, y)
            }
            web.close()
            drawPath(web, color = gridColor, style = Stroke(width = 1.dp.toPx()))
          }

          val dataPath = Path()
          val pts = mutableListOf<Offset>()
          for (i in 0 until count) {
            val a = -PI.toFloat() / 2f + i * step
            val gx = cx + radius * cos(a)
            val gy = cy + radius * sin(a)
            drawLine(gridColor, Offset(cx, cy), Offset(gx, gy), strokeWidth = 1.dp.toPx())

            val norm = (axes[i].second / 10f).coerceIn(0.1f, 1f)
            val px = cx + radius * norm * cos(a)
            val py = cy + radius * norm * sin(a)
            pts.add(Offset(px, py))
            if (i == 0) dataPath.moveTo(px, py) else dataPath.lineTo(px, py)
          }
          dataPath.close()

          drawPath(dataPath, color = LogoBlue.copy(alpha = 0.22f), style = Fill)
          drawPath(dataPath, color = LogoOrange, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round))

          pts.forEachIndexed { idx, pt ->
            drawCircle(color = axes[idx].third, radius = 4.5.dp.toPx(), center = pt)
            drawCircle(color = Color.White, radius = 1.8.dp.toPx(), center = pt)
          }

          val labelPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 9.5.sp.toPx()
            textAlign = android.graphics.Paint.Align.CENTER
            isAntiAlias = true
            isFakeBoldText = true
          }

          for (i in 0 until count) {
            val a = -PI.toFloat() / 2f + i * step
            val lr = radius * 1.25f
            val lx = cx + lr * cos(a)
            val ly = cy + lr * sin(a) + 3.dp.toPx()
            val scoreInt = ((axes[i].second * 10f).roundToInt() / 10f)
            drawContext.canvas.nativeCanvas.drawText("${axes[i].first} ($scoreInt)", lx, ly, labelPaint)
          }
        }
      }
    }
  }
}
