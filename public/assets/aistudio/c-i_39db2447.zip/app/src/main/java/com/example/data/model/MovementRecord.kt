package com.example.data.model

import com.example.ui.theme.AppLanguage

data class MovementRecord(
  val id: String,
  val title: String,
  val dateStr: String,
  val jamOrWorkshop: String,
  val partner: String,
  val durationMinutes: Int,
  val pillarCategory: String,
  val contactPoints: List<String>,
  val weightSharingLevel: Float, // 1.0 .. 10.0
  val attunementLevel: Float, // 1.0 .. 10.0
  val boundaryClarityLevel: Float, // 1.0 .. 10.0
  val fallingMomentumLevel: Float = 8.2f, // 1.0 .. 10.0
  val groundingLevel: Float = 8.8f, // 1.0 .. 10.0
  val tactileAttentionLevel: Float = 8.5f, // 1.0 .. 10.0
  val twoRiversState: String,
  val reflectionNotes: String,
  val keyTakeaway: String,
  val somaticSensations: List<String>,
  val timestampMs: Long = System.currentTimeMillis()
)

data class SomaticRecommendation(
  val id: String,
  val shortTitle: String,
  val subtitleTag: String,
  val axisType: SomaticAxisType,
  val summaryPreview: String,
  val fullExplanation: String,
  val practicalSteps: List<String>,
  val quoteText: String,
  val quoteAuthor: String,
  val hasInteractivePractice: Boolean = false,
  val shortTitleEn: String = shortTitle,
  val subtitleTagEn: String = subtitleTag,
  val fullExplanationEn: String = fullExplanation,
  val practicalStepsEn: List<String> = practicalSteps,
  val quoteTextEn: String = quoteText,
  val quoteAuthorEn: String = quoteAuthor
) {
  fun title(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, shortTitle, shortTitleEn)
  fun tag(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, subtitleTag, subtitleTagEn)
  fun subtitle(lang: AppLanguage): String = tag(lang)
  fun explanation(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, fullExplanation, fullExplanationEn)
  fun steps(lang: AppLanguage): List<String> =
    if (lang == AppLanguage.HE) practicalSteps else practicalStepsEn.map { com.example.ui.theme.trLang(lang, it, it) }
  fun quote(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, quoteText, quoteTextEn)
  fun author(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, quoteAuthor, quoteAuthorEn)
}

enum class SomaticAxisType(
  val titleHe: String,
  val shortLabelHe: String,
  val subtitleHe: String,
  val titleEn: String,
  val shortLabelEn: String,
  val subtitleEn: String
) {
  ATTUNEMENT(
    titleHe = "הקשבה סומטית",
    shortLabelHe = "הקשבה",
    subtitleHe = "רגישות והתכווננות לתנועת הפרטנר ולרגע ההווה",
    titleEn = "Somatic Attunement",
    shortLabelEn = "Attunement",
    subtitleEn = "Sensitivity & real-time resonance with your partner's movement"
  ),
  WEIGHT_SHARING(
    titleHe = "שיתוף משקל",
    shortLabelHe = "משקל",
    subtitleHe = "הישענות הדדית, אמון ומציאת מרכז כובד משותף",
    titleEn = "Weight Sharing",
    shortLabelEn = "Weight",
    subtitleEn = "Mutual leaning, counter-balance & shared center of gravity"
  ),
  BOUNDARIES(
    titleHe = "גבולות והסכמה",
    shortLabelHe = "גבולות",
    subtitleHe = "בהירות בסימון 'לא' ו-'כן' מלא (תרגיל שני הנהרות)",
    titleEn = "Boundaries & Consent",
    shortLabelEn = "Boundaries",
    subtitleEn = "Clarity in signaling 'No' & full 'Yes' (Two Rivers practice)"
  ),
  FALLING_MOMENTUM(
    titleHe = "נפילה ומומנטום",
    shortLabelHe = "מומנטום",
    subtitleHe = "שימוש בתנופת הירידה והארכת שטח פנים עם הרצפה",
    titleEn = "Falling & Momentum",
    shortLabelEn = "Momentum",
    subtitleEn = "Riding gravity through spirals & softening floor contact"
  ),
  GROUNDING(
    titleHe = "קרקוע (הריקוד הקטן)",
    shortLabelHe = "קרקוע",
    subtitleHe = "אמון בשלד ובכוח המשיכה מתוך עמידה קשובה",
    titleEn = "Grounding (Small Dance)",
    shortLabelEn = "Grounding",
    subtitleEn = "Skeletal alignment & trusting gravity in quiet standing"
  ),
  TACTILE_ATTENTION(
    titleHe = "תשומת לב עורית",
    shortLabelHe = "מגע ועור",
    subtitleHe = "הקשבה רב-חושית דרך העור והמרחב סביב (Attention is Tactile)",
    titleEn = "Tactile Attention",
    shortLabelEn = "Tactile",
    subtitleEn = "360° multi-directional listening through skin & space"
  );

  fun title(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, titleHe, titleEn)
  fun shortLabel(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, shortLabelHe, shortLabelEn)
  fun subtitle(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, subtitleHe, subtitleEn)
}
