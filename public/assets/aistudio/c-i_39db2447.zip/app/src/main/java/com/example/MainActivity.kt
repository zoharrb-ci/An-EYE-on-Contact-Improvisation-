package com.example

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ZoomOutMap
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.QuestionAnswer
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material.icons.outlined.ViewAgenda
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.ui.components.LogoBlue
import com.example.ui.components.LogoOrange
import com.example.ui.components.LogoTeal
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.components.SomaticInfoGuideDialog
import com.example.ui.components.WeightTransferIntroScreen
import com.example.ui.screens.ConversationsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NewReflectionScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.RecordsScreen
import com.example.ui.theme.AppLanguage
import com.example.ui.theme.ContactWaysTheme
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.ContactWaysViewModel
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
  private val viewModel: ContactWaysViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    viewModel.detectAndApplyDeviceLocality(this)
    enableEdgeToEdge()
    setContent {
      ContactWaysTheme {
        ContactWaysMainApp(viewModel = viewModel)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactWaysMainApp(viewModel: ContactWaysViewModel) {
  val appLanguage by viewModel.appLanguage.collectAsState()
  val availableLanguages by viewModel.availableLanguages.collectAsState()
  val isIsraelLocality by viewModel.isIsraelLocality.collectAsState()
  val deviceLocalityInfo by viewModel.deviceLocalityInfo.collectAsState()
  val showLanguageDialog by viewModel.showLanguageSelectorDialog.collectAsState()
  val currentTab by viewModel.currentTab.collectAsState()
  val showIntroAnimation by viewModel.showIntroAnimation.collectAsState()
  val desktopModeOverride by viewModel.isDesktopModeOverride.collectAsState()
  val desktopZoomScale by viewModel.desktopZoomScale.collectAsState()
  val isFullScreenMode by viewModel.isFullScreenMode.collectAsState()
  val activeGuideTopic by viewModel.activeGuideTopic.collectAsState()

  val view = LocalView.current

  // Automatically rotate the Android Emulator to Landscape Widescreen (16:9) when Desktop Mode is selected,
  // and return to Portrait when Mobile Mode is selected.
  LaunchedEffect(desktopModeOverride) {
    val activity = view.context as? Activity ?: return@LaunchedEffect
    when (desktopModeOverride) {
      true -> {
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
      }
      false -> {
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
      }
      null -> {
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
      }
    }
  }

  // Apply Immersive Full-Screen system bars toggle when isFullScreenMode changes
  LaunchedEffect(isFullScreenMode) {
    val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
    val insetsController = WindowCompat.getInsetsController(window, view)
    insetsController.systemBarsBehavior =
      WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    if (isFullScreenMode) {
      insetsController.hide(WindowInsetsCompat.Type.systemBars())
    } else {
      insetsController.show(WindowInsetsCompat.Type.systemBars())
    }
  }

  // Dynamically switch between Hebrew (RTL) and LTR languages (EN, IT, DE, ES, UK, PT)
  CompositionLocalProvider(
    LocalAppLanguage provides appLanguage,
    LocalLayoutDirection provides appLanguage.layoutDirection
  ) {
    if (showLanguageDialog) {
      com.example.ui.components.LanguageSelectorDialog(
        currentLanguage = appLanguage,
        availableLanguages = availableLanguages,
        isIsraelLocality = isIsraelLocality,
        deviceLocalityInfo = deviceLocalityInfo,
        onSelectLanguage = { viewModel.setLanguage(it) },
        onToggleIsraelLocality = { viewModel.setIsraelLocalityOverride(it) },
        onDismiss = { viewModel.setShowLanguageSelectorDialog(false) }
      )
    }

    if (showIntroAnimation) {
      BackHandler {
        viewModel.dismissIntroAnimation()
      }
      WeightTransferIntroScreen(
        onFinished = { viewModel.dismissIntroAnimation() },
        onEnterDesktopPreview = { viewModel.enterDesktopWidescreenPreview() },
        onToggleLanguage = { viewModel.toggleLanguage() },
        availableLanguages = availableLanguages,
        isIsraelLocality = isIsraelLocality,
        countryCode = deviceLocalityInfo.countryCode,
        onSelectLanguage = { viewModel.setLanguage(it) },
        onOpenLanguageDialog = { viewModel.setShowLanguageSelectorDialog(true) }
      )
      return@CompositionLocalProvider
    }

    // Handle hardware back button: exit Full-Screen first, or return to HOME if on other tabs
    BackHandler(enabled = isFullScreenMode || currentTab != AppNavTab.HOME) {
      if (isFullScreenMode) {
        viewModel.toggleFullScreenMode()
      } else {
        viewModel.selectTab(AppNavTab.HOME)
      }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val isWideScreen = maxWidth >= 600.dp
      val effectiveDesktopMode = desktopModeOverride ?: isWideScreen
      val baseDensity = LocalDensity.current

      // Apply Desktop Monitor Viewport Scaling when in Desktop Mode so columns & side rail have generous space
      val activeDensity = if (effectiveDesktopMode) {
        Density(
          density = baseDensity.density * desktopZoomScale,
          fontScale = baseDensity.fontScale * 0.95f
        )
      } else {
        baseDensity
      }

      CompositionLocalProvider(LocalDensity provides activeDensity) {
        Scaffold(
          topBar = {
            if (!isFullScreenMode) {
              CenterAlignedTopAppBar(
                navigationIcon = {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 8.dp)
                  ) {
                    // Prominent Desktop / Mobile Screen Preview Toggle Button
                    Surface(
                      shape = RoundedCornerShape(50),
                      color = if (effectiveDesktopMode) LogoBlue else LogoOrange.copy(alpha = 0.14f),
                      border = if (!effectiveDesktopMode) androidx.compose.foundation.BorderStroke(1.dp, LogoOrange) else null,
                      modifier = Modifier
                        .clickable { viewModel.toggleDesktopMode(effectiveDesktopMode) }
                        .testTag("toggle_desktop_mode_button")
                    ) {
                      Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Icon(
                          imageVector = if (effectiveDesktopMode) Icons.Default.PhoneAndroid else Icons.Default.DesktopWindows,
                          contentDescription = tr("מעבר בין תצוגת מחשב לנייד", "Switch between Desktop and Mobile view"),
                          tint = if (effectiveDesktopMode) Color.White else LogoOrange,
                          modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                          text = if (effectiveDesktopMode) {
                            tr("חזור לנייד", "Mobile View")
                          } else {
                            tr("תצוגת מחשב", "Desktop View")
                          },
                          style = MaterialTheme.typography.labelSmall,
                          fontWeight = FontWeight.Bold,
                          color = if (effectiveDesktopMode) Color.White else LogoOrange,
                          fontSize = 11.sp
                        )
                      }
                    }

                    if (effectiveDesktopMode) {
                      Spacer(modifier = Modifier.width(6.dp))
                      // Desktop Scale / Zoom Control Pill (74% / 85% / 100%)
                      Surface(
                        shape = RoundedCornerShape(50),
                        color = LogoTeal.copy(alpha = 0.14f),
                        modifier = Modifier
                          .clickable { viewModel.cycleDesktopZoomScale() }
                          .testTag("desktop_zoom_scale_button")
                      ) {
                        Row(
                          modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                          verticalAlignment = Alignment.CenterVertically
                        ) {
                          Icon(
                            imageVector = Icons.Default.ZoomOutMap,
                            contentDescription = tr("קנה מידה שולחני", "Desktop Scale"),
                            tint = SomaticPrimary,
                            modifier = Modifier.size(14.dp)
                          )
                          Spacer(modifier = Modifier.width(4.dp))
                          Text(
                            text = tr("זום ${(desktopZoomScale * 100).roundToInt()}%", "Zoom ${(desktopZoomScale * 100).roundToInt()}%"),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SomaticPrimary,
                            fontSize = 10.sp
                          )
                        }
                      }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Full-Screen Toggle Button
                    IconButton(
                      onClick = { viewModel.toggleFullScreenMode() },
                      modifier = Modifier
                        .size(34.dp)
                        .testTag("toggle_fullscreen_button")
                    ) {
                      Icon(
                        imageVector = Icons.Default.Fullscreen,
                        contentDescription = tr("מסך מלא", "Full Screen"),
                        tint = SomaticPrimary,
                        modifier = Modifier.size(22.dp)
                      )
                    }
                  }
                },
                title = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                      painter = painterResource(id = R.drawable.ci_logo_frameless),
                      contentDescription = "C-i Logo",
                      modifier = Modifier
                        .size(38.dp)
                        .testTag("app_header_logo")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                      Text(
                        text = "Contact Ways",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                      )
                      Text(
                        text = if (effectiveDesktopMode) {
                          tr("תצוגת מסך מחשב רחבה • ci-eye", "Desktop Widescreen • ci-eye")
                        } else {
                          tr("הדיאלוג הנע • ci-eye", "Moving Dialogue • ci-eye")
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = SomaticPrimary,
                        fontSize = 10.sp
                      )
                    }
                  }
                },
                actions = {
                  // Multilingual & Locality Selector Pill (HE in Israel only + EN, IT, DE, ES, UK, PT)
                  Surface(
                    shape = RoundedCornerShape(50),
                    color = SomaticPrimary.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SomaticPrimary.copy(alpha = 0.35f)),
                    modifier = Modifier
                      .clickable { viewModel.setShowLanguageSelectorDialog(true) }
                      .testTag("topbar_language_toggle_button")
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = tr("בחירת שפה", "Select Language"),
                        tint = SomaticPrimary,
                        modifier = Modifier.size(14.dp)
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = "${appLanguage.flagEmoji} ${appLanguage.toggleBadge}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = SomaticPrimary,
                        fontSize = 11.sp
                      )
                    }
                  }

                  // Global Info & Guidance Button
                  IconButton(
                    onClick = {
                      val defaultTopicForTab = when (currentTab) {
                        AppNavTab.HOME -> SomaticGuideTopic.GUIDE_HOME_DASHBOARD
                        AppNavTab.RECORDS -> SomaticGuideTopic.GUIDE_RECORDS_MODES
                        AppNavTab.REFLECTION -> SomaticGuideTopic.AXIS_ATTUNEMENT
                        AppNavTab.INQUIRIES -> SomaticGuideTopic.GUIDE_INQUIRIES_MODES
                        AppNavTab.PROGRESS -> SomaticGuideTopic.GUIDE_PROGRESS_RADAR
                        AppNavTab.PROFILE -> SomaticGuideTopic.GUIDE_PROFILE_INTENTIONS
                      }
                      viewModel.openGuideTopic(defaultTopicForTab)
                    },
                    modifier = Modifier.testTag("topbar_guide_button")
                  ) {
                    Icon(
                      imageVector = Icons.Default.HelpOutline,
                      contentDescription = tr("מדריך והסבר למסך", "Screen Guide & Info"),
                      tint = LogoOrange
                    )
                  }

                  IconButton(
                    onClick = { viewModel.selectTab(AppNavTab.PROFILE) },
                    modifier = Modifier.testTag("topbar_profile_button")
                  ) {
                    Icon(
                      imageVector = if (currentTab == AppNavTab.PROFILE) Icons.Filled.AccountCircle else Icons.Outlined.AccountCircle,
                      contentDescription = AppNavTab.PROFILE.title(appLanguage),
                      tint = if (currentTab == AppNavTab.PROFILE) SomaticPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                  containerColor = MaterialTheme.colorScheme.surface
                )
              )
            }
          },
          bottomBar = {
            // Only show Bottom NavigationBar when NOT in Desktop Mode
            if (!effectiveDesktopMode) {
              NavigationBar(
                modifier = Modifier
                  .fillMaxWidth()
                  .windowInsetsPadding(WindowInsets.navigationBars)
                  .testTag("bottom_nav_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
              ) {
                val navItems = listOf(
                  Triple(AppNavTab.HOME, Icons.Filled.Home, Icons.Outlined.Home),
                  Triple(AppNavTab.RECORDS, Icons.Filled.ViewAgenda, Icons.Outlined.ViewAgenda),
                  Triple(AppNavTab.REFLECTION, Icons.Filled.EditNote, Icons.Outlined.EditNote),
                  Triple(AppNavTab.INQUIRIES, Icons.Filled.QuestionAnswer, Icons.Outlined.QuestionAnswer),
                  Triple(AppNavTab.PROGRESS, Icons.Filled.ShowChart, Icons.Outlined.ShowChart)
                )

                navItems.forEach { (tab, filledIcon, outlinedIcon) ->
                  val isSelected = currentTab == tab
                  val isProminentReflection = tab == AppNavTab.REFLECTION
                  val tabLabel = tab.title(appLanguage)

                  if (isProminentReflection) {
                    NavigationBarItem(
                      selected = isSelected,
                      onClick = { viewModel.selectTab(tab) },
                      icon = {
                        Box(
                          modifier = Modifier
                            .size(44.dp)
                            .shadow(if (isSelected) 6.dp else 3.dp, RoundedCornerShape(14.dp))
                            .background(
                              brush = Brush.linearGradient(
                                colors = if (isSelected) {
                                  listOf(LogoOrange, Color(0xFFE11D48))
                                } else {
                                  listOf(LogoOrange, LogoTeal)
                                }
                              ),
                              shape = RoundedCornerShape(14.dp)
                            )
                            .border(
                              width = if (isSelected) 2.dp else 1.dp,
                              color = Color.White.copy(alpha = 0.85f),
                              shape = RoundedCornerShape(14.dp)
                            ),
                          contentAlignment = Alignment.Center
                        ) {
                          Icon(
                            imageVector = Icons.Filled.AddCircle,
                            contentDescription = tabLabel,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                          )
                        }
                      },
                      label = {
                        Text(
                          text = tabLabel,
                          style = MaterialTheme.typography.labelSmall,
                          fontSize = 11.sp,
                          fontWeight = FontWeight.ExtraBold,
                          color = if (isSelected) LogoOrange else MaterialTheme.colorScheme.onSurface
                        )
                      },
                      colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = LogoOrange,
                        unselectedIconColor = Color.White,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurface,
                        indicatorColor = Color.Transparent
                      ),
                      modifier = Modifier.testTag("nav_${tab.route}")
                    )
                  } else {
                    NavigationBarItem(
                      selected = isSelected,
                      onClick = { viewModel.selectTab(tab) },
                      icon = {
                        Icon(
                          imageVector = if (isSelected) filledIcon else outlinedIcon,
                          contentDescription = tabLabel,
                          modifier = Modifier.size(22.dp)
                        )
                      },
                      label = {
                        Text(
                          text = tabLabel,
                          style = MaterialTheme.typography.labelSmall,
                          fontSize = 10.sp,
                          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                      },
                      colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SomaticPrimary,
                        selectedTextColor = SomaticPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        indicatorColor = SomaticPrimary.copy(alpha = 0.12f)
                      ),
                      modifier = Modifier.testTag("nav_${tab.route}")
                    )
                  }
                }
              }
            }
          },
          modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
          ) {
            if (effectiveDesktopMode) {
              // DESKTOP / WIDESCREEN WORKSPACE WITH SIDE NAVIGATION RAIL
              Row(modifier = Modifier.fillMaxSize()) {
                DesktopSideNavigationRail(
                  currentTab = currentTab,
                  appLanguage = appLanguage,
                  isFullScreenMode = isFullScreenMode,
                  desktopZoomScale = desktopZoomScale,
                  onSelectTab = { viewModel.selectTab(it) },
                  onToggleLanguage = { viewModel.setShowLanguageSelectorDialog(true) },
                  onToggleFullScreen = { viewModel.toggleFullScreenMode() },
                  onCycleZoom = { viewModel.cycleDesktopZoomScale() },
                  onToggleMobileMode = { viewModel.toggleDesktopMode(true) },
                  onOpenGuide = { viewModel.openGuideTopic(SomaticGuideTopic.GUIDE_APP_OVERVIEW) }
                )

                VerticalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f))

                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                ) {
                  when (currentTab) {
                    AppNavTab.HOME -> HomeScreen(viewModel = viewModel, isDesktopMode = true)
                    AppNavTab.RECORDS -> RecordsScreen(viewModel = viewModel, isDesktopMode = true)
                    AppNavTab.REFLECTION -> NewReflectionScreen(viewModel = viewModel, isDesktopMode = true)
                    AppNavTab.INQUIRIES -> ConversationsScreen(viewModel = viewModel, isDesktopMode = true)
                    AppNavTab.PROGRESS -> ProgressScreen(viewModel = viewModel, isDesktopMode = true)
                    AppNavTab.PROFILE -> ProfileScreen(viewModel = viewModel, isDesktopMode = true)
                  }
                }
              }
            } else {
              // MOBILE SINGLE-COLUMN WORKSPACE
              when (currentTab) {
                AppNavTab.HOME -> HomeScreen(viewModel = viewModel, isDesktopMode = false)
                AppNavTab.RECORDS -> RecordsScreen(viewModel = viewModel, isDesktopMode = false)
                AppNavTab.REFLECTION -> NewReflectionScreen(viewModel = viewModel, isDesktopMode = false)
                AppNavTab.INQUIRIES -> ConversationsScreen(viewModel = viewModel, isDesktopMode = false)
                AppNavTab.PROGRESS -> ProgressScreen(viewModel = viewModel, isDesktopMode = false)
                AppNavTab.PROFILE -> ProfileScreen(viewModel = viewModel, isDesktopMode = false)
              }
            }

            // Floating Full-Screen Control Pill when TopAppBar is hidden in Full-Screen Mode
            if (isFullScreenMode) {
              Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                shadowElevation = 6.dp,
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .windowInsetsPadding(WindowInsets.statusBars)
                  .padding(12.dp)
                  .border(1.dp, SomaticPrimary.copy(alpha = 0.3f), RoundedCornerShape(50))
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Surface(
                    shape = RoundedCornerShape(50),
                    color = SomaticPrimary.copy(alpha = 0.14f),
                    modifier = Modifier.clickable { viewModel.setShowLanguageSelectorDialog(true) }
                  ) {
                    Text(
                      text = "${appLanguage.flagEmoji} ${appLanguage.toggleBadge}",
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.ExtraBold,
                      color = SomaticPrimary,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }

                  Surface(
                    shape = RoundedCornerShape(50),
                    color = LogoBlue.copy(alpha = 0.14f),
                    modifier = Modifier.clickable { viewModel.toggleDesktopMode(effectiveDesktopMode) }
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Icon(
                        imageVector = if (effectiveDesktopMode) Icons.Default.PhoneAndroid else Icons.Default.DesktopWindows,
                        contentDescription = null,
                        tint = LogoBlue,
                        modifier = Modifier.size(14.dp)
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = if (effectiveDesktopMode) {
                          tr("חזור לנייד", "Mobile")
                        } else {
                          tr("תצוגת מחשב", "Desktop")
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = LogoBlue
                      )
                    }
                  }

                  Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = tr("מדריך", "Guide"),
                    tint = LogoOrange,
                    modifier = Modifier
                      .size(20.dp)
                      .clickable { viewModel.openGuideTopic(SomaticGuideTopic.GUIDE_APP_OVERVIEW) }
                  )

                  Surface(
                    shape = RoundedCornerShape(50),
                    color = LogoOrange,
                    modifier = Modifier
                      .clickable { viewModel.toggleFullScreenMode() }
                      .testTag("exit_fullscreen_pill")
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Icon(
                        imageVector = Icons.Default.FullscreenExit,
                        contentDescription = tr("יציאה ממסך מלא", "Exit Full Screen"),
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = tr("צא ממסך מלא", "Exit Full Screen"),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                      )
                    }
                  }
                }
              }
            }
          }
        }

        // Global Contextual Somatic Info & Guidance Dialog
        activeGuideTopic?.let { topic ->
          SomaticInfoGuideDialog(
            topic = topic,
            onSelectTopic = { viewModel.openGuideTopic(it) },
            onDismiss = { viewModel.closeGuideTopic() }
          )
        }
      }
    }
  }
}

@Composable
private fun DesktopSideNavigationRail(
  currentTab: AppNavTab,
  appLanguage: AppLanguage,
  isFullScreenMode: Boolean,
  desktopZoomScale: Float,
  onSelectTab: (AppNavTab) -> Unit,
  onToggleLanguage: () -> Unit,
  onToggleFullScreen: () -> Unit,
  onCycleZoom: () -> Unit,
  onToggleMobileMode: () -> Unit,
  onOpenGuide: () -> Unit
) {
  NavigationRail(
    containerColor = MaterialTheme.colorScheme.surface,
    modifier = Modifier
      .fillMaxHeight()
      .width(96.dp)
      .testTag("desktop_nav_rail"),
    header = {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
      ) {
        if (isFullScreenMode) {
          Image(
            painter = painterResource(id = R.drawable.ci_logo_frameless),
            contentDescription = "C-i Logo",
            modifier = Modifier.size(34.dp)
          )
          Spacer(modifier = Modifier.height(6.dp))
        }

        // Prominent New Reflection CTA in the Side Rail
        val isReflectionSelected = currentTab == AppNavTab.REFLECTION
        val reflectionTitle = AppNavTab.REFLECTION.title(appLanguage)
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier
            .clickable { onSelectTab(AppNavTab.REFLECTION) }
            .padding(vertical = 4.dp)
            .testTag("nav_reflection")
        ) {
          Box(
            modifier = Modifier
              .size(48.dp)
              .shadow(if (isReflectionSelected) 6.dp else 3.dp, RoundedCornerShape(16.dp))
              .background(
                brush = Brush.linearGradient(
                  colors = if (isReflectionSelected) {
                    listOf(LogoOrange, Color(0xFFE11D48))
                  } else {
                    listOf(LogoOrange, LogoTeal)
                  }
                ),
                shape = RoundedCornerShape(16.dp)
              )
              .border(
                width = if (isReflectionSelected) 2.dp else 1.dp,
                color = Color.White,
                shape = RoundedCornerShape(16.dp)
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Filled.AddCircle,
              contentDescription = reflectionTitle,
              tint = Color.White,
              modifier = Modifier.size(26.dp)
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = reflectionTitle,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isReflectionSelected) LogoOrange else MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }
  ) {
    Column(
      modifier = Modifier
        .fillMaxHeight()
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      val railTabs = listOf(
        Triple(AppNavTab.HOME, Icons.Filled.Home, Icons.Outlined.Home),
        Triple(AppNavTab.RECORDS, Icons.Filled.ViewAgenda, Icons.Outlined.ViewAgenda),
        Triple(AppNavTab.INQUIRIES, Icons.Filled.QuestionAnswer, Icons.Outlined.QuestionAnswer),
        Triple(AppNavTab.PROGRESS, Icons.Filled.ShowChart, Icons.Outlined.ShowChart),
        Triple(AppNavTab.PROFILE, Icons.Filled.AccountCircle, Icons.Outlined.AccountCircle)
      )

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        railTabs.forEach { (tab, filledIcon, outlinedIcon) ->
          val isSelected = currentTab == tab
          val label = tab.title(appLanguage)
          NavigationRailItem(
            selected = isSelected,
            onClick = { onSelectTab(tab) },
            icon = {
              Icon(
                imageVector = if (isSelected) filledIcon else outlinedIcon,
                contentDescription = label,
                modifier = Modifier.size(22.dp)
              )
            },
            label = {
              Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationRailItemDefaults.colors(
              selectedIconColor = SomaticPrimary,
              selectedTextColor = SomaticPrimary,
              unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
              unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
              indicatorColor = SomaticPrimary.copy(alpha = 0.14f)
            ),
            modifier = Modifier.testTag("nav_${tab.route}")
          )
        }
      }

      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        HorizontalDivider(
          modifier = Modifier.width(56.dp),
          color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )

        // Language Selector in Side Rail
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = SomaticPrimary.copy(alpha = 0.14f),
          modifier = Modifier
            .clickable { onToggleLanguage() }
            .testTag("rail_language_toggle_button")
        ) {
          Text(
            text = "${appLanguage.flagEmoji} ${appLanguage.toggleBadge} ▾",
            style = MaterialTheme.typography.labelSmall,
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            color = SomaticPrimary,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = LogoTeal.copy(alpha = 0.14f),
          modifier = Modifier.clickable { onCycleZoom() }
        ) {
          Text(
            text = tr("זום ${(desktopZoomScale * 100).roundToInt()}%", "Zoom ${(desktopZoomScale * 100).roundToInt()}%"),
            style = MaterialTheme.typography.labelSmall,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = SomaticPrimary,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }

        IconButton(onClick = onOpenGuide) {
          Icon(
            imageVector = Icons.Default.HelpOutline,
            contentDescription = tr("מדריך האפליקציה", "App Guide"),
            tint = LogoOrange
          )
        }

        IconButton(onClick = onToggleFullScreen) {
          Icon(
            imageVector = if (isFullScreenMode) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
            contentDescription = tr("מסך מלא", "Full Screen"),
            tint = SomaticPrimary
          )
        }

        IconButton(onClick = onToggleMobileMode) {
          Icon(
            imageVector = Icons.Default.PhoneAndroid,
            contentDescription = tr("מעבר למצב נייד", "Switch to Mobile Mode"),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
