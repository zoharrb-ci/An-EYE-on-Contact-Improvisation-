package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SomaticAxisType
import com.example.data.model.SomaticProgress
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

data class RadarAxis(
  val label: String,
  val value: Float, // 0..100
  val color: Color,
  val axisType: SomaticAxisType
)

@Composable
fun SomaticRadarChart(
  progress: SomaticProgress,
  onOpenGuide: ((SomaticGuideTopic) -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  val lang = LocalAppLanguage.current
  val animProgress = remember { Animatable(0f) }

  LaunchedEffect(progress) {
    animProgress.snapTo(0f)
    animProgress.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing)
    )
  }

  val axes = remember(progress, lang) {
    listOf(
      RadarAxis(SomaticAxisType.ATTUNEMENT.title(lang), progress.attunementScore, SomaticPrimary, SomaticAxisType.ATTUNEMENT),
      RadarAxis(SomaticAxisType.WEIGHT_SHARING.title(lang), progress.weightShareScore, Color(0xFFE11D48), SomaticAxisType.WEIGHT_SHARING),
      RadarAxis(SomaticAxisType.BOUNDARIES.title(lang), progress.boundaryScore, GroundAmber, SomaticAxisType.BOUNDARIES),
      RadarAxis(SomaticAxisType.FALLING_MOMENTUM.title(lang), progress.fallingMomentumScore, Color(0xFF6366F1), SomaticAxisType.FALLING_MOMENTUM),
      RadarAxis(SomaticAxisType.GROUNDING.title(lang), progress.groundingScore, Color(0xFF059669), SomaticAxisType.GROUNDING),
      RadarAxis(SomaticAxisType.TACTILE_ATTENTION.title(lang), progress.nonVerbalScore, Color(0xFF7C3AED), SomaticAxisType.TACTILE_ATTENTION)
    )
  }

  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 2.dp,
    modifier = modifier
      .fillMaxWidth()
      .testTag("somatic_radar_chart")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = tr("מפת מיומנויות סומטיות — 6 עמודי תווך", "Somatic Skills Radar — 6 Core Pillars"),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = tr("מדד כולל: ${progress.overallIndex.toInt()}%", "Overall Index: ${progress.overallIndex.toInt()}%"),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
          )
        }
        if (onOpenGuide != null) {
          InfoGuideButton(
            topic = SomaticGuideTopic.GUIDE_PROGRESS_RADAR,
            onOpenGuide = onOpenGuide,
            label = tr("הסבר המכ״ם", "Radar Guide")
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Box(
        modifier = Modifier
          .size(280.dp)
          .padding(8.dp),
        contentAlignment = Alignment.Center
      ) {
        val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
        val polyFillColor = SomaticPrimary.copy(alpha = 0.22f)
        val polyStrokeColor = SomaticPrimary

        Canvas(modifier = Modifier.size(260.dp)) {
          val centerX = size.width / 2f
          val centerY = size.height / 2f
          val radius = (size.minDimension / 2f) * 0.72f
          val count = axes.size
          val angleStep = (2 * PI / count).toFloat()

          // Draw 4 Concentric Webs
          for (level in 1..4) {
            val levelRadius = radius * (level / 4f)
            val webPath = Path()
            for (i in 0 until count) {
              val angle = -PI.toFloat() / 2f + i * angleStep
              val x = centerX + levelRadius * cos(angle)
              val y = centerY + levelRadius * sin(angle)
              if (i == 0) webPath.moveTo(x, y) else webPath.lineTo(x, y)
            }
            webPath.close()
            drawPath(
              path = webPath,
              color = gridColor,
              style = Stroke(width = 1.dp.toPx(), cap = StrokeCap.Round)
            )
          }

          // Draw Axis Spoke Lines
          for (i in 0 until count) {
            val angle = -PI.toFloat() / 2f + i * angleStep
            val x = centerX + radius * cos(angle)
            val y = centerY + radius * sin(angle)
            drawLine(
              color = gridColor,
              start = Offset(centerX, centerY),
              end = Offset(x, y),
              strokeWidth = 1.dp.toPx()
            )
          }

          // Draw Data Polygon with Animation
          val polyPath = Path()
          val dataPoints = mutableListOf<Offset>()
          for (i in 0 until count) {
            val axis = axes[i]
            val normalizedVal = (axis.value / 100f).coerceIn(0f, 1f) * animProgress.value
            val currentRadius = radius * normalizedVal
            val angle = -PI.toFloat() / 2f + i * angleStep
            val x = centerX + currentRadius * cos(angle)
            val y = centerY + currentRadius * sin(angle)
            dataPoints.add(Offset(x, y))
            if (i == 0) polyPath.moveTo(x, y) else polyPath.lineTo(x, y)
          }
          polyPath.close()

          // Fill polygon
          drawPath(path = polyPath, color = polyFillColor, style = Fill)

          // Stroke polygon
          drawPath(
            path = polyPath,
            color = polyStrokeColor,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
          )

          // Draw vertex circles
          dataPoints.forEachIndexed { i, pt ->
            drawCircle(
              color = axes[i].color,
              radius = 5.dp.toPx(),
              center = pt
            )
            drawCircle(
              color = Color.White,
              radius = 2.dp.toPx(),
              center = pt
            )
          }

          // Draw Label texts near outer edge using Android native canvas
          val paint = android.graphics.Paint().apply {
            color = android.graphics.Color.GRAY
            textSize = 10.sp.toPx()
            textAlign = android.graphics.Paint.Align.CENTER
            isAntiAlias = true
          }

          for (i in 0 until count) {
            val angle = -PI.toFloat() / 2f + i * angleStep
            val labelRadius = radius * 1.25f
            val lx = centerX + labelRadius * cos(angle)
            val ly = centerY + labelRadius * sin(angle) + 4.dp.toPx()
            val text = "${axes[i].axisType.shortLabel(lang)} (${axes[i].value.toInt()}%)"
            drawContext.canvas.nativeCanvas.drawText(text, lx, ly, paint)
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Breakdown Legend in 2 Columns with Logo-Inspired Icons
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
          .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        val pairs = axes.chunked(2)
        pairs.forEach { rowAxes ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            rowAxes.forEach { axis ->
              Row(
                modifier = Modifier
                  .weight(1f)
                  .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                SomaticLogoIcon(
                  axisType = axis.axisType,
                  size = 24.dp,
                  showBackground = true
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "${axis.label}: ${axis.value.toInt()}%",
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.Medium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.weight(1f, fill = false)
                )
                if (onOpenGuide != null) {
                  Spacer(modifier = Modifier.width(4.dp))
                  InfoGuideButton(
                    topic = getAxisGuideTopic(axis.axisType),
                    onOpenGuide = onOpenGuide,
                    tint = axis.color
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
