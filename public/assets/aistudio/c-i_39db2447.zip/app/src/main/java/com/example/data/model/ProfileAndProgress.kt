package com.example.data.model

data class DancerProfile(
  val name: String,
  val levelTitle: String,
  val bio: String,
  val yearsDanced: Float,
  val primaryRole: String,
  val touchPreference: String,
  val activeIntentions: List<String>,
  val totalJamHours: Float,
  val currentStreakWeeks: Int,
  val completedInquiriesCount: Int,
  val savedRecordsCount: Int
)

data class ProgressMilestone(
  val id: String,
  val title: String,
  val description: String,
  val isUnlocked: Boolean,
  val unlockedDate: String? = null,
  val category: String,
  val iconEmoji: String
)

data class DaySessionData(
  val dayLabel: String,
  val hours: Float,
  val depthRating: Float // 1..5
)

data class SomaticProgress(
  val attunementScore: Float, // 0..100
  val weightShareScore: Float, // 0..100
  val boundaryScore: Float, // 0..100
  val fallingMomentumScore: Float, // 0..100
  val groundingScore: Float, // 0..100
  val nonVerbalScore: Float, // 0..100
  val overallIndex: Float, // 0..100
  val levelTitle: String,
  val nextLevelTitle: String,
  val levelProgressPct: Float,
  val textualNarrative: String,
  val weeklySessions: List<DaySessionData>,
  val milestones: List<ProgressMilestone>
)
