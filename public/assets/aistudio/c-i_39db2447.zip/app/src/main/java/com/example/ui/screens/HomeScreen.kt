package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MovementRecord
import com.example.data.model.SomaticAxisType
import com.example.data.model.SomaticRecommendation
import com.example.ui.components.InfoGuideButton
import com.example.ui.components.LogoBlue
import com.example.ui.components.LogoOrange
import com.example.ui.components.LogoTeal
import com.example.ui.components.PillarChip
import com.example.ui.components.RecordDetailDialog
import com.example.ui.components.SmallDanceMeditationDialog
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.components.SomaticLogoIcon
import com.example.ui.components.getAxisAccentColor
import com.example.ui.components.getAxisGuideTopic
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.ContactWaysViewModel

@Composable
fun HomeScreen(
  viewModel: ContactWaysViewModel,
  isDesktopMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  val lang = LocalAppLanguage.current
  val profile by viewModel.dancerProfile.collectAsState()
  val progress by viewModel.somaticProgress.collectAsState()
  val records by viewModel.filteredRecords.collectAsState()
  val recommendations = viewModel.recommendations
  val selectedRecommendation by viewModel.selectedRecommendation.collectAsState()
  val selectedRecord by viewModel.selectedRecord.collectAsState()
  val isSmallDanceActive by viewModel.isSmallDanceActive.collectAsState()

  val axesQuickSummary = listOf(
    Triple(SomaticAxisType.ATTUNEMENT, SomaticAxisType.ATTUNEMENT.shortLabel(lang), progress.attunementScore.toInt()),
    Triple(SomaticAxisType.WEIGHT_SHARING, SomaticAxisType.WEIGHT_SHARING.shortLabel(lang), progress.weightShareScore.toInt()),
    Triple(SomaticAxisType.BOUNDARIES, SomaticAxisType.BOUNDARIES.shortLabel(lang), progress.boundaryScore.toInt()),
    Triple(SomaticAxisType.FALLING_MOMENTUM, SomaticAxisType.FALLING_MOMENTUM.shortLabel(lang), progress.fallingMomentumScore.toInt()),
    Triple(SomaticAxisType.GROUNDING, SomaticAxisType.GROUNDING.shortLabel(lang), progress.groundingScore.toInt()),
    Triple(SomaticAxisType.TACTILE_ATTENTION, SomaticAxisType.TACTILE_ATTENTION.shortLabel(lang), progress.nonVerbalScore.toInt())
  )

  if (isDesktopMode) {
    // TWO-COLUMN DESKTOP DASHBOARD LAYOUT
    Row(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp, vertical = 12.dp)
        .testTag("home_screen"),
      horizontalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      // First Column (45%): Welcome Card + 6-Axis Overview + Recent Records
      Column(
        modifier = Modifier
          .weight(0.45f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        HomeWelcomeCard(
          name = profile.name,
          overallIndex = progress.overallIndex.toInt(),
          streakWeeks = profile.currentStreakWeeks,
          onReplayIntro = { viewModel.replayIntroAnimation() },
          onOpenReflection = { viewModel.selectTab(AppNavTab.REFLECTION) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        HomeSixAxesSection(
          axesQuickSummary = axesQuickSummary,
          isDesktopGrid = true,
          onNavigateToProgress = { viewModel.selectTab(AppNavTab.PROGRESS) },
          onNavigateToReflection = { viewModel.selectTab(AppNavTab.REFLECTION) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        HomeRecentRecordsSection(
          records = records,
          onOpenAllRecords = { viewModel.selectTab(AppNavTab.RECORDS) },
          onOpenRecordDetails = { viewModel.openRecordDetails(it) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
        Spacer(modifier = Modifier.height(20.dp))
      }

      // Second Column (55%): Tap-to-Reveal Recommendations Grid
      Column(
        modifier = Modifier
          .weight(0.55f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        HomeRecommendationsHeader(
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
        HomeRecommendationsGrid(
          recommendations = recommendations,
          onSelectRecommendation = { viewModel.selectRecommendation(it) },
          onOpenAxisGuide = { viewModel.openGuideTopic(it) }
        )
        Spacer(modifier = Modifier.height(20.dp))
      }
    }
  } else {
    // MOBILE SINGLE-COLUMN LAYOUT
    LazyColumn(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
        .testTag("home_screen"),
      contentPadding = PaddingValues(top = 10.dp, bottom = 88.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        HomeWelcomeCard(
          name = profile.name,
          overallIndex = progress.overallIndex.toInt(),
          streakWeeks = profile.currentStreakWeeks,
          onReplayIntro = { viewModel.replayIntroAnimation() },
          onOpenReflection = { viewModel.selectTab(AppNavTab.REFLECTION) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        HomeSixAxesSection(
          axesQuickSummary = axesQuickSummary,
          isDesktopGrid = false,
          onNavigateToProgress = { viewModel.selectTab(AppNavTab.PROGRESS) },
          onNavigateToReflection = { viewModel.selectTab(AppNavTab.REFLECTION) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        HomeRecommendationsHeader(
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        HomeRecommendationsGrid(
          recommendations = recommendations,
          onSelectRecommendation = { viewModel.selectRecommendation(it) },
          onOpenAxisGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        HomeRecentRecordsSection(
          records = records,
          onOpenAllRecords = { viewModel.selectTab(AppNavTab.RECORDS) },
          onOpenRecordDetails = { viewModel.openRecordDetails(it) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }
    }
  }

  // Recommendation Detail Modal (Revealed on Tap)
  selectedRecommendation?.let { rec ->
    RecommendationDetailDialog(
      recommendation = rec,
      onDismiss = { viewModel.selectRecommendation(null) },
      onStartSmallDance = {
        viewModel.selectRecommendation(null)
        viewModel.toggleSmallDanceMeditation()
      },
      onOpenReflection = {
        viewModel.selectRecommendation(null)
        viewModel.selectTab(AppNavTab.REFLECTION)
      }
    )
  }

  // Record Detail Dialog if user tapped a recent record on Home
  selectedRecord?.let { rec ->
    RecordDetailDialog(
      record = rec,
      onDismiss = { viewModel.closeRecordDetails() },
      onDelete = { viewModel.deleteRecord(it) }
    )
  }

  // Small Dance Meditation Dialog
  if (isSmallDanceActive) {
    SmallDanceMeditationDialog(onDismiss = { viewModel.toggleSmallDanceMeditation() })
  }
}

@Composable
private fun HomeWelcomeCard(
  name: String,
  overallIndex: Int,
  streakWeeks: Int,
  onReplayIntro: () -> Unit,
  onOpenReflection: () -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.linearGradient(
            colors = listOf(
              LogoTeal.copy(alpha = 0.12f),
              LogoBlue.copy(alpha = 0.08f)
            )
          )
        )
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = tr("שלום, $name", "Welcome, $name"),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.width(6.dp))
            InfoGuideButton(
              topic = SomaticGuideTopic.GUIDE_HOME_DASHBOARD,
              onOpenGuide = onOpenGuide
            )
          }
          Text(
            text = tr(
              "מדד סומטי: $overallIndex% • $streakWeeks שבועות רצף",
              "Somatic Index: $overallIndex% • $streakWeeks-week streak"
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        OutlinedButton(
          onClick = onReplayIntro,
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
          modifier = Modifier.testTag("replay_weight_transfer_button")
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = tr("נגן מהלך העברת משקל", "Replay weight transfer intro"),
            modifier = Modifier.size(15.dp),
            tint = SomaticPrimary
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = tr("מהלך משקל", "Weight Flow"),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = SomaticPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Button(
        onClick = onOpenReflection,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = LogoOrange),
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("home_open_reflection_button")
      ) {
        Icon(
          imageVector = Icons.Default.AddCircleOutline,
          contentDescription = null,
          tint = Color.White,
          modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = tr("מילוי רפלקציה חדשה לפי 6 הצירים", "Log a New 6-Axis Dance Reflection"),
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }
    }
  }
}

@Composable
private fun HomeSixAxesSection(
  axesQuickSummary: List<Triple<SomaticAxisType, String, Int>>,
  isDesktopGrid: Boolean,
  onNavigateToProgress: () -> Unit,
  onNavigateToReflection: () -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Column {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = tr("6 צירי המכ״ם הסומטי שלך", "Your 6 Somatic Radar Axes"),
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(6.dp))
        InfoGuideButton(
          topic = SomaticGuideTopic.GUIDE_PROGRESS_RADAR,
          onOpenGuide = onOpenGuide
        )
      }
      Text(
        text = tr("מפה מלאה ›", "Full Radar ›"),
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = SomaticPrimary,
        modifier = Modifier.clickable { onNavigateToProgress() }
      )
    }
    Spacer(modifier = Modifier.height(8.dp))

    if (isDesktopGrid) {
      val rows = axesQuickSummary.chunked(3)
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { rowItems ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            rowItems.forEach { (axisType, shortLabel, pct) ->
              Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier
                  .weight(1f)
                  .clickable { onOpenGuide(getAxisGuideTopic(axisType)) }
              ) {
                Column(
                  modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  SomaticLogoIcon(
                    axisType = axisType,
                    size = 34.dp,
                    showBackground = true
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = shortLabel,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                  )
                  Text(
                    text = "$pct%",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = getAxisAccentColor(axisType)
                  )
                }
              }
            }
          }
        }
      }
    } else {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 2.dp)
      ) {
        items(axesQuickSummary) { (axisType, shortLabel, pct) ->
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            modifier = Modifier
              .width(86.dp)
              .clickable { onOpenGuide(getAxisGuideTopic(axisType)) }
          ) {
            Column(
              modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              SomaticLogoIcon(
                axisType = axisType,
                size = 34.dp,
                showBackground = true
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = shortLabel,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
              )
              Text(
                text = "$pct%",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = getAxisAccentColor(axisType)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun HomeRecommendationsHeader(
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = tr("הצעות והמלצות לתרגול", "Somatic Practice Recommendations"),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(6.dp))
        InfoGuideButton(
          topic = SomaticGuideTopic.GUIDE_HOME_RECOMMENDATIONS,
          onOpenGuide = onOpenGuide
        )
      }
      Text(
        text = tr("לחץ על כרטיס לפתיחת ההמלצה והתרגול", "Tap any card to open its somatic guide & practice"),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
    Icon(
      imageVector = Icons.Default.TouchApp,
      contentDescription = null,
      tint = SomaticPrimary,
      modifier = Modifier.size(18.dp)
    )
  }
}

@Composable
private fun HomeRecommendationsGrid(
  recommendations: List<SomaticRecommendation>,
  onSelectRecommendation: (SomaticRecommendation) -> Unit,
  onOpenAxisGuide: (SomaticGuideTopic) -> Unit
) {
  val lang = LocalAppLanguage.current
  val chunkedRecs = recommendations.chunked(2)
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    chunkedRecs.forEach { rowItems ->
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        rowItems.forEach { rec ->
          val accentColor = getAxisAccentColor(rec.axisType)
          Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier
              .weight(1f)
              .border(1.dp, accentColor.copy(alpha = 0.22f), RoundedCornerShape(18.dp))
              .clickable { onSelectRecommendation(rec) }
              .testTag("recommendation_card_${rec.id}")
          ) {
            Box(modifier = Modifier.fillMaxWidth()) {
              InfoGuideButton(
                topic = getAxisGuideTopic(rec.axisType),
                onOpenGuide = onOpenAxisGuide,
                tint = accentColor,
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .padding(8.dp)
              )
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                SomaticLogoIcon(
                  axisType = rec.axisType,
                  size = 44.dp,
                  showBackground = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = rec.title(lang),
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = accentColor.copy(alpha = 0.10f)
                ) {
                  Text(
                    text = rec.subtitle(lang),
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = accentColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                  )
                }
              }
            }
          }
        }
        if (rowItems.size == 1) {
          Spacer(modifier = Modifier.weight(1f))
        }
      }
    }
  }
}

@Composable
private fun HomeRecentRecordsSection(
  records: List<MovementRecord>,
  onOpenAllRecords: () -> Unit,
  onOpenRecordDetails: (MovementRecord) -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = tr("רשומות אחרונות", "Recent Reflections"),
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(6.dp))
        InfoGuideButton(
          topic = SomaticGuideTopic.GUIDE_RECORDS_MODES,
          onOpenGuide = onOpenGuide
        )
      }
      Text(
        text = tr("לכל היומן (${records.size}) ›", "All Records (${records.size}) ›"),
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = SomaticPrimary,
        modifier = Modifier.clickable { onOpenAllRecords() }
      )
    }

    records.take(2).forEach { rec ->
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOpenRecordDetails(rec) }
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = rec.title,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = "${rec.partner} • ${rec.dateStr}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          PillarChip(pillar = rec.pillarCategory)
        }
      }
    }
  }
}

@Composable
private fun RecommendationDetailDialog(
  recommendation: SomaticRecommendation,
  onDismiss: () -> Unit,
  onStartSmallDance: () -> Unit,
  onOpenReflection: () -> Unit
) {
  val lang = LocalAppLanguage.current
  val accentColor = getAxisAccentColor(recommendation.axisType)

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      shape = RoundedCornerShape(26.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .padding(vertical = 20.dp)
        .testTag("recommendation_detail_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            SomaticLogoIcon(
              axisType = recommendation.axisType,
              size = 44.dp,
              showBackground = true
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = recommendation.title(lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = recommendation.subtitle(lang),
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
                fontWeight = FontWeight.Bold
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = tr("סגור", "Close"))
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = recommendation.explanation(lang),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface,
          lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = tr("צעדים מעשיים לחקירה בג'אם:", "Practical Steps to Explore in the Jam:"),
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = accentColor
        )
        Spacer(modifier = Modifier.height(8.dp))

        recommendation.steps(lang).forEachIndexed { idx, step ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.Top
          ) {
            Box(
              modifier = Modifier
                .size(22.dp)
                .background(accentColor.copy(alpha = 0.14f), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "${idx + 1}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = accentColor
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = step,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              lineHeight = 19.sp,
              modifier = Modifier.weight(1f)
            )
          }
        }

        if (recommendation.quote(lang).isNotBlank()) {
          Spacer(modifier = Modifier.height(14.dp))
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = GroundAmber.copy(alpha = 0.08f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "“${recommendation.quote(lang)}”",
                style = MaterialTheme.typography.bodySmall,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
              )
              if (recommendation.author(lang).isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "— ${recommendation.author(lang)}",
                  style = MaterialTheme.typography.labelSmall,
                  color = GroundAmber,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        if (recommendation.hasInteractivePractice) {
          Button(
            onClick = onStartSmallDance,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary),
            modifier = Modifier
              .fillMaxWidth()
              .height(46.dp)
              .testTag("start_small_dance_from_rec")
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = tr("התחל תרגול מודרך: הריקוד הקטן", "Start Guided Practice: The Small Dance"),
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
        }

        OutlinedButton(
          onClick = onOpenReflection,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
        ) {
          Text(
            text = tr("מלא רפלקציה סומטית על ציר זה", "Log a Somatic Reflection on This Axis"),
            fontWeight = FontWeight.Bold,
            color = SomaticPrimary
          )
        }
      }
    }
  }
}
