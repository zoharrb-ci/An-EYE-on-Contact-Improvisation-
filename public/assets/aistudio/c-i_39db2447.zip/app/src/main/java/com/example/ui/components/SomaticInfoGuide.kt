package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.SomaticAxisType
import com.example.ui.theme.AppLanguage
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr

data class RatingLevelGuide(
  val rangeLabel: String,
  val title: String,
  val somaticDescription: String,
  val color: Color,
  val titleEn: String = title,
  val somaticDescriptionEn: String = somaticDescription
) {
  fun title(lang: AppLanguage): String = if (lang == AppLanguage.HE) title else titleEn
  fun description(lang: AppLanguage): String = if (lang == AppLanguage.HE) somaticDescription else somaticDescriptionEn
}

enum class SomaticGuideTopic(
  val titleHe: String,
  val subtitleHe: String,
  val axisType: SomaticAxisType?,
  val explanationHe: String,
  val ratingLevels: List<RatingLevelGuide> = emptyList(),
  val practicalTips: List<String> = emptyList(),
  val reflectionQuestion: String? = null,
  val titleEn: String = titleHe,
  val subtitleEn: String = subtitleHe,
  val explanationEn: String = explanationHe,
  val practicalTipsEn: List<String> = practicalTips,
  val reflectionQuestionEn: String? = reflectionQuestion
) {
  // --- 6 REFLECTION AXES ---
  AXIS_ATTUNEMENT(
    titleHe = "הקשבה סומטית (Somatic Attunement)",
    subtitleHe = "ציר 1 במכ״ם הרפלקציה • רגישות והתכווננות בזמן אמת",
    axisType = SomaticAxisType.ATTUNEMENT,
    explanationHe = "הקשבה סומטית היא היכולת להרגיש את תנועת הפרטנר ואת השינויים העדינים בטונוס השרירים, בנשימה ובכיוון התנועה מבלי לכפות תוכנית מראש. במקום 'להוביל' או 'להיות מובל', נוצר מרחב של הקשבה הדדית שבו נקודת המגע עצמה מובילה את שני הרוקדים.",
    ratingLevels = listOf(
      RatingLevelGuide(
        "1–4",
        "קשב מפוצל או תגובתי",
        "המחשבה עסוקה ב'מה לעשות עכשיו', קושי להבחין בשינויי כיוון עדינים של הפרטנר.",
        Color(0xFFDC2626),
        "Split or Reactive Attention",
        "Mind occupied with planning next moves; difficulty sensing subtle partner shifts."
      ),
      RatingLevelGuide(
        "5–7",
        "הקשבה פעילה ומתפתחת",
        "רגעים של חיבור וזרימה לצד רגעים שבהם הקשב בורח לתכנון או מאמץ שרירי.",
        GroundAmber,
        "Active Developing Attunement",
        "Moments of fluid connection alongside moments of planning or muscular effort."
      ),
      RatingLevelGuide(
        "8–10",
        "נוכחות סומטית עמוקה",
        "תקשורת מיידית ושקטה דרך נקודת המגע; תחושה שהגוף מגיב מעצמו בחופשיות.",
        Color(0xFF059669),
        "Deep Somatic Presence",
        "Immediate, quiet communication through the rolling point of contact; effortless response."
      )
    ),
    practicalTips = listOf(
      "רכך/י את המבט העיני (מבט היקפי) כדי להעביר קשב אל העור והמרכז.",
      "הקשב/י לנשימה של הפרטנר דרך הגב או השכמות לפני תחילת תנועה גדולה."
    ),
    reflectionQuestion = "באילו רגעים בריקוד הרגשת שאת/ה לא יודע/ת מי יזם את התנועה?",
    titleEn = "Somatic Attunement",
    subtitleEn = "Axis 1 in Reflection Radar • Real-time sensitivity & listening",
    explanationEn = "Somatic Attunement is the ability to sense your partner's micro-shifts in muscle tone, breath, and trajectory without imposing a pre-planned agenda. Instead of leading or following, the rolling point of contact leads both dancers.",
    practicalTipsEn = listOf(
      "Soften your visual gaze (peripheral vision) to shift attention toward skin and center.",
      "Listen to your partner's breath through the back or shoulder blades before initiating large moves."
    ),
    reflectionQuestionEn = "In which moments of the dance did you feel nobody knew who initiated the movement?"
  ),

  AXIS_WEIGHT_SHARING(
    titleHe = "שיתוף משקל (Weight Sharing)",
    subtitleHe = "ציר 2 במכ״ם הרפלקציה • נתינה, קבלה ומרכז כובד משותף",
    axisType = SomaticAxisType.WEIGHT_SHARING,
    explanationHe = "שיתוף משקל הוא לב הפיזיקה של קונטקט אימפרוביזציה: היכולת לתת משקל אמיתי מתוך השלד (מבלי 'ליפול' או להעמיס בכוח) ולקבל משקל של פרטנר דרך מבנה שלדי יציב ומופנה אל הרצפה, או ליצור קונטר-באלאנס (איזון נגדי) משותף.",
    ratingLevels = listOf(
      RatingLevelGuide(
        "1–4",
        "החזקת יתר או עומס שרירי",
        "חשש לתת משקל (נשיאה עצמית נוקשה) או נתינת משקל פתאומית ללא בסיס משותף.",
        Color(0xFFDC2626),
        "Over-holding or Muscular Strain",
        "Hesitation to pour weight (rigid self-holding) or sudden dropping without a shared base."
      ),
      RatingLevelGuide(
        "5–7",
        "העברות משקל הדרגתיות",
        "שיתוף משקל נעים בגבהים נמוכים ובינוניים, עם זהירות במעברים לעמידה.",
        GroundAmber,
        "Gradual Weight Transfers",
        "Pleasant weight sharing at low and mid levels, with caution during transitions to standing."
      ),
      RatingLevelGuide(
        "8–10",
        "איזון וזרימת משקל מלאה",
        "מעבר חלק בין הזרמת משקל לאדמה, תמיכה מהאגן וקונטר-באלאנס הרמוני.",
        Color(0xFF059669),
        "Full Weight Flow & Counterbalance",
        "Seamless pouring of weight into the floor, pelvic support, and harmonic counterbalance."
      )
    ),
    practicalTips = listOf(
      "ודא/י שכפות הרגליים או האגן מושרשים ברצפה לפני קבלת משקל של פרטנר.",
      "חפש/י 'נקודת מגע מתגלגלת' (Rolling Point) במקום החלקה או דחיפה."
    ),
    reflectionQuestion = "האם הרשית לעצמך לתת משקל מלא ולהיתמך, או שהחזקת את עצמך?",
    titleEn = "Weight Sharing",
    subtitleEn = "Axis 2 in Reflection Radar • Giving, receiving & shared center",
    explanationEn = "Weight Sharing is the physics heart of Contact Improvisation: pouring authentic skeletal weight without collapsing, and receiving a partner's mass through aligned bone structure into the floor or shared counterbalance.",
    practicalTipsEn = listOf(
      "Ensure your feet or pelvis are rooted in the floor before receiving a partner's weight.",
      "Look for a continuous Rolling Point of Contact rather than sliding or pushing."
    ),
    reflectionQuestionEn = "Did you allow yourself to pour full weight and be supported, or did you hold yourself back?"
  ),

  AXIS_BOUNDARIES(
    titleHe = "גבולות והסכמה (Boundaries & Consent)",
    subtitleHe = "ציר 3 במכ״ם הרפלקציה • בהירות ב-'לא' שיוצרת אמון ב-'כן'",
    axisType = SomaticAxisType.BOUNDARIES,
    explanationHe = "בהשראת מרטין קיו ('101 דרכים לומר לא' ותרגיל שני הנהרות): היכולת להקשיב לגבולות הפיזיים והרגשיים של הגוף בזמן אמת. כאשר רקדן מרגיש בטוח לשנות כיוון, להאט או לסמן גבול ברור ללא אשמה, נוצר אמון שמאפשר 'כן' שלם וחופשי.",
    ratingLevels = listOf(
      RatingLevelGuide(
        "1–4",
        "ריצוי או חציית גבול עצמי",
        "כניסה לתנועה או הרמה שלא התאימה לגוף מתוך אי-נעימות לעצור או לשנות.",
        Color(0xFFDC2626),
        "Pleasing or Overstepping Self-Boundary",
        "Entering a lift or trajectory that didn't feel right out of hesitation to redirect."
      ),
      RatingLevelGuide(
        "5–7",
        "מודעות לגבול בזמן אמת",
        "זיהוי של אי-נוחות ושינוי כיוון תנועתי, גם אם באיחור קל.",
        GroundAmber,
        "Real-time Boundary Awareness",
        "Noticing discomfort and redirecting movement, even if slightly delayed."
      ),
      RatingLevelGuide(
        "8–10",
        "בהירות, ביטחון והסכמה מלאה",
        "נאמנות מלאה ל'נהר שלי' לצד קשב ל'נהר של הפרטנר' — חופש לומר לא וכן.",
        Color(0xFF059669),
        "Full Clarity, Safety & Consent",
        "Fidelity to 'My River' alongside listening to 'Partner's River'—freedom to say no and yes."
      )
    ),
    practicalTips = listOf(
      "סימון גבול לא חייב לעצור את הריקוד — ניתן להתגלגל הצידה, לרדת לרצפה או להפחית משקל.",
      "בדוק/י עם עצמך בכל כמה דקות: 'האם הגוף שלי אומר כן למה שקורה עכשיו?'"
    ),
    reflectionQuestion = "האם היה רגע שבו הגוף שלך סימן 'לא' קטן, ואיך בחרת להגיב אליו?",
    titleEn = "Boundaries & Consent",
    subtitleEn = "Axis 3 in Reflection Radar • Clear 'No' enables a wholehearted 'Yes'",
    explanationEn = "Inspired by Martin Keogh ('101 Ways to Say No' and the Two Rivers exercise): listening to your physical and emotional boundaries in real time. Feeling safe to redirect or lower your center builds deep mutual trust.",
    practicalTipsEn = listOf(
      "Signaling a boundary doesn't have to stop the dance—spiral aside, ground your pelvis, or lighten contact.",
      "Check in every few minutes: 'Is my body saying a genuine yes to what is happening right now?'"
    ),
    reflectionQuestionEn = "Was there a moment where your body signaled a subtle 'no', and how did you respond?"
  ),

  AXIS_FALLING_MOMENTUM(
    titleHe = "נפילה ומומנטום (Falling & Momentum)",
    subtitleHe = "ציר 4 במכ״ם הרפלקציה • ספירלות, ריכוך והפיכת נפילה לזרימה",
    axisType = SomaticAxisType.FALLING_MOMENTUM,
    explanationHe = "בקונטקט אימפרוביזציה נפילה אינה תקלה אלא מנוע התנועה. במקום לבלום את המומנטום בעזרת כיווץ שרירים, אנו משתמשים בתנועה ספירלית ובהגדלת שטח הפנים עם הרצפה או הפרטנר כדי להפוך אנרגיה אנכית לתנועה אופקית רציפה.",
    ratingLevels = listOf(
      RatingLevelGuide(
        "1–4",
        "בלימה וחשש מאובדן שליטה",
        "עצירת תנופה באמצעות כיווץ בצוואר/בכתפיים ופחד מירידה מהירה לרצפה.",
        Color(0xFFDC2626),
        "Braking & Fear of Losing Control",
        "Stopping momentum by tensing neck/shoulders and resisting descent to the floor."
      ),
      RatingLevelGuide(
        "5–7",
        "שימוש חלקי בתנופה",
        "ירידה רכה לרצפה ושימוש בסיבוב האגן, עם שליטה מבוקרת במעברים.",
        GroundAmber,
        "Partial Momentum Flow",
        "Soft descent into the floor using pelvic rotation, with controlled transitions."
      ),
      RatingLevelGuide(
        "8–10",
        "רכיבה חופשית על המומנטום",
        "ספירלות טבעיות, רכות במפגש עם הרצפה והתמרת תנופת הנפילה להמשך ריקוד.",
        Color(0xFF059669),
        "Effortless Riding of Momentum",
        "Natural spirals, soft floor integration, and transforming downward energy into upward flow."
      )
    ),
    practicalTips = listOf(
      "נשוף/י אוויר ברגע שבו מתחילה ירידה אל הרצפה כדי למנוע הקשחת בית החזה.",
      "תן/י לקצה הגוף (כף יד, מרפק רך, ירך) לפגוש את הקרקע ברצף מתגלגל."
    ),
    reflectionQuestion = "איך פגש הגוף שלך את הרצפה או את אובדן שיווי המשקל בריקוד הזה?",
    titleEn = "Falling & Momentum",
    subtitleEn = "Axis 4 in Reflection Radar • Spirals, softening & continuous flow",
    explanationEn = "In Contact Improvisation, falling is not an error—it is the engine of motion. Rather than braking momentum with muscular tension, we use spirals and wide surface contact to turn vertical drop into horizontal flow.",
    practicalTipsEn = listOf(
      "Exhale as you begin descending toward the floor to keep your ribcage supple.",
      "Let the extremities (palm, soft forearm, thigh, back) meet the floor in a sequential roll."
    ),
    reflectionQuestionEn = "How did your body meet the floor or moments of off-balance during this dance?"
  ),

  AXIS_GROUNDING(
    titleHe = "קרקוע — הריקוד הקטן (Grounding & Small Dance)",
    subtitleHe = "ציר 5 במכ״ם הרפלקציה • יציבות שלדית והקשבה לכוח המשיכה",
    axisType = SomaticAxisType.GROUNDING,
    explanationHe = "'הריקוד הקטן' (The Small Dance) שפיתח סטיב פקסטון הוא תנודות המיקרו הזעירות של השלד בעמידה שקטה מול כוח המשיכה. קרקוע פירושו שהתנועה צומחת מתוך קשר עמוק לאדמה וארגון שלדי יעיל, ולא מתוך מאמץ שרירי מיותר.",
    ratingLevels = listOf(
      RatingLevelGuide(
        "1–4",
        "ניתוק מהקרקע או מתח עליון",
        "משקל הגוף עולה לכתפיים ולחזה, תחושת חוסר יציבות או תלישות מהרצפה.",
        Color(0xFFDC2626),
        "Uprooted or Upper-Body Tension",
        "Weight rises into shoulders and chest; feeling unstable or disconnected from the floor."
      ),
      RatingLevelGuide(
        "5–7",
        "חיבור יציב לאדמה",
        "מודעות לכפות הרגליים ולאגן, ויכולת לחזור לבסיס יציב לאחר תנועה רחבה.",
        GroundAmber,
        "Steady Earth Connection",
        "Clear awareness of feet and pelvis, returning to a grounded base after expansive moves."
      ),
      RatingLevelGuide(
        "8–10",
        "השתרשות שלדית עמוקה",
        "תחושת תמיכה מלאה מהאדמה; השלד מאורגן, המפרקים פתוחים והתנועה חסרת מאמץ.",
        Color(0xFF059669),
        "Deep Skeletal Rooting",
        "Full support from the earth; aligned skeleton, open joints, and effortless movement."
      )
    ),
    practicalTips = listOf(
      "לפני תחילת ריקוד, עמוד/י 30 שניות בעיניים עצומות והרגש/י את הרפלקסים של העמידה.",
      "דמיין/י שהמשקל שלך נוזל דרך כפות הרגליים אל תוך הרצפה בכל צעד."
    ),
    reflectionQuestion = "עד כמה הרגשת את התמיכה של הרצפה ושל השלד שלך בזמן התנועה?",
    titleEn = "Grounding — The Small Dance",
    subtitleEn = "Axis 5 in Reflection Radar • Skeletal alignment & gravity awareness",
    explanationEn = "Steve Paxton's 'Small Dance' tunes into the micro-reflexes of the skeleton standing quietly in gravity. Grounding means movement grows from a deep connection to the earth and skeletal organization rather than muscular force.",
    practicalTipsEn = listOf(
      "Before starting a duet, stand quietly for 30 seconds and sense your postural reflexes.",
      "Imagine your weight pouring through the soles of your feet into the floor with every step."
    ),
    reflectionQuestionEn = "How deeply did you feel the support of the floor and your skeleton while moving?"
  ),

  AXIS_TACTILE_ATTENTION(
    titleHe = "תשומת לב עורית (Tactile Attention)",
    subtitleHe = "ציר 6 במכ״ם הרפלקציה • הקשבה רב-כיוונית דרך העור והמרחב",
    axisType = SomaticAxisType.TACTILE_ATTENTION,
    explanationHe = "העור הוא איבר החישה הגדול ביותר שלנו. 'תשומת לב עורית' היא היכולת לחוש לא רק את הנקודה שבה אנו נוגעים בפרטנר, אלא את כל מעטפת העור ב-360 מעלות — כולל המגע עם האוויר, הבגד, הרצפה והמרחב שמאחורי הגב.",
    ratingLevels = listOf(
      RatingLevelGuide(
        "1–4",
        "מיקוד צר או מגע מכני",
        "תשומת הלב מרוכזת רק בכפות הידיים או בראייה, ושאר הגוף פחות קשוב.",
        Color(0xFFDC2626),
        "Narrow Focus or Mechanical Touch",
        "Attention concentrated only in the hands or visual field; back and torso less responsive."
      ),
      RatingLevelGuide(
        "5–7",
        "רגישות עורית מתרחבת",
        "קשב נעים באזורי הגב, הכתפיים והאגן, עם פתיחות למגע משתנה.",
        GroundAmber,
        "Expanding Tactile Sensitivity",
        "Responsive listening across the back, shoulders, and pelvis with openness to shifting touch."
      ),
      RatingLevelGuide(
        "8–10",
        "ערנות עורית רב-ממדית (360°)",
        "כל פני העור קשובים ונושמים; תחושת מרחב, עדינות ודיוק בכל איכות מגע.",
        Color(0xFF059669),
        "360° Multi-Dimensional Skin Awareness",
        "The entire skin envelope breathes and listens; spaciousness and precision in every contact."
      )
    ),
    practicalTips = listOf(
      "נסה/י ליזום תנועה מהעור של הגב העליון או הצלעות במקום מהידיים.",
      "הבחן/י בטמפרטורה, במרקם ובכיוון הסיבים של המגע בכל רגע."
    ),
    reflectionQuestion = "איזה אזור בגוף שלך היה הכי ער ורגיש למגע במהלך הריקוד?",
    titleEn = "Tactile Attention",
    subtitleEn = "Axis 6 in Reflection Radar • 360° listening through skin & space",
    explanationEn = "The skin is our largest sensory organ. Tactile Attention is the capacity to sense not only the active point of contact with a partner, but the entire 360° skin envelope—including air, floor, and back space.",
    practicalTipsEn = listOf(
      "Try initiating movement from the skin of your upper back or ribs rather than your hands.",
      "Notice temperature, texture, and shear direction at the contact point."
    ),
    reflectionQuestionEn = "Which area of your body felt most awake and sensitive to touch during the dance?"
  ),

  // --- ADDITIONAL REFLECTION FORM PARAMETERS ---
  PARAM_LIVE_RADAR(
    titleHe = "תצוגת מכ״ם חיה לריקוד הנוכחי",
    subtitleHe = "משוב ויזואלי בזמן אמת ל-6 צירי הרפלקציה",
    axisType = SomaticAxisType.WEIGHT_SHARING,
    explanationHe = "מפת המכ״ם המשושה בראש טופס הרפלקציה מציגה בזמן אמת את האיזון בין ששת הצירים של הריקוד הנוכחי. ככל שהמצולע רחב ומאוזן יותר, כך הריקוד שילב הקשבה, משקל, גבולות, מומנטום, קרקוע ומגע עורי באופן הרמוני.",
    practicalTips = listOf(
      "אין צורך לשאוף ל-10 בכל ציר — המטרה היא שיקוף כן של איכות המפגש.",
      "שמירת הרפלקציה תעדכן אוטומטית את מפת ההתקדמות הרב-שבועית שלך בלשונית 'התקדמות'."
    ),
    titleEn = "Live 6-Axis Radar Preview",
    subtitleEn = "Real-time visual feedback for the current dance reflection",
    explanationEn = "The hexagonal radar map visualizes the balance across all 6 somatic axes for your current dance in real time. Saving this reflection automatically updates your multi-week Progress Radar.",
    practicalTipsEn = listOf(
      "There is no need to aim for 10 on every axis—the goal is an honest somatic mirror of the duet.",
      "Saving the reflection immediately updates your long-term Progress tab."
    )
  ),

  PARAM_TWO_RIVERS(
    titleHe = "מצב גבולות — תרגיל 'שני הנהרות'",
    subtitleHe = "הנהר שלי, הנהר של הפרטנר והמפגש ביניהם",
    axisType = SomaticAxisType.BOUNDARIES,
    explanationHe = "תרגיל 'שני הנהרות' (Two Rivers) מתאר שני זרמים מקבילים בריקוד: 'הנהר שלי' (הצורך הפנימי, הקצב והגבולות שלי) ו'הנהר שלך' (ההצעות והתנועה של הפרטנר). בחירה בפרמטר זה מתעדת כיצד חווית את המרחב והגבולות בריקוד.",
    practicalTips = listOf(
      "מגע בכל מקום (מבוסס אמון): זרימה פתוחה שבה שני הצדדים חשים ביטחון מלא.",
      "מגע עדין בלבד: העדפה להקשבה שקטה, משקל קל ואינטימיות סומטית עדינה.",
      "עצירה / סימון גבול: תיעוד חשוב של רגע שבו בחרת לשמור על עצמך ולסמן גבול ברור."
    ),
    titleEn = "Boundary State — 'Two Rivers' Exercise",
    subtitleEn = "My River, Partner's River & the meeting point between them",
    explanationEn = "The 'Two Rivers' exercise describes two parallel streams in a dance: 'My River' (my internal pace, needs, and boundaries) and 'Your River' (my partner's invitations). Selecting this logs how you navigated consent.",
    practicalTipsEn = listOf(
      "Trust-based full contact: Open flow where both partners feel complete safety.",
      "Gentle contact only: Preference for quiet listening and light weight.",
      "Pause / Boundary signal: Valuable log of a moment you honored your boundary."
    )
  ),

  PARAM_CONTACT_POINTS(
    titleHe = "נקודות מגע בגוף ופרטי הריקוד",
    subtitleHe = "מיפוי האזורים הפיזיים שהובילו את הדיאלוג",
    axisType = SomaticAxisType.TACTILE_ATTENTION,
    explanationHe = "תיעוד נקודות המגע (כגון אגן ומרכז, גב אל גב, שכמות, משטח הרצפה) עוזר לך לזהות דפוסים לאורך זמן: אילו אזורים בגוף מוכרים ובטוחים עבורך, ואילו אזורים חדשים נפתחים לחקירה.",
    practicalTips = listOf(
      "ניתן לבחור מספר נקודות מגע שהיו דומיננטיות בריקוד.",
      "ציון שם הפרטנר והג׳אם מאפשר לך לחפש ולסנן רשומות לפי שותפים או סדנאות ביומן."
    ),
    titleEn = "Body Contact Points & Session Details",
    subtitleEn = "Mapping the physical surfaces that led the dialogue",
    explanationEn = "Logging contact points (Pelvis & Center, Back-to-Back, Shoulder Blades, Floor Surface) helps identify somatic patterns over time—which zones feel familiar and which new surfaces are opening to exploration.",
    practicalTipsEn = listOf(
      "You can select multiple contact points that were dominant during the session.",
      "Logging partner and jam names lets you filter and search your journal later."
    )
  ),

  PARAM_REFLECTION_NOTES(
    titleHe = "הערת רפלקציה ותובנה מרכזית",
    subtitleHe = "עיבוד מילולי של החוויה הגופנית",
    axisType = SomaticAxisType.ATTUNEMENT,
    explanationHe = "המעבר מחוויה גופנית (סומטית) למילים מחזק את הזיכרון התנועתי. בשדה 'רפלקציה טקסטואלית' מומלץ לתאר תחושות גוף ורגעים משמעותיים ללא שיפוטיות, ובשדה 'תובנה מרכזית' לזקק משפט קצר אחד שתרצה/י לקחת לג׳אם הבא.",
    practicalTips = listOf(
      "כתוב/י בגוף ראשון ובהווה או בעבר קרוב ('הרגשתי שכאשר שחררתי את האגן...').",
      "התובנה המרכזית תופיע כציטוט מודגש בכרטיס הרשומה שלך ביומן."
    ),
    titleEn = "Reflection Notes & Key Takeaway",
    subtitleEn = "Translating bodily sensation into verbal integration",
    explanationEn = "Bridging somatic sensation into words strengthens kinesthetic memory. Describe bodily sensations without judgment in the notes field, and distill one concise sentence in Key Takeaway for your next jam.",
    practicalTipsEn = listOf(
      "Write in the first person about concrete sensations ('When I softened my pelvis...').",
      "Your Key Takeaway is highlighted on your journal card in the Records tab."
    )
  ),

  // --- APP-WIDE GUIDES ---
  GUIDE_APP_OVERVIEW(
    titleHe = "מדריך האפליקציה ומצב שולחני / מסך מלא",
    subtitleHe = "הכרת סביבת העבודה של Contact Ways (עברית / English)",
    axisType = SomaticAxisType.WEIGHT_SHARING,
    explanationHe = "Contact Ways היא סוויטת התבוננות, תיעוד וחקירה סומטית לרקדני קונטקט אימפרוביזציה. האפליקציה מותאמת באופן מלא הן לטלפון נייד והן למחשב שולחני ומסך מלא (Desktop & Full-Screen Mode), ותומכת במעבר מיידי בין עברית לאנגלית.",
    practicalTips = listOf(
      "כפתור 'EN / עב' בסרגל העליון מחליף מיידית בין עברית (RTL) לאנגלית (LTR).",
      "כפתור 'מצב שולחני' מעביר לפריסה דו-עמודתית רחבה (16:9) עם סרגל ניווט צידי.",
      "כפתור 'מסך מלא' מסתיר את סרגלי המערכת לתצוגה נקייה ורחבה במיוחד."
    ),
    titleEn = "App Overview & Desktop / Full-Screen Mode",
    subtitleEn = "Getting to know the Contact Ways bilingual workspace",
    explanationEn = "Contact Ways is a somatic reflection, journaling, and inquiry suite for Contact Improvisation dancers. It adapts seamlessly between mobile portrait and Desktop Widescreen / Full-Screen mode, with instant Hebrew (RTL) and English (LTR) switching.",
    practicalTipsEn = listOf(
      "Click 'EN / עב' in the top bar or side rail to switch between English (LTR) and Hebrew (RTL).",
      "Click 'Desktop Mode' to switch to a 16:9 widescreen split-pane workspace with a side navigation rail.",
      "Click every ⓘ button next to any reflection axis or header for in-depth somatic guidance."
    )
  ),

  GUIDE_HOME_DASHBOARD(
    titleHe = "מדריך המסך הראשי ומדד המודעות הסומטית",
    subtitleHe = "תמונת מצב מהירה של התרגול שלך",
    axisType = SomaticAxisType.ATTUNEMENT,
    explanationHe = "המסך הראשי מציג באופן נקי ומאוורר את מדד המודעות הסומטית המשוקלל שלך (מתוך 6 צירי הרפלקציה), גישה מהירה למילוי רפלקציה חדשה, סקירת ששת הצירים, וכרטיסי המלצות לתרגול.",
    practicalTips = listOf(
      "לחץ/י על כל אחד מ-6 הצירים בסרגל המהיר כדי לעבור למילוי רפלקציה או למפת ההתקדמות.",
      "כפתור 'מהלך משקל' מפעיל מחדש את אנימציית הפתיחה של העברת המשקל והרציונאל."
    ),
    titleEn = "Home Dashboard & Somatic Awareness Index",
    subtitleEn = "At-a-glance overview of your movement practice",
    explanationEn = "The Home screen presents your weighted Somatic Awareness Index across the 6 reflection axes, quick access to logging a new reflection, a 6-axis overview strip, and tap-to-reveal micro-practices.",
    practicalTipsEn = listOf(
      "Tap any of the 6 axes in the quick strip to jump to New Reflection or Progress.",
      "Tap 'Weight Flow' in the header to replay the interactive weight-transfer intro animation."
    )
  ),

  GUIDE_HOME_RECOMMENDATIONS(
    titleHe = "מדריך הצעות והמלצות לתרגול",
    subtitleHe = "כרטיסי מיקרו-תרגול שנפתחים בלחיצה",
    axisType = SomaticAxisType.GROUNDING,
    explanationHe = "כדי לשמור על מסך נקי מעומס טקסטואלי, כל כרטיס מציג את אייקון הציר המותאם מהלוגו וכותרת ממוקדת. לחיצה על כרטיס פותחת חלונית עם ההסבר המלא, צעדים מעשיים לחקירה בג׳אם, ציטוט השראה וכפתור לתרגול חי.",
    practicalTips = listOf(
      "בחר/י המלצה אחת בלבד לפני כניסה לג׳אם ככוונת מיקוד (Intention).",
      "מכרטיס 'הריקוד הקטן' ניתן להפעיל טיימר ותרגול מודרך של עמידה קשובה."
    ),
    titleEn = "Somatic Practice Recommendations Guide",
    subtitleEn = "Tap-to-reveal micro-practice cards",
    explanationEn = "To keep the workspace calm and uncluttered, each card displays its custom C-i axis icon and focused title. Clicking a card opens the full somatic explanation, practical steps for your next jam, a quote, and interactive practice.",
    practicalTipsEn = listOf(
      "Choose just one recommendation before entering a jam as your somatic intention.",
      "Open 'The Small Dance' card to launch a guided standing meditation timer."
    )
  ),

  GUIDE_RECORDS_MODES(
    titleHe = "מדריך יומן רשומות ו-4 אופני התצוגה",
    subtitleHe = "כרטיסים, ציר זמן, לפי נושא ותמציתי",
    axisType = SomaticAxisType.WEIGHT_SHARING,
    explanationHe = "יומן הרשומות שומר את כל הרפלקציות שמילאת ומאפשר לבחון אותן ב-4 אופני תצוגה שונים לבחירתך. במצב שולחני המסך מתפצל אוטומטית לרשימה מימין ותצוגת פרטים מלאה של 6 הצירים משמאל.",
    practicalTips = listOf(
      "כרטיסים: תצוגה עשירה עם תובנת המפתח ונקודות המגע.",
      "ציר זמן: מעקב כרונולוגי לאורך השבועות והג׳אמים.",
      "לפי נושא: קיבוץ אוטומטי לפי הציר הסומטי המוביל בכל ריקוד.",
      "תמציתי: רשימה מהירה וצפופה לסריקה נוחה."
    ),
    titleEn = "Movement Records Journal & 4 View Modes",
    subtitleEn = "Cards, Timeline, By Theme, and Compact views",
    explanationEn = "The Records journal stores all your dance reflections and lets you inspect them across 4 distinct view modes. In Desktop Mode, the screen automatically splits into a master list and a persistent 6-axis detail pane.",
    practicalTipsEn = listOf(
      "Cards: Rich overview featuring key takeaways and contact points.",
      "Timeline: Chronological progression across jams and workshops.",
      "By Theme: Automatic grouping by primary somatic pillar.",
      "Compact: High-density list for rapid scanning."
    )
  ),

  GUIDE_INQUIRIES_MODES(
    titleHe = "מדריך שיחות, חקירות סומטיות ואופני תצוגה",
    subtitleHe = "דיאלוג קהילתי סביב שאלות מפתח בקונטקט",
    axisType = SomaticAxisType.ATTUNEMENT,
    explanationHe = "מסך השיחות מרכז חקירות מונחות מתוך ספרות המקצוע של קונטקט אימפרוביזציה (סטיב פקסטון, ננסי סטארק סמית׳, מרטין קיו). ניתן לקרוא, להשיב ולהחליף בין 4 אופני תצוגה.",
    practicalTips = listOf(
      "שיחה: שרשור הודעות חי שבו ניתן להוסיף תובנה אישית משלך.",
      "שאלות ותשובות: תצוגת אקורדיון מתקפלת לפי שאלות מנחות.",
      "תובנות: ריכוז עקרונות מפתח וציטוטים מרכזיים.",
      "כרטיסיות: כרטיסיות מתהפכות (Flashcards) לתרגול עצמי לפני סדנה או ג׳אם."
    ),
    titleEn = "Somatic Inquiries & 4 Dialogue Modes",
    subtitleEn = "Guided explorations from Contact Improvisation literature",
    explanationEn = "The Inquiries screen curates guided dialogues rooted in foundational Contact Improvisation texts (Steve Paxton, Martin Keogh, Kathleen Rea). Read, contribute your own reflections, and switch among 4 study views.",
    practicalTipsEn = listOf(
      "Chat: Interactive thread where you can post your own reflection.",
      "Q&A: Expandable accordion organized by guiding questions.",
      "Insights: Distilled somatic principles and reference quotes.",
      "Flashcards: Interactive flip cards for pre-jam contemplation."
    )
  ),

  GUIDE_PROGRESS_RADAR(
    titleHe = "מדריך מפת המכ״ם הסומטי — 6 עמודי התווך",
    subtitleHe = "ניתוח גראפי וטקסטואלי של התפתחותך כרקדנ/ית",
    axisType = SomaticAxisType.FALLING_MOMENTUM,
    explanationHe = "מפת המכ״ם משקללת את כל הרפלקציות שלך ביומן לתוך 6 צירי היסוד: הקשבה סומטית, שיתוף משקל, גבולות והסכמה, נפילה ומומנטום, קרקוע (הריקוד הקטן), ותשומת לב עורית.",
    practicalTips = listOf(
      "הסיכום הטקסטואלי מעל המכ״ם מתעדכן דינמית ומצביע על הצירים החזקים שלך.",
      "כל רפלקציה חדשה שתשמור/י בלשונית 'רפלקציה חדשה' תעדכן מיד את הגרף."
    ),
    titleEn = "6-Pillar Somatic Radar Map Guide",
    subtitleEn = "Graphical and narrative synthesis of your movement growth",
    explanationEn = "The Somatic Radar aggregates all your journal reflections across the 6 core pillars: Somatic Attunement, Weight Sharing, Boundaries & Consent, Falling & Momentum, Grounding (Small Dance), and Tactile Attention.",
    practicalTipsEn = listOf(
      "The narrative summary highlights your strongest pillars and growth edges.",
      "Every new reflection saved in the 'New Reflection' tab updates this radar immediately."
    )
  ),

  GUIDE_PROGRESS_WEEKLY(
    titleHe = "מדריך גרף פעילות שבועית ואבני דרך",
    subtitleHe = "מעקב אחר שעות ג׳אם, עומק רפלקציה והישגים",
    axisType = SomaticAxisType.GROUNDING,
    explanationHe = "גרף העמודות מציג את היקף שעות הג׳אם והסדנאות שלך לאורך השבועות האחרונים לצד עומק ההקשבה הממוצע. מתחתיו מופיעות אבני דרך סומטיות שנפתחות ככל שהתרגול שלך מעמיק.",
    practicalTips = listOf(
      "עקביות שבועית (אפילו של ג׳אם אחד בשבוע) בונה ביטחון שלדי וזיכרון סומטי."
    ),
    titleEn = "Weekly Jam Activity & Somatic Milestones",
    subtitleEn = "Tracking jam hours, reflection depth & unlocked milestones",
    explanationEn = "The bar chart tracks your weekly jam/workshop hours alongside average attunement depth, paired with somatic milestones unlocked as your practice deepens.",
    practicalTipsEn = listOf(
      "Consistent weekly practice—even a single focused jam—builds skeletal trust and somatic memory."
    )
  ),

  GUIDE_PROFILE_INTENTIONS(
    titleHe = "מדריך פרופיל רקדן, העדפות תצוגה וגבולות",
    subtitleHe = "התאמה אישית של החשבון וכוונות החקירה",
    axisType = SomaticAxisType.BOUNDARIES,
    explanationHe = "במסך החשבון ניתן לערוך את הפרופיל התנועתי שלך, להגדיר את אופן התצוגה הקבוע לרשומות ולשיחות, ולנסח את העדפת המגע והגבולות האישית שלך ('שני הנהרות') ואת כוונות החקירה הנוכחיות.",
    practicalTips = listOf(
      "עדכן/י את כוונות החקירה שלך בכל חודש בהתאם לציר שתרצה/י לחזק במכ״ם."
    ),
    titleEn = "Dancer Profile, View Preferences & Intentions",
    subtitleEn = "Personalizing your movement identity and boundaries",
    explanationEn = "In the Profile tab you can edit your movement bio, choose default display modes for Records and Inquiries, and articulate your personal touch preference ('Two Rivers') and active movement intentions.",
    practicalTipsEn = listOf(
      "Refresh your active movement intentions monthly based on the axis you wish to cultivate."
    )
  );

  fun title(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, titleHe, titleEn)
  fun subtitle(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, subtitleHe, subtitleEn)
  fun explanation(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, explanationHe, explanationEn)
  fun tips(lang: AppLanguage): List<String> =
    if (lang == AppLanguage.HE) practicalTips else practicalTipsEn.map { com.example.ui.theme.trLang(lang, it, it) }
  fun question(lang: AppLanguage): String? =
    if (lang == AppLanguage.HE) reflectionQuestion else reflectionQuestionEn?.let { com.example.ui.theme.trLang(lang, it, it) }
}

fun getAxisGuideTopic(axisType: SomaticAxisType): SomaticGuideTopic {
  return when (axisType) {
    SomaticAxisType.ATTUNEMENT -> SomaticGuideTopic.AXIS_ATTUNEMENT
    SomaticAxisType.WEIGHT_SHARING -> SomaticGuideTopic.AXIS_WEIGHT_SHARING
    SomaticAxisType.BOUNDARIES -> SomaticGuideTopic.AXIS_BOUNDARIES
    SomaticAxisType.FALLING_MOMENTUM -> SomaticGuideTopic.AXIS_FALLING_MOMENTUM
    SomaticAxisType.GROUNDING -> SomaticGuideTopic.AXIS_GROUNDING
    SomaticAxisType.TACTILE_ATTENTION -> SomaticGuideTopic.AXIS_TACTILE_ATTENTION
  }
}

/**
 * Interactive Info & Guidance Button (`ⓘ`) to place next to any reflection parameter or section header.
 */
@Composable
fun InfoGuideButton(
  topic: SomaticGuideTopic,
  onOpenGuide: (SomaticGuideTopic) -> Unit,
  modifier: Modifier = Modifier,
  label: String? = null,
  tint: Color = LogoBlue
) {
  val lang = LocalAppLanguage.current
  if (label != null) {
    Surface(
      shape = RoundedCornerShape(50),
      color = tint.copy(alpha = 0.10f),
      modifier = modifier
        .clickable { onOpenGuide(topic) }
        .testTag("info_btn_${topic.name.lowercase()}")
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Outlined.Info,
          contentDescription = tr("מידע והסבר: ${topic.titleHe}", "Info & Guide: ${topic.titleEn}"),
          tint = tint,
          modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = label,
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = tint,
          fontSize = 11.sp
        )
      }
    }
  } else {
    Box(
      modifier = modifier
        .size(30.dp)
        .background(tint.copy(alpha = 0.12f), CircleShape)
        .border(1.dp, tint.copy(alpha = 0.3f), CircleShape)
        .clickable { onOpenGuide(topic) }
        .testTag("info_btn_${topic.name.lowercase()}"),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Outlined.Info,
        contentDescription = tr("מידע והסבר: ${topic.title(lang)}", "Info & Guide: ${topic.title(lang)}"),
        tint = tint,
        modifier = Modifier.size(17.dp)
      )
    }
  }
}

/**
 * Modal dialog displaying detailed somatic guidance, 1-10 rating scale breakdown,
 * practical tips, and quick navigation between all 6 reflection axis guides.
 */
@Composable
fun SomaticInfoGuideDialog(
  topic: SomaticGuideTopic,
  onSelectTopic: (SomaticGuideTopic) -> Unit,
  onDismiss: () -> Unit
) {
  val lang = LocalAppLanguage.current
  val accentColor = topic.axisType?.let { getAxisAccentColor(it) } ?: SomaticPrimary
  val allAxisTopics = listOf(
    SomaticGuideTopic.AXIS_ATTUNEMENT,
    SomaticGuideTopic.AXIS_WEIGHT_SHARING,
    SomaticGuideTopic.AXIS_BOUNDARIES,
    SomaticGuideTopic.AXIS_FALLING_MOMENTUM,
    SomaticGuideTopic.AXIS_GROUNDING,
    SomaticGuideTopic.AXIS_TACTILE_ATTENTION
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      shape = RoundedCornerShape(26.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .widthIn(max = 640.dp)
        .padding(vertical = 18.dp)
        .testTag("somatic_info_guide_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        // Header with Logo-style icon
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            if (topic.axisType != null) {
              SomaticLogoIcon(
                axisType = topic.axisType,
                size = 48.dp,
                showBackground = true
              )
            } else {
              Box(
                modifier = Modifier
                  .size(46.dp)
                  .background(accentColor.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.HelpOutline,
                  contentDescription = null,
                  tint = accentColor,
                  modifier = Modifier.size(24.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = topic.title(lang),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = topic.subtitle(lang),
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = tr("סגור מדריך", "Close guide"))
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quick switcher across the 6 axes so the user can explore all parameters easily
        Text(
          text = tr("מעבר מהיר בין הסברי 6 הצירים:", "Quick switch across the 6 Reflection Axes:"),
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          contentPadding = PaddingValues(vertical = 2.dp)
        ) {
          items(allAxisTopics) { axisTopic ->
            val isSelected = axisTopic == topic
            val chipColor = axisTopic.axisType?.let { getAxisAccentColor(it) } ?: SomaticPrimary
            Surface(
              shape = RoundedCornerShape(50),
              color = if (isSelected) chipColor else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
              modifier = Modifier.clickable { onSelectTopic(axisTopic) }
            ) {
              Text(
                text = axisTopic.axisType?.shortLabel(lang) ?: axisTopic.title(lang).take(10),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(12.dp))

        // Main Explanation
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = accentColor.copy(alpha = 0.08f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = tr("מהות הפרמטר והרציונאל הסומטי:", "Somatic Rationale & Parameter Meaning:"),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = accentColor
              )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = topic.explanation(lang),
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurface,
              lineHeight = 22.sp
            )
          }
        }

        // Rating Scale Breakdown (1-10) if available
        if (topic.ratingLevels.isNotEmpty()) {
          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = tr("איך לדרג את עצמך בסליידר (סולם 1–10):", "How to rate yourself on the slider (1–10 scale):"),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(8.dp))
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            topic.ratingLevels.forEach { level ->
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = level.color.copy(alpha = 0.08f),
                modifier = Modifier
                  .fillMaxWidth()
                  .border(1.dp, level.color.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.Top
                ) {
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = level.color
                  ) {
                    Text(
                      text = level.rangeLabel,
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = level.title(lang),
                      style = MaterialTheme.typography.labelMedium,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = level.description(lang),
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      lineHeight = 18.sp
                    )
                  }
                }
              }
            }
          }
        }

        // Practical Tips
        val tips = topic.tips(lang)
        if (tips.isNotEmpty()) {
          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = tr("דגשים מעשיים לתרגול ולהתבוננות:", "Practical Tips for Jam & Reflection:"),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = accentColor
          )
          Spacer(modifier = Modifier.height(6.dp))
          tips.forEach { tip ->
            Row(
              modifier = Modifier.padding(vertical = 3.dp),
              verticalAlignment = Alignment.Top
            ) {
              Text(
                text = "✦ ",
                color = LogoOrange,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = tip,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 19.sp
              )
            }
          }
        }

        // Reflection Question
        topic.question(lang)?.let { question ->
          Spacer(modifier = Modifier.height(14.dp))
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = GroundAmber.copy(alpha = 0.10f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = tr("שאלה מנחה לרפלקציה אישית:", "Guiding Question for Personal Reflection:"),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = GroundAmber
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "“$question”",
                style = MaterialTheme.typography.bodyMedium,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = onDismiss,
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = accentColor),
          modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .testTag("close_info_guide_button")
        ) {
          Text(
            text = tr("הבנתי, חזרה למסך", "Got it, Back to Screen"),
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }
    }
  }
}
