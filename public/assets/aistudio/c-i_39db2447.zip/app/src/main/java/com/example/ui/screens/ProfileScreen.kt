package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.ConversationViewMode
import com.example.data.model.DancerProfile
import com.example.data.model.RecordViewMode
import com.example.ui.components.InfoGuideButton
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr
import com.example.ui.viewmodel.ContactWaysViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
  viewModel: ContactWaysViewModel,
  isDesktopMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  val profile by viewModel.dancerProfile.collectAsState()
  val recordMode by viewModel.recordViewMode.collectAsState()
  val conversationMode by viewModel.conversationViewMode.collectAsState()
  val showEditDialog by viewModel.showProfileEditDialog.collectAsState()
  val apiKeyStatus by viewModel.deviceApiKeyStatus.collectAsState()
  val view = androidx.compose.ui.platform.LocalView.current

  if (isDesktopMode) {
    // TWO-COLUMN DESKTOP PROFILE LAYOUT
    Row(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp, vertical = 12.dp)
        .testTag("profile_screen"),
      horizontalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      Column(
        modifier = Modifier
          .weight(0.48f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        DancerHeaderCard(
          profile = profile,
          onEditClick = { viewModel.setShowProfileEditDialog(true) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        ProfileDeviceApiKeyCard(
          status = apiKeyStatus,
          onSyncFromDevice = { viewModel.resetToAutoDetectedDeviceApiKey(view.context) },
          onSaveDeviceKey = { key -> viewModel.saveDeviceApiKey(view.context, key) }
        )

        ProfileDisplayModesCard(
          recordMode = recordMode,
          onRecordModeChange = { viewModel.setRecordViewMode(it) },
          conversationMode = conversationMode,
          onConversationModeChange = { viewModel.setConversationViewMode(it) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
        Spacer(modifier = Modifier.height(24.dp))
      }

      Column(
        modifier = Modifier
          .weight(0.52f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        ProfileBoundariesCard(
          profile = profile,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        ProfileIntentionsCard(
          profile = profile,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  } else {
    // MOBILE SINGLE-COLUMN LAYOUT
    LazyColumn(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
        .testTag("profile_screen"),
      contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        DancerHeaderCard(
          profile = profile,
          onEditClick = { viewModel.setShowProfileEditDialog(true) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        ProfileDeviceApiKeyCard(
          status = apiKeyStatus,
          onSyncFromDevice = { viewModel.resetToAutoDetectedDeviceApiKey(view.context) },
          onSaveDeviceKey = { key -> viewModel.saveDeviceApiKey(view.context, key) }
        )
      }

      item {
        ProfileDisplayModesCard(
          recordMode = recordMode,
          onRecordModeChange = { viewModel.setRecordViewMode(it) },
          conversationMode = conversationMode,
          onConversationModeChange = { viewModel.setConversationViewMode(it) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        ProfileBoundariesCard(
          profile = profile,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        ProfileIntentionsCard(
          profile = profile,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }
    }
  }

  // Edit Profile Dialog
  if (showEditDialog) {
    EditProfileDialog(
      currentProfile = profile,
      onDismiss = { viewModel.setShowProfileEditDialog(false) },
      onSave = { name, bio, role, touchPref, intentions ->
        viewModel.updateDancerProfile(name, bio, role, touchPref, intentions)
      }
    )
  }
}

@Composable
private fun DancerHeaderCard(
  profile: DancerProfile,
  onEditClick: () -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          com.example.ui.components.SomaticLogoIcon(
            axisType = com.example.data.model.SomaticAxisType.WEIGHT_SHARING,
            size = 52.dp,
            showBackground = false
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = profile.name,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.width(6.dp))
              InfoGuideButton(
                topic = SomaticGuideTopic.GUIDE_PROFILE_INTENTIONS,
                onOpenGuide = onOpenGuide
              )
            }
            Text(
              text = profile.levelTitle,
              style = MaterialTheme.typography.bodySmall,
              color = SomaticPrimary,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        IconButton(
          onClick = onEditClick,
          modifier = Modifier.testTag("edit_profile_button")
        ) {
          Icon(Icons.Default.Edit, contentDescription = tr("ערוך פרופיל", "Edit profile"), tint = SomaticPrimary)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = profile.bio,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(14.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = tr("ניסיון: ${profile.yearsDanced} שנים ב-CI", "Experience: ${profile.yearsDanced} yrs in CI"),
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.outline
        )
        Text(
          text = tr("תפקיד: ${profile.primaryRole}", "Role: ${profile.primaryRole}"),
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface
        )
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProfileDisplayModesCard(
  recordMode: RecordViewMode,
  onRecordModeChange: (RecordViewMode) -> Unit,
  conversationMode: ConversationViewMode,
  onConversationModeChange: (ConversationViewMode) -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  val lang = LocalAppLanguage.current
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Tune, contentDescription = null, tint = SomaticPrimary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = tr("העדפות תצוגה בחשבון", "Display Mode Preferences"),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
        InfoGuideButton(
          topic = SomaticGuideTopic.GUIDE_RECORDS_MODES,
          onOpenGuide = onOpenGuide,
          label = tr("הסבר תצוגות", "View Guide")
        )
      }
      Text(
        text = tr(
          "בחר את אופן התצוגה המועדף עבור רשומות ותשובות לשיחות",
          "Choose your default display mode for Records and Somatic Inquiries"
        ),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = tr("אופן תצוגת רשומות ביומן:", "Journal Records View Mode:"),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(6.dp))
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        RecordViewMode.values().forEach { mode ->
          val isSelected = recordMode == mode
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) SomaticPrimary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clickable { onRecordModeChange(mode) }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (isSelected) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
              }
              Text(
                text = mode.title(lang),
                style = MaterialTheme.typography.bodySmall,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = tr("אופן תצוגת שיחות ותשובות חקירה:", "Somatic Inquiries View Mode:"),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(6.dp))
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        ConversationViewMode.values().forEach { mode ->
          val isSelected = conversationMode == mode
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) GroundAmber else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clickable { onConversationModeChange(mode) }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (isSelected) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
              }
              Text(
                text = mode.title(lang),
                style = MaterialTheme.typography.bodySmall,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ProfileBoundariesCard(
  profile: DancerProfile,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Security, contentDescription = null, tint = GroundAmber)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "הגדרת גבולות ובטיחות (תרגיל שני הנהרות)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
        InfoGuideButton(
          topic = SomaticGuideTopic.PARAM_TWO_RIVERS,
          onOpenGuide = onOpenGuide,
          tint = GroundAmber
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "על פי סדנת '101 דרכים לומר לא' של מרטין קיו: 'עד שלאדם יש את הביטחון והיכולת לומר לא, לא יהיה לו האמון לומר כן מלא'.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(12.dp))

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = GroundAmber.copy(alpha = 0.08f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(
            text = "העדפת מגע אישית מוגדרת:",
            style = MaterialTheme.typography.labelSmall,
            color = GroundAmber,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = profile.touchPreference,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }
  }
}

@Composable
private fun ProfileIntentionsCard(
  profile: DancerProfile,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "כוונות חקירה פעילות (Intentions):",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        InfoGuideButton(
          topic = SomaticGuideTopic.GUIDE_PROFILE_INTENTIONS,
          onOpenGuide = onOpenGuide
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      profile.activeIntentions.forEach { intention ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(7.dp)
              .background(SomaticPrimary, CircleShape)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = intention,
            style = MaterialTheme.typography.bodyMedium
          )
        }
      }
    }
  }
}

@Composable
fun EditProfileDialog(
  currentProfile: DancerProfile,
  onDismiss: () -> Unit,
  onSave: (name: String, bio: String, role: String, touchPref: String, intentions: List<String>) -> Unit
) {
  var name by remember { mutableStateOf(currentProfile.name) }
  var bio by remember { mutableStateOf(currentProfile.bio) }
  var role by remember { mutableStateOf(currentProfile.primaryRole) }
  var touchPref by remember { mutableStateOf(currentProfile.touchPreference) }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "סגור")
          }
          Text(
            text = "עריכת פרופיל רקדנ/ית",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
        }

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("שם מלא") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = role,
          onValueChange = { role = it },
          label = { Text("תפקיד / זיקה לתחום") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = touchPref,
          onValueChange = { touchPref = it },
          label = { Text("העדפת מגע וגבולות (שני הנהרות)") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = bio,
          onValueChange = { bio = it },
          label = { Text("תיאור אישי ורקע תנועתי") },
          modifier = Modifier.fillMaxWidth(),
          minLines = 3
        )

        Button(
          onClick = {
            onSave(name, bio, role, touchPref, currentProfile.activeIntentions)
          },
          colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(tr("שמור שינויים", "Save Changes"), fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun ProfileDeviceApiKeyCard(
  status: com.example.data.config.DeviceApiKeyStatus,
  onSyncFromDevice: () -> Unit,
  onSaveDeviceKey: (String) -> Unit
) {
  var customKeyInput by remember { mutableStateOf("") }
  var showEditField by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("device_api_key_card")
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = null,
            tint = SomaticPrimary,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = tr("מפתח API של המכשיר", "Device API Key Configuration"),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = tr(status.sourceHe, status.sourceEn),
              style = MaterialTheme.typography.labelSmall,
              color = if (status.isConfigured) Color(0xFF059669) else MaterialTheme.colorScheme.onSurfaceVariant,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = if (status.isConfigured) Color(0xFFECFDF5) else MaterialTheme.colorScheme.surfaceVariant
        ) {
          Text(
            text = status.maskedKey,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (status.isConfigured) Color(0xFF059669) else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = tr(
          "האפליקציה משתמשת אוטומטית במפתח ה-API המוגדר במכשיר המשתמש (משתנה סביבה GEMINI_API_KEY / API_KEY, מאפייני מערכת המכשיר, או אחסון מקומי במכשיר).",
          "The app automatically uses the API key defined on the user's device (Device Environment GEMINI_API_KEY / API_KEY, System Properties, or Local Device Storage)."
        ),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = SomaticPrimary.copy(alpha = 0.12f),
          modifier = Modifier
            .weight(1f)
            .clickable {
              showEditField = false
              onSyncFromDevice()
            }
            .testTag("sync_device_api_key_button")
        ) {
          Text(
            text = tr("🔄 זהה אוטומטית מהמכשיר", "🔄 Auto-Detect from Device"),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = SomaticPrimary,
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp)
          )
        }

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier
            .clickable { showEditField = !showEditField }
            .testTag("toggle_device_key_input_button")
        ) {
          Text(
            text = tr("הגדר במכשיר", "Set on Device"),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp)
          )
        }
      }

      if (showEditField) {
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = customKeyInput,
          onValueChange = { customKeyInput = it },
          label = { Text(tr("מפתח API מקומי במכשיר", "Local Device API Key")) },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("device_api_key_input")
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
          onClick = {
            onSaveDeviceKey(customKeyInput)
            customKeyInput = ""
            showEditField = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("save_device_api_key_button")
        ) {
          Text(tr("שמור מפתח במכשיר", "Save Key on Device"), fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

