package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DancerProfile
import com.example.data.model.ProgressMilestone
import com.example.data.model.SomaticProgress
import com.example.ui.components.InfoGuideButton
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.components.SomaticRadarChart
import com.example.ui.components.WeeklyActivityChart
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr
import com.example.ui.viewmodel.ContactWaysViewModel

@Composable
fun ProgressScreen(
  viewModel: ContactWaysViewModel,
  isDesktopMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  val progress by viewModel.somaticProgress.collectAsState()
  val profile by viewModel.dancerProfile.collectAsState()

  if (isDesktopMode) {
    // TWO-COLUMN DESKTOP PROGRESS DASHBOARD
    Row(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp, vertical = 12.dp)
        .testTag("progress_screen"),
      horizontalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      // Right Column in RTL (48%): Level Narrative Summary + 6-Axis Somatic Radar Chart
      Column(
        modifier = Modifier
          .weight(0.48f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        ProgressHeaderRow(onOpenGuide = { viewModel.openGuideTopic(it) })

        TextualProgressSummaryCard(
          progress = progress,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        SomaticRadarChart(
          progress = progress,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
        Spacer(modifier = Modifier.height(24.dp))
      }

      // Left Column in RTL (52%): Weekly Activity Chart + Quick Stats + Milestones
      Column(
        modifier = Modifier
          .weight(0.52f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        WeeklyActivityChart(weeklyData = progress.weeklySessions)

        ProgressQuickStatsRow(profile = profile)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = tr("אבני דרך והישגים סומטיים", "Somatic Milestones & Achievements"),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          InfoGuideButton(
            topic = SomaticGuideTopic.GUIDE_PROGRESS_WEEKLY,
            onOpenGuide = { viewModel.openGuideTopic(it) },
            label = tr("הסבר", "Guide")
          )
        }

        progress.milestones.forEach { milestone ->
          MilestoneCard(milestone = milestone)
        }
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  } else {
    // MOBILE SINGLE-COLUMN LAYOUT
    LazyColumn(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
        .testTag("progress_screen"),
      contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        ProgressHeaderRow(onOpenGuide = { viewModel.openGuideTopic(it) })
      }

      item {
        TextualProgressSummaryCard(
          progress = progress,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        SomaticRadarChart(
          progress = progress,
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )
      }

      item {
        WeeklyActivityChart(weeklyData = progress.weeklySessions)
      }

      item {
        ProgressQuickStatsRow(profile = profile)
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = tr("אבני דרך והישגים סומטיים", "Somatic Milestones & Achievements"),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          InfoGuideButton(
            topic = SomaticGuideTopic.GUIDE_PROGRESS_WEEKLY,
            onOpenGuide = { viewModel.openGuideTopic(it) },
            label = tr("הסבר", "Guide")
          )
        }
      }

      items(progress.milestones) { milestone ->
        MilestoneCard(milestone = milestone)
      }
    }
  }
}

@Composable
private fun ProgressHeaderRow(
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = tr("התקדמות סומטית: גראפית וטקסטואלית", "Somatic Progress: Radar & Narrative"),
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = tr("ניתוח מיומנויות תנועה, עקביות ג'אמים ובהירות גבולות", "Movement skills analysis, jam consistency & boundary clarity"),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
    Spacer(modifier = Modifier.width(8.dp))
    InfoGuideButton(
      topic = SomaticGuideTopic.GUIDE_PROGRESS_RADAR,
      onOpenGuide = onOpenGuide,
      label = tr("מדריך", "Guide")
    )
  }
}

@Composable
private fun TextualProgressSummaryCard(
  progress: SomaticProgress,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = tr("דרגת מודעות סומטית", "Somatic Awareness Level"),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            InfoGuideButton(
              topic = SomaticGuideTopic.GUIDE_PROGRESS_WEEKLY,
              onOpenGuide = onOpenGuide
            )
          }
          Text(
            text = progress.levelTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = SomaticPrimary.copy(alpha = 0.12f)
        ) {
          Text(
            text = "${progress.levelProgressPct.toInt()}%",
            style = MaterialTheme.typography.titleSmall,
            color = SomaticPrimary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      LinearProgressIndicator(
        progress = { progress.levelProgressPct / 100f },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp),
        color = SomaticPrimary,
        trackColor = MaterialTheme.colorScheme.surfaceVariant
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = tr("היעד הבא: ${progress.nextLevelTitle}", "Next Milestone: ${progress.nextLevelTitle}"),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(14.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = tr("סיכום התקדמות טקסטואלי:", "Narrative Progress Synthesis:"),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = progress.textualNarrative,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 22.sp
      )
    }
  }
}

@Composable
private fun ProgressQuickStatsRow(profile: DancerProfile) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 1.dp,
      modifier = Modifier.weight(1f)
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(text = "🔥 רצף", style = MaterialTheme.typography.labelSmall)
        Text(
          text = "${profile.currentStreakWeeks} שבועות",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = GroundAmber
        )
        Text(text = "ג'אם עקבי", style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
      }
    }

    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 1.dp,
      modifier = Modifier.weight(1f)
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(text = "⏱️ שעות ג'אם", style = MaterialTheme.typography.labelSmall)
        Text(
          text = "${profile.totalJamHours.toInt()} שעות",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = SomaticPrimary
        )
        Text(text = "סה״כ ביומן", style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
      }
    }

    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 1.dp,
      modifier = Modifier.weight(1f)
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(text = "💬 שיחות", style = MaterialTheme.typography.labelSmall)
        Text(
          text = "${profile.completedInquiriesCount}",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF059669)
        )
        Text(text = "חקירות הושלמו", style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
      }
    }
  }
}

@Composable
private fun MilestoneCard(milestone: ProgressMilestone) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (milestone.isUnlocked) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (milestone.isUnlocked) 1.dp else 0.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .background(
            if (milestone.isUnlocked) SomaticPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
            CircleShape
          ),
        contentAlignment = Alignment.Center
      ) {
        Text(text = milestone.iconEmoji, fontSize = 20.sp)
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = milestone.title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = milestone.unlockedDate ?: "נעול",
            style = MaterialTheme.typography.labelSmall,
            color = if (milestone.isUnlocked) Color(0xFF059669) else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = milestone.description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      Icon(
        imageVector = if (milestone.isUnlocked) Icons.Default.CheckCircle else Icons.Default.Lock,
        contentDescription = null,
        tint = if (milestone.isUnlocked) Color(0xFF059669) else MaterialTheme.colorScheme.outline,
        modifier = Modifier.size(20.dp)
      )
    }
  }
}
