package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.SomaticAxisType

// Logo-matched C-i color palette (Bright Light Skin & Soft Tones)
val LogoTeal = Color(0xFF4EB8A6)
val LogoBlue = Color(0xFF2A82C5)
val LogoOrange = Color(0xFFF36523)
val LogoBlack = Color(0xFF334155) // Soft Slate instead of pitch black
val LogoSkin = Color(0xFFFCE0C8) // Bright warm light skin tone
val LogoNavy = Color(0xFF2B3A55)
val LogoBrown = Color(0xFF9C7A63) // Warm light chestnut hair
val LogoSoftSky = Color(0xFFF0F9FF)

fun getAxisAccentColor(axisType: SomaticAxisType): Color {
  return when (axisType) {
    SomaticAxisType.ATTUNEMENT -> LogoBlue
    SomaticAxisType.WEIGHT_SHARING -> LogoOrange
    SomaticAxisType.BOUNDARIES -> Color(0xFFD97706)
    SomaticAxisType.FALLING_MOMENTUM -> Color(0xFF4F46E5)
    SomaticAxisType.GROUNDING -> LogoTeal
    SomaticAxisType.TACTILE_ATTENTION -> Color(0xFF7C3AED)
  }
}

fun mapPillarToAxisType(pillar: String): SomaticAxisType {
  return when {
    pillar.contains("משקל") -> SomaticAxisType.WEIGHT_SHARING
    pillar.contains("גבול") || pillar.contains("הסכמה") -> SomaticAxisType.BOUNDARIES
    pillar.contains("נפילה") || pillar.contains("מומנטום") -> SomaticAxisType.FALLING_MOMENTUM
    pillar.contains("הריקוד הקטן") || pillar.contains("קרקוע") -> SomaticAxisType.GROUNDING
    pillar.contains("עור") || pillar.contains("מגע") -> SomaticAxisType.TACTILE_ATTENTION
    else -> SomaticAxisType.ATTUNEMENT
  }
}

/**
 * Renders a custom mini-illustration inspired directly by the C-i logo's two dancers
 * tailored to each of the 6 somatic axes — completely frameless, without background or border.
 */
@Composable
fun SomaticLogoIcon(
  axisType: SomaticAxisType,
  modifier: Modifier = Modifier,
  size: Dp = 44.dp,
  showBackground: Boolean = false
) {
  Box(
    modifier = modifier.size(size),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.size(size)) {
      when (axisType) {
        SomaticAxisType.WEIGHT_SHARING -> drawWeightSharingDuetIcon()
        SomaticAxisType.ATTUNEMENT -> drawAttunementDuetIcon()
        SomaticAxisType.BOUNDARIES -> drawBoundariesLogoIcon()
        SomaticAxisType.FALLING_MOMENTUM -> drawFallingMomentumLogoIcon()
        SomaticAxisType.GROUNDING -> drawGroundingSmallDanceLogoIcon()
        SomaticAxisType.TACTILE_ATTENTION -> drawTactileAttentionLogoIcon()
      }
    }
  }
}

// 1. Weight Sharing: Mini version of the signature C-i arched teal + blue/orange counter-balance duet
private fun DrawScope.drawWeightSharingDuetIcon() {
  val w = size.width
  val h = size.height
  val stroke = w * 0.13f

  // Teal arch dancer
  val archPath = Path().apply {
    moveTo(w * 0.18f, h * 0.85f)
    quadraticTo(w * 0.30f, h * 0.38f, w * 0.50f, h * 0.56f)
  }
  drawPath(archPath, color = LogoTeal, style = Stroke(width = stroke, cap = StrokeCap.Round))
  drawCircle(color = LogoSkin, radius = w * 0.085f, center = Offset(w * 0.30f, h * 0.63f))

  // Orange lifted leg & counter-balance
  drawLine(
    color = LogoOrange,
    start = Offset(w * 0.54f, h * 0.44f),
    end = Offset(w * 0.88f, h * 0.16f),
    strokeWidth = stroke,
    cap = StrokeCap.Round
  )
  drawLine(
    color = LogoOrange,
    start = Offset(w * 0.56f, h * 0.48f),
    end = Offset(w * 0.84f, h * 0.66f),
    strokeWidth = stroke * 0.85f,
    cap = StrokeCap.Round
  )

  // Black standing legs
  drawLine(
    color = LogoBlack,
    start = Offset(w * 0.52f, h * 0.54f),
    end = Offset(w * 0.40f, h * 0.88f),
    strokeWidth = stroke * 0.95f,
    cap = StrokeCap.Round
  )
  drawLine(
    color = LogoBlack,
    start = Offset(w * 0.56f, h * 0.54f),
    end = Offset(w * 0.64f, h * 0.88f),
    strokeWidth = stroke * 0.95f,
    cap = StrokeCap.Round
  )

  // Blue torso & head
  drawLine(
    color = LogoBlue,
    start = Offset(w * 0.54f, h * 0.52f),
    end = Offset(w * 0.45f, h * 0.34f),
    strokeWidth = stroke * 1.35f,
    cap = StrokeCap.Round
  )
  drawCircle(color = LogoBrown, radius = w * 0.095f, center = Offset(w * 0.39f, h * 0.26f))
  drawCircle(color = LogoSkin, radius = w * 0.085f, center = Offset(w * 0.40f, h * 0.28f))
}

// 2. Somatic Attunement: Two logo-style figures leaning in mutual listening with resonance arcs
private fun DrawScope.drawAttunementDuetIcon() {
  val w = size.width
  val h = size.height
  val stroke = w * 0.13f

  // Left Teal figure
  val leftPath = Path().apply {
    moveTo(w * 0.26f, h * 0.86f)
    quadraticTo(w * 0.32f, h * 0.55f, w * 0.45f, h * 0.42f)
  }
  drawPath(leftPath, color = LogoTeal, style = Stroke(width = stroke, cap = StrokeCap.Round))
  drawCircle(color = LogoSkin, radius = w * 0.09f, center = Offset(w * 0.38f, h * 0.26f))

  // Right Blue figure
  val rightPath = Path().apply {
    moveTo(w * 0.74f, h * 0.86f)
    quadraticTo(w * 0.68f, h * 0.55f, w * 0.55f, h * 0.42f)
  }
  drawPath(rightPath, color = LogoBlue, style = Stroke(width = stroke, cap = StrokeCap.Round))
  drawCircle(color = LogoSkin, radius = w * 0.09f, center = Offset(w * 0.62f, h * 0.26f))

  // Shared orange resonance / listening point at shoulder contact
  drawCircle(color = LogoOrange, radius = w * 0.065f, center = Offset(w * 0.50f, h * 0.43f))
  drawArc(
    color = LogoOrange.copy(alpha = 0.55f),
    startAngle = 200f,
    sweepAngle = 140f,
    useCenter = false,
    topLeft = Offset(w * 0.30f, h * 0.08f),
    size = androidx.compose.ui.geometry.Size(w * 0.40f, h * 0.28f),
    style = Stroke(width = w * 0.05f, cap = StrokeCap.Round)
  )
}

// 3. Boundaries & Consent (Two Rivers): Grounded figure with clear protective orange/teal boundary arc
private fun DrawScope.drawBoundariesLogoIcon() {
  val w = size.width
  val h = size.height
  val stroke = w * 0.13f

  // Two Rivers flowing lines at base
  val river1 = Path().apply {
    moveTo(w * 0.12f, h * 0.82f)
    quadraticTo(w * 0.50f, h * 0.72f, w * 0.88f, h * 0.82f)
  }
  drawPath(river1, color = LogoTeal, style = Stroke(width = w * 0.07f, cap = StrokeCap.Round))

  // Grounded Blue/Black figure
  drawLine(
    color = LogoBlack,
    start = Offset(w * 0.42f, h * 0.58f),
    end = Offset(w * 0.36f, h * 0.84f),
    strokeWidth = stroke * 0.9f,
    cap = StrokeCap.Round
  )
  drawLine(
    color = LogoBlack,
    start = Offset(w * 0.50f, h * 0.58f),
    end = Offset(w * 0.56f, h * 0.84f),
    strokeWidth = stroke * 0.9f,
    cap = StrokeCap.Round
  )
  drawLine(
    color = LogoBlue,
    start = Offset(w * 0.46f, h * 0.56f),
    end = Offset(w * 0.46f, h * 0.36f),
    strokeWidth = stroke * 1.2f,
    cap = StrokeCap.Round
  )
  drawCircle(color = LogoSkin, radius = w * 0.09f, center = Offset(w * 0.46f, h * 0.22f))

  // Clear boundary arm gesture & orange shield arc
  drawLine(
    color = LogoBlue,
    start = Offset(w * 0.48f, h * 0.40f),
    end = Offset(w * 0.72f, h * 0.38f),
    strokeWidth = stroke * 0.75f,
    cap = StrokeCap.Round
  )
  drawArc(
    color = LogoOrange,
    startAngle = -55f,
    sweepAngle = 110f,
    useCenter = false,
    topLeft = Offset(w * 0.24f, h * 0.14f),
    size = androidx.compose.ui.geometry.Size(w * 0.62f, h * 0.62f),
    style = Stroke(width = w * 0.075f, cap = StrokeCap.Round)
  )
}

// 4. Falling & Momentum: Flowing spiral figure in blue & orange rebounding from the floor
private fun DrawScope.drawFallingMomentumLogoIcon() {
  val w = size.width
  val h = size.height
  val stroke = w * 0.12f

  // Momentum wave path (Teal)
  val wavePath = Path().apply {
    moveTo(w * 0.12f, h * 0.72f)
    cubicTo(
      w * 0.35f, h * 0.92f,
      w * 0.62f, h * 0.88f,
      w * 0.88f, h * 0.34f
    )
  }
  drawPath(wavePath, color = LogoTeal, style = Stroke(width = w * 0.08f, cap = StrokeCap.Round))

  // Rolling/Flying Blue & Orange figure
  drawLine(
    color = LogoOrange,
    start = Offset(w * 0.46f, h * 0.56f),
    end = Offset(w * 0.82f, h * 0.22f),
    strokeWidth = stroke,
    cap = StrokeCap.Round
  )
  drawLine(
    color = LogoBlue,
    start = Offset(w * 0.32f, h * 0.62f),
    end = Offset(w * 0.54f, h * 0.46f),
    strokeWidth = stroke * 1.25f,
    cap = StrokeCap.Round
  )
  drawCircle(color = LogoSkin, radius = w * 0.09f, center = Offset(w * 0.28f, h * 0.48f))
}

// 5. Grounding (The Small Dance): Upright teal/blue figure with gravity alignment & earth rings
private fun DrawScope.drawGroundingSmallDanceLogoIcon() {
  val w = size.width
  val h = size.height
  val stroke = w * 0.12f

  // Earth grounding oval at feet
  drawOval(
    color = LogoTeal.copy(alpha = 0.35f),
    topLeft = Offset(w * 0.20f, h * 0.76f),
    size = androidx.compose.ui.geometry.Size(w * 0.60f, h * 0.16f)
  )

  // Vertical plumb line of gravity
  drawLine(
    color = LogoOrange.copy(alpha = 0.6f),
    start = Offset(w * 0.50f, h * 0.10f),
    end = Offset(w * 0.50f, h * 0.88f),
    strokeWidth = w * 0.04f,
    cap = StrokeCap.Round
  )

  // Standing figure in Small Dance
  drawLine(
    color = LogoBlack,
    start = Offset(w * 0.50f, h * 0.54f),
    end = Offset(w * 0.41f, h * 0.82f),
    strokeWidth = stroke * 0.9f,
    cap = StrokeCap.Round
  )
  drawLine(
    color = LogoBlack,
    start = Offset(w * 0.50f, h * 0.54f),
    end = Offset(w * 0.59f, h * 0.82f),
    strokeWidth = stroke * 0.9f,
    cap = StrokeCap.Round
  )
  drawLine(
    color = LogoTeal,
    start = Offset(w * 0.50f, h * 0.54f),
    end = Offset(w * 0.50f, h * 0.32f),
    strokeWidth = stroke * 1.3f,
    cap = StrokeCap.Round
  )
  drawCircle(color = LogoSkin, radius = w * 0.09f, center = Offset(w * 0.50f, h * 0.20f))
}

// 6. Tactile Attention: Two limbs/shoulders meeting with warm tactile ripples
private fun DrawScope.drawTactileAttentionLogoIcon() {
  val w = size.width
  val h = size.height
  val stroke = w * 0.13f

  // Left Teal arm/shoulder reaching in
  val leftArm = Path().apply {
    moveTo(w * 0.14f, h * 0.72f)
    quadraticTo(w * 0.32f, h * 0.46f, w * 0.48f, h * 0.50f)
  }
  drawPath(leftArm, color = LogoTeal, style = Stroke(width = stroke, cap = StrokeCap.Round))

  // Right Blue/Orange arm/shoulder meeting
  val rightArm = Path().apply {
    moveTo(w * 0.86f, h * 0.30f)
    quadraticTo(w * 0.68f, h * 0.54f, w * 0.52f, h * 0.50f)
  }
  drawPath(rightArm, color = LogoBlue, style = Stroke(width = stroke, cap = StrokeCap.Round))

  // Tactile skin contact point & ripples
  val center = Offset(w * 0.50f, h * 0.50f)
  drawCircle(color = LogoSkin, radius = w * 0.095f, center = center)
  drawCircle(
    color = LogoOrange,
    radius = w * 0.19f,
    center = center,
    style = Stroke(width = w * 0.045f)
  )
  drawCircle(
    color = LogoOrange.copy(alpha = 0.4f),
    radius = w * 0.29f,
    center = center,
    style = Stroke(width = w * 0.035f)
  )
}
