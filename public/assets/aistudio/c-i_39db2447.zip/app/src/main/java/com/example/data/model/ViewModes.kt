package com.example.data.model

import com.example.ui.theme.AppLanguage
import com.example.ui.theme.trLang

enum class RecordViewMode(val titleHe: String, val titleEn: String, val iconName: String) {
  CARDS("כרטיסיות עשירות", "Rich Cards", "cards"),
  TIMELINE("ציר זמן", "Timeline", "timeline"),
  CATEGORIZED("לפי עמודי תווך", "By Pillar", "category"),
  COMPACT("טבלה קומפקטית", "Compact List", "compact");

  fun title(lang: AppLanguage): String = trLang(lang, titleHe, titleEn)
}

enum class ConversationViewMode(val titleHe: String, val titleEn: String, val iconName: String) {
  CHAT("דיאלוג צ'אט", "Chat Thread", "chat"),
  ACCORDION("שאלות ותשובות", "Q&A Accordion", "accordion"),
  INSIGHTS("תמצית תובנות", "Key Insights", "insights"),
  FLASHCARDS("כרטיסיות עיון", "Flashcards", "flashcards");

  fun title(lang: AppLanguage): String = trLang(lang, titleHe, titleEn)
}
