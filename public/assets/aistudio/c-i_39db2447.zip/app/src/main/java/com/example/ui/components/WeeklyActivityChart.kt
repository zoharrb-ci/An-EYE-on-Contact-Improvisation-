package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DaySessionData
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.SomaticPrimary

@Composable
fun WeeklyActivityChart(
  weeklyData: List<DaySessionData>,
  modifier: Modifier = Modifier
) {
  val animProgress = remember { Animatable(0f) }

  LaunchedEffect(weeklyData) {
    animProgress.snapTo(0f)
    animProgress.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing)
    )
  }

  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 2.dp,
    modifier = modifier
      .fillMaxWidth()
      .testTag("weekly_activity_chart")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "פעילות שבועית: שעות ג'אם ועומק חקירה",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          val totalHours = weeklyData.sumOf { it.hours.toDouble() }.toFloat()
          Text(
            text = "סה״כ שעות השבוע: $totalHours שעות",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Canvas(
        modifier = Modifier
          .fillMaxWidth()
          .height(160.dp)
          .padding(horizontal = 8.dp)
      ) {
        val maxHours = 3.5f
        val w = size.width
        val h = size.height - 24.dp.toPx() // Reserve space for day labels
        val barCount = weeklyData.size
        val barSlotWidth = w / barCount
        val barWidth = barSlotWidth * 0.45f
        val baselineY = h

        // Draw horizontal guide lines
        val gridLines = 3
        val gridColor = Color.LightGray.copy(alpha = 0.35f)
        for (i in 0..gridLines) {
          val y = baselineY * (i / gridLines.toFloat())
          drawLine(
            color = gridColor,
            start = Offset(0f, y),
            end = Offset(w, y),
            strokeWidth = 1.dp.toPx()
          )
        }

        val textPaint = android.graphics.Paint().apply {
          color = android.graphics.Color.GRAY
          textSize = 12.sp.toPx()
          textAlign = android.graphics.Paint.Align.CENTER
          isAntiAlias = true
        }

        val hourLabelPaint = android.graphics.Paint().apply {
          color = android.graphics.Color.DKGRAY
          textSize = 10.sp.toPx()
          textAlign = android.graphics.Paint.Align.CENTER
          isAntiAlias = true
        }

        weeklyData.forEachIndexed { index, data ->
          val slotCenterX = (index + 0.5f) * barSlotWidth
          val barLeft = slotCenterX - (barWidth / 2f)
          val targetBarHeight = (data.hours / maxHours).coerceIn(0f, 1f) * baselineY
          val animatedBarHeight = targetBarHeight * animProgress.value
          val barTop = baselineY - animatedBarHeight

          if (data.hours > 0f) {
            // Gradient fill from indigo to amber for high depth sessions
            val brush = if (data.depthRating >= 4.5f) {
              Brush.verticalGradient(listOf(GroundAmber, SomaticPrimary))
            } else {
              Brush.verticalGradient(listOf(SomaticPrimary, Color(0xFF818CF8)))
            }

            drawRoundRect(
              brush = brush,
              topLeft = Offset(barLeft, barTop),
              size = Size(barWidth, animatedBarHeight),
              cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )

            // Hour label on top of bar
            if (animProgress.value > 0.7f) {
              drawContext.canvas.nativeCanvas.drawText(
                "${data.hours}h",
                slotCenterX,
                barTop - 4.dp.toPx(),
                hourLabelPaint
              )
            }
          } else {
            // Draw empty subtle dot for rest days
            drawCircle(
              color = Color.LightGray.copy(alpha = 0.5f),
              radius = 2.dp.toPx(),
              center = Offset(slotCenterX, baselineY - 4.dp.toPx())
            )
          }

          // Day label at bottom
          drawContext.canvas.nativeCanvas.drawText(
            data.dayLabel,
            slotCenterX,
            baselineY + 18.dp.toPx(),
            textPaint
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(2.dp),
            color = SomaticPrimary,
            modifier = Modifier.height(8.dp).fillMaxWidth(0.04f)
          ) {}
          Text(
            text = " שעות ג'אם רגילות",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(2.dp),
            color = GroundAmber,
            modifier = Modifier.height(8.dp).fillMaxWidth(0.06f)
          ) {}
          Text(
            text = " עומק חקירה מירבי (4.5+)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
