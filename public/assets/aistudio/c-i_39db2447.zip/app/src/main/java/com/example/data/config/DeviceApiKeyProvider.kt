package com.example.data.config

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log
import com.example.BuildConfig

data class DeviceApiKeyStatus(
  val activeKey: String,
  val maskedKey: String,
  val sourceHe: String,
  val sourceEn: String,
  val isConfigured: Boolean
)

/**
 * Resolves and manages the API key defined on the user's device.
 *
 * Resolution order:
 * 1. Device SharedPreferences ("contact_ways_device_config" -> "device_api_key")
 * 2. Device OS Environment Variables (GEMINI_API_KEY, GOOGLE_API_KEY, API_KEY)
 * 3. Device JVM / Android System Properties (GEMINI_API_KEY, debug.gemini.api_key, persist.sys.api_key)
 * 4. Android Device Global/Secure Settings (Settings.Global / Settings.Secure "GEMINI_API_KEY")
 * 5. Android Manifest Meta-Data ("GEMINI_API_KEY")
 * 6. BuildConfig.GEMINI_API_KEY (injected via Secrets Gradle Plugin / .env)
 */
object DeviceApiKeyProvider {
  private const val TAG = "DeviceApiKeyProvider"
  private const val PREFS_NAME = "contact_ways_device_config"
  private const val KEY_DEVICE_API_KEY = "device_api_key"
  private const val PLACEHOLDER_KEY = "MY_GEMINI_API_KEY"

  @Volatile
  private var inMemoryOverrideKey: String? = null

  fun resolveApiKey(context: Context? = null): DeviceApiKeyStatus {
    // 1. Check explicit device SharedPreferences or in-memory override
    val savedPrefsKey = readFromDevicePrefs(context) ?: inMemoryOverrideKey
    if (isValidKey(savedPrefsKey)) {
      val clean = savedPrefsKey!!.trim()
      return DeviceApiKeyStatus(
        activeKey = clean,
        maskedKey = maskKey(clean),
        sourceHe = "הגדרת מפתח במכשיר (Device Storage)",
        sourceEn = "User Device Storage (SharedPreferences)",
        isConfigured = true
      )
    }

    // 2. Check Device OS Environment Variables
    val envKeys = listOf("GEMINI_API_KEY", "GOOGLE_API_KEY", "API_KEY")
    for (envName in envKeys) {
      val envVal = try {
        System.getenv(envName)
      } catch (_: Throwable) {
        null
      }
      if (isValidKey(envVal)) {
        val clean = envVal!!.trim()
        return DeviceApiKeyStatus(
          activeKey = clean,
          maskedKey = maskKey(clean),
          sourceHe = "משתנה סביבה במכשיר ($envName)",
          sourceEn = "Device Environment Variable ($envName)",
          isConfigured = true
        )
      }
    }

    // 3. Check Device System Properties & Android SystemProperties
    val propNames = listOf(
      "GEMINI_API_KEY",
      "GOOGLE_API_KEY",
      "API_KEY",
      "debug.gemini.api_key",
      "persist.sys.gemini.api_key"
    )
    for (prop in propNames) {
      val propVal = readSystemProperty(prop)
      if (isValidKey(propVal)) {
        val clean = propVal!!.trim()
        return DeviceApiKeyStatus(
          activeKey = clean,
          maskedKey = maskKey(clean),
          sourceHe = "מאפיין מערכת במכשיר ($prop)",
          sourceEn = "Device System Property ($prop)",
          isConfigured = true
        )
      }
    }

    // 4. Check Android Device Global / Secure Settings (e.g., configured on device via settings)
    val settingsVal = readFromDeviceSystemSettings(context)
    if (isValidKey(settingsVal)) {
      val clean = settingsVal!!.trim()
      return DeviceApiKeyStatus(
        activeKey = clean,
        maskedKey = maskKey(clean),
        sourceHe = "הגדרות מערכת המכשיר (Android Settings)",
        sourceEn = "Android Device System Settings",
        isConfigured = true
      )
    }

    // 5. Check Android Manifest Meta-Data
    val metaVal = readFromManifestMetaData(context)
    if (isValidKey(metaVal)) {
      val clean = metaVal!!.trim()
      return DeviceApiKeyStatus(
        activeKey = clean,
        maskedKey = maskKey(clean),
        sourceHe = "מניפסט המכשיר (Manifest Meta-Data)",
        sourceEn = "Device App Manifest Meta-Data",
        isConfigured = true
      )
    }

    // 6. Optional fallback: Check if a buildConfigKey was passed via reflection (without baking hardcoded keys into APK)
    val buildConfigKey = try {
      val field = BuildConfig::class.java.getDeclaredField("GEMINI_API_KEY")
      field.isAccessible = true
      field.get(null) as? String ?: ""
    } catch (_: Throwable) {
      ""
    }
    if (isValidKey(buildConfigKey)) {
      val clean = buildConfigKey.trim()
      return DeviceApiKeyStatus(
        activeKey = clean,
        maskedKey = maskKey(clean),
        sourceHe = "מפתח מובנה בהגדרות הבנייה (BuildConfig / Secrets)",
        sourceEn = "BuildConfig / AI Studio Secrets (.env)",
        isConfigured = true
      )
    }

    Log.i(TAG, "No custom device API key detected yet; waiting for device configuration.")
    return DeviceApiKeyStatus(
      activeKey = "",
      maskedKey = "לא הוגדר במכשיר / Not Set",
      sourceHe = "ממתין לזיהוי או הזנת מפתח במכשיר המשתמש",
      sourceEn = "Waiting for key on user's device",
      isConfigured = false
    )
  }

  fun saveDeviceApiKey(context: Context?, newKey: String): DeviceApiKeyStatus {
    val clean = newKey.trim()
    inMemoryOverrideKey = clean.ifBlank { null }
    if (context != null) {
      try {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (clean.isBlank()) {
          prefs.edit().remove(KEY_DEVICE_API_KEY).apply()
        } else {
          prefs.edit().putString(KEY_DEVICE_API_KEY, clean).apply()
        }
      } catch (_: Throwable) {
      }
    }
    return resolveApiKey(context)
  }

  fun clearCustomDeviceApiKey(context: Context?): DeviceApiKeyStatus {
    inMemoryOverrideKey = null
    if (context != null) {
      try {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
          .edit()
          .remove(KEY_DEVICE_API_KEY)
          .apply()
      } catch (_: Throwable) {
      }
    }
    return resolveApiKey(context)
  }

  private fun isValidKey(value: String?): Boolean {
    if (value.isNullOrBlank()) return false
    val trimmed = value.trim()
    return trimmed != PLACEHOLDER_KEY &&
      trimmed != "YOUR_API_KEY" &&
      trimmed != "null"
  }

  private fun maskKey(key: String): String {
    if (key.length <= 6) return "••••" + key.takeLast(2)
    return key.take(4) + "••••••••" + key.takeLast(4)
  }

  private fun readFromDevicePrefs(context: Context?): String? {
    if (context == null) return null
    return try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      prefs.getString(KEY_DEVICE_API_KEY, null)
    } catch (_: Throwable) {
      null
    }
  }

  private fun readSystemProperty(name: String): String? {
    try {
      val jvmProp = System.getProperty(name)
      if (!jvmProp.isNullOrBlank()) return jvmProp
    } catch (_: Throwable) {
    }
    return try {
      val sysPropsClass = Class.forName("android.os.SystemProperties")
      val getMethod = sysPropsClass.getMethod("get", String::class.java)
      val value = getMethod.invoke(null, name) as? String
      value?.takeIf { it.isNotBlank() }
    } catch (_: Throwable) {
      null
    }
  }

  private fun readFromDeviceSystemSettings(context: Context?): String? {
    if (context == null) return null
    return try {
      val resolver = context.contentResolver
      Settings.Global.getString(resolver, "GEMINI_API_KEY")
        ?: Settings.Global.getString(resolver, "gemini_api_key")
        ?: Settings.Secure.getString(resolver, "GEMINI_API_KEY")
        ?: Settings.Secure.getString(resolver, "gemini_api_key")
    } catch (_: Throwable) {
      null
    }
  }

  private fun readFromManifestMetaData(context: Context?): String? {
    if (context == null) return null
    return try {
      val appInfo = context.packageManager.getApplicationInfo(
        context.packageName,
        PackageManager.GET_META_DATA
      )
      val bundle = appInfo.metaData ?: return null
      bundle.getString("GEMINI_API_KEY") ?: bundle.getString("API_KEY")
    } catch (_: Throwable) {
      null
    }
  }
}
