package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.SomaticPrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddRecordDialog(
  onDismiss: () -> Unit,
  onSave: (
    title: String,
    partner: String,
    jamName: String,
    durationMinutes: Int,
    pillar: String,
    contactPoints: List<String>,
    weightShare: Float,
    attunement: Float,
    boundaryClarity: Float,
    twoRiversState: String,
    reflectionNotes: String,
    keyTakeaway: String
  ) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var partner by remember { mutableStateOf("") }
  var jamName by remember { mutableStateOf("") }
  var durationMinutes by remember { mutableIntStateOf(90) }
  var selectedPillar by remember { mutableStateOf("שיתוף משקל") }
  val availablePillars = listOf("הריקוד הקטן", "שיתוף משקל", "גבולות והסכמה", "נפילה ומומנטום", "הקשבה סומטית", "הג'אם וקהילה")

  val allContactPoints = listOf(
    "אגן ומרכז", "גב אל גב", "שכמות וכתפיים", "צלעות", "משטח הרצפה", "כפות רגליים", "מגע קל בידיים", "ראש וצוואר"
  )
  val selectedContactPoints = remember { mutableStateListOf("אגן ומרכז", "גב אל גב") }

  var weightShareRating by remember { mutableFloatStateOf(8.0f) }
  var attunementRating by remember { mutableFloatStateOf(8.5f) }
  var boundaryRating by remember { mutableFloatStateOf(9.0f) }

  var twoRiversMode by remember { mutableStateOf("מגע בכל מקום") }
  val twoRiversOptions = listOf("מגע בכל מקום", "מגע עדין בלבד", "עצירה / סימון גבול")

  var reflectionNotes by remember { mutableStateOf("") }
  var keyTakeaway by remember { mutableStateOf("") }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .heightIn(max = 700.dp)
        .padding(8.dp)
        .testTag("add_record_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "סגור")
          }
          Text(
            text = "תיעוד רשומת תנועה / ג'אם",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Scrollable Form
        Column(
          modifier = Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("כותרת הרשומה") },
            placeholder = { Text("לדוגמה: ג'אם ירושלמי - שיתוף משקל על הרצפה") },
            modifier = Modifier.fillMaxWidth().testTag("record_title_input"),
            singleLine = true
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = partner,
              onValueChange = { partner = it },
              label = { Text("פרטנר/ית לריקוד") },
              placeholder = { Text("שם או 'סולו'") },
              modifier = Modifier.weight(1f),
              singleLine = true
            )
            OutlinedTextField(
              value = jamName,
              onValueChange = { jamName = it },
              label = { Text("מסגרת / סטודיו") },
              placeholder = { Text("שם הג'אם") },
              modifier = Modifier.weight(1f),
              singleLine = true
            )
          }

          // Duration
          Column {
            Text(
              text = "משך הריקוד: $durationMinutes דקות",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold
            )
            Slider(
              value = durationMinutes.toFloat(),
              onValueChange = { durationMinutes = it.toInt() },
              valueRange = 15f..180f,
              steps = 10,
              colors = SliderDefaults.colors(thumbColor = SomaticPrimary, activeTrackColor = SomaticPrimary)
            )
          }

          // CI Pillar
          Column {
            Text(
              text = "עמוד תווך מרכזי ב-CI:",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              availablePillars.forEach { pillar ->
                val isSelected = selectedPillar == pillar
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = if (isSelected) SomaticPrimary else MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier.clickable { selectedPillar = pillar }
                ) {
                  Text(
                    text = pillar,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                  )
                }
              }
            }
          }

          // Contact Points
          Column {
            Text(
              text = "נקודות מגע בולטות (בחר כמה שרלוונטי):",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              allContactPoints.forEach { pt ->
                val isSelected = selectedContactPoints.contains(pt)
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (isSelected) GroundAmber.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                  border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, GroundAmber) else null,
                  modifier = Modifier.clickable {
                    if (isSelected) selectedContactPoints.remove(pt) else selectedContactPoints.add(pt)
                  }
                ) {
                  Text(
                    text = pt,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isSelected) GroundAmber else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                  )
                }
              }
            }
          }

          // Ratings: Weight Share, Attunement, Boundary
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
              text = "מדדים סומטיים (1-10):",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold
            )

            // Weight Sharing
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("שיתוף משקל ומומנטום:", style = MaterialTheme.typography.bodySmall)
              Text("${weightShareRating.toInt()}/10", fontWeight = FontWeight.Bold, color = SomaticPrimary)
            }
            Slider(
              value = weightShareRating,
              onValueChange = { weightShareRating = it },
              valueRange = 1f..10f,
              steps = 8
            )

            // Attunement
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("הקשבה והתכווננות (Attunement):", style = MaterialTheme.typography.bodySmall)
              Text("${attunementRating.toInt()}/10", fontWeight = FontWeight.Bold, color = Color(0xFF059669))
            }
            Slider(
              value = attunementRating,
              onValueChange = { attunementRating = it },
              valueRange = 1f..10f,
              steps = 8
            )

            // Boundary
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("בהירות גבולות והסכמה (101 דרכים):", style = MaterialTheme.typography.bodySmall)
              Text("${boundaryRating.toInt()}/10", fontWeight = FontWeight.Bold, color = GroundAmber)
            }
            Slider(
              value = boundaryRating,
              onValueChange = { boundaryRating = it },
              valueRange = 1f..10f,
              steps = 8
            )
          }

          // Two Rivers Boundary Mode
          Column {
            Text(
              text = "מצב גבולות - תרגיל שני הנהרות:",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              twoRiversOptions.forEach { opt ->
                val isSelected = twoRiversMode == opt
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (isSelected) SomaticPrimary else MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier
                    .weight(1f)
                    .clickable { twoRiversMode = opt }
                ) {
                  Text(
                    text = opt,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                  )
                }
              }
            }
          }

          // Reflections
          OutlinedTextField(
            value = reflectionNotes,
            onValueChange = { reflectionNotes = it },
            label = { Text("רפלקציה סומטית (תחושות, נשימה, מעברים)") },
            placeholder = { Text("איך הרגיש המפגש? מה קרה כשהמשקל עבר?") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
          )

          // Key Takeaway
          OutlinedTextField(
            value = keyTakeaway,
            onValueChange = { keyTakeaway = it },
            label = { Text("תובנה מרכזית לקחת הלאה") },
            placeholder = { Text("לדוגמה: לזכור להרפות את הכתפיים לפני שמעבירים משקל...") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Save Button
        Button(
          onClick = {
            onSave(
              title,
              partner,
              jamName,
              durationMinutes,
              selectedPillar,
              selectedContactPoints.toList(),
              weightShareRating,
              attunementRating,
              boundaryRating,
              twoRiversMode,
              reflectionNotes,
              keyTakeaway
            )
          },
          colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("save_record_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Add, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text("שמור רשומה ביומן התנועה", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
