package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConversationInquiry
import com.example.data.model.ConversationViewMode
import com.example.ui.components.InfoGuideButton
import com.example.ui.components.PillarChip
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr
import com.example.ui.viewmodel.ContactWaysViewModel

@Composable
fun ConversationsScreen(
  viewModel: ContactWaysViewModel,
  isDesktopMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  val inquiries by viewModel.inquiries.collectAsState()
  val viewMode by viewModel.conversationViewMode.collectAsState()
  val selectedInquiry by viewModel.selectedInquiry.collectAsState()

  val currentInquiry = selectedInquiry ?: inquiries.firstOrNull()

  if (isDesktopMode) {
    // DESKTOP MASTER-DETAIL SPLIT VIEW
    Row(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      // Right Pane in RTL (42%): Topics List + 4 Display Mode Toggles
      Column(
        modifier = Modifier
          .weight(0.42f)
          .fillMaxHeight()
      ) {
        ConversationsHeaderAndModeSelector(
          viewMode = viewMode,
          onViewModeChange = { viewModel.setConversationViewMode(it) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = tr("בחר נושא חקירה מונחה (${inquiries.size}):", "Select a Guided Inquiry Topic (${inquiries.size}):"),
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(bottom = 24.dp)
        ) {
          items(inquiries, key = { it.id }) { inq ->
            val isCurrent = inq.id == currentInquiry?.id
            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(
                containerColor = if (isCurrent) SomaticPrimary.copy(alpha = 0.10f) else MaterialTheme.colorScheme.surface
              ),
              border = if (isCurrent) BorderStroke(2.dp, SomaticPrimary) else null,
              modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.selectInquiry(inq) }
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  PillarChip(pillar = inq.category)
                  Text(
                    text = tr("${inq.messages.size} תגובות", "${inq.messages.size} replies"),
                    style = MaterialTheme.typography.labelSmall,
                    color = SomaticPrimary,
                    fontWeight = FontWeight.Bold
                  )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = inq.title,
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = inq.subtitle,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }

      // Left Pane in RTL (58%): Active Conversation / Mode Content
      Column(
        modifier = Modifier
          .weight(0.58f)
          .fillMaxHeight()
          .verticalScroll(rememberScrollState())
      ) {
        currentInquiry?.let { inquiry ->
          when (viewMode) {
            ConversationViewMode.CHAT -> ChatView(
              inquiry = inquiry,
              onSendMessage = { text -> viewModel.sendInquiryMessage(inquiry.id, text) }
            )
            ConversationViewMode.ACCORDION -> AccordionView(inquiries = inquiries)
            ConversationViewMode.INSIGHTS -> InsightsView(inquiries = inquiries)
            ConversationViewMode.FLASHCARDS -> FlashcardsView(inquiries = inquiries)
          }
        }
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  } else {
    // MOBILE SINGLE-COLUMN LAYOUT
    Column(
      modifier = modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
    ) {
      Spacer(modifier = Modifier.height(10.dp))

      ConversationsHeaderAndModeSelector(
        viewMode = viewMode,
        onViewModeChange = { viewModel.setConversationViewMode(it) },
        onOpenGuide = { viewModel.openGuideTopic(it) }
      )

      Spacer(modifier = Modifier.height(10.dp))

      LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(bottom = 80.dp)
      ) {
        item {
          Text(
            text = tr("נושא החקירה הפעיל:", "Active Inquiry Topic:"),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            inquiries.forEach { inq ->
              val isCurrent = inq.id == currentInquiry?.id
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isCurrent) SomaticPrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .weight(1f)
                  .clickable { viewModel.selectInquiry(inq) }
              ) {
                Text(
                  text = inq.title.take(18) + "...",
                  style = MaterialTheme.typography.labelSmall,
                  color = if (isCurrent) Color.White else MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                  textAlign = TextAlign.Center,
                  fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                )
              }
            }
          }
          Spacer(modifier = Modifier.height(14.dp))
        }

        currentInquiry?.let { inquiry ->
          item {
            when (viewMode) {
              ConversationViewMode.CHAT -> ChatView(
                inquiry = inquiry,
                onSendMessage = { text ->
                  viewModel.sendInquiryMessage(inquiry.id, text)
                }
              )
              ConversationViewMode.ACCORDION -> AccordionView(inquiries = inquiries)
              ConversationViewMode.INSIGHTS -> InsightsView(inquiries = inquiries)
              ConversationViewMode.FLASHCARDS -> FlashcardsView(inquiries = inquiries)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ConversationsHeaderAndModeSelector(
  viewMode: ConversationViewMode,
  onViewModeChange: (ConversationViewMode) -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  val lang = LocalAppLanguage.current
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = tr("שיחות, דיאלוגים ותשובות בחשבון", "Somatic Inquiries & Dialogues"),
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = tr(
          "חקירות מונחות סביב עקרונות הדיאלוג הנע וספרי הלימוד של CI",
          "Guided explorations rooted in Contact Improvisation literature"
        ),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
    Spacer(modifier = Modifier.width(8.dp))
    InfoGuideButton(
      topic = SomaticGuideTopic.GUIDE_INQUIRIES_MODES,
      onOpenGuide = onOpenGuide,
      label = tr("4 תצוגות", "4 Modes")
    )
  }

  Spacer(modifier = Modifier.height(12.dp))

  Surface(
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(4.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      ConversationViewMode.values().forEach { mode ->
        val isSelected = viewMode == mode
        val icon = when (mode) {
          ConversationViewMode.CHAT -> Icons.Default.Chat
          ConversationViewMode.ACCORDION -> Icons.Default.QuestionAnswer
          ConversationViewMode.INSIGHTS -> Icons.Default.Lightbulb
          ConversationViewMode.FLASHCARDS -> Icons.Default.Style
        }
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (isSelected) SomaticPrimary else Color.Transparent,
          modifier = Modifier
            .weight(1f)
            .clickable { onViewModeChange(mode) }
            .testTag("conv_mode_${mode.name.lowercase()}")
        ) {
          Column(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = icon,
              contentDescription = mode.title(lang),
              tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
              text = mode.title(lang),
              style = MaterialTheme.typography.labelSmall,
              fontSize = 10.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }
  }
}

// 1. CHAT VIEW
@Composable
private fun ChatView(
  inquiry: ConversationInquiry,
  onSendMessage: (String) -> Unit
) {
  var replyText by remember { mutableStateOf("") }

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = inquiry.category, style = MaterialTheme.typography.labelSmall, color = SomaticPrimary, fontWeight = FontWeight.Bold)
          Text(text = inquiry.authorReference, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = inquiry.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = inquiry.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }

    inquiry.messages.forEach { msg ->
      val isGuide = msg.isGuide
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isGuide) Arrangement.Start else Arrangement.End
      ) {
        if (isGuide) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .background(SomaticPrimary, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
          }
          Spacer(modifier = Modifier.width(8.dp))
        }

        Surface(
          shape = RoundedCornerShape(
            topStart = 16.dp,
            topEnd = 16.dp,
            bottomStart = if (isGuide) 4.dp else 16.dp,
            bottomEnd = if (isGuide) 16.dp else 4.dp
          ),
          color = if (isGuide) MaterialTheme.colorScheme.surfaceVariant else SomaticPrimary,
          modifier = Modifier.fillMaxWidth(0.85f)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = msg.senderName,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isGuide) SomaticPrimary else Color.White
              )
              Text(
                text = msg.timeStr,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                color = if (isGuide) MaterialTheme.colorScheme.onSurfaceVariant else Color.White.copy(alpha = 0.7f)
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = msg.text,
              style = MaterialTheme.typography.bodyMedium,
              color = if (isGuide) MaterialTheme.colorScheme.onSurface else Color.White
            )

            msg.contextTip?.let { tip ->
              Spacer(modifier = Modifier.height(6.dp))
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = SomaticPrimary.copy(alpha = 0.12f)
              ) {
                Text(
                  text = "💡 $tip",
                  style = MaterialTheme.typography.labelSmall,
                  color = SomaticPrimary,
                  modifier = Modifier.padding(4.dp)
                )
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedTextField(
        value = replyText,
        onValueChange = { replyText = it },
        placeholder = { Text("השב לשיחה עם תובנה סומטית...") },
        modifier = Modifier
          .weight(1f)
          .testTag("inquiry_reply_input"),
        shape = RoundedCornerShape(20.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = SomaticPrimary
        )
      )
      Spacer(modifier = Modifier.width(8.dp))
      IconButton(
        onClick = {
          if (replyText.isNotBlank()) {
            onSendMessage(replyText)
            replyText = ""
          }
        },
        modifier = Modifier
          .background(SomaticPrimary, CircleShape)
          .testTag("inquiry_send_button")
      ) {
        Icon(Icons.Default.Send, contentDescription = "שלח", tint = Color.White)
      }
    }
  }
}

// 2. ACCORDION VIEW
@Composable
private fun AccordionView(
  inquiries: List<ConversationInquiry>
) {
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    inquiries.forEach { inq ->
      var isExpanded by remember { mutableStateOf(false) }

      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              PillarChip(pillar = inq.category)
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = inq.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
            }
            Icon(
              imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
              contentDescription = null,
              tint = SomaticPrimary
            )
          }

          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "שאלה מנחה: ${inq.relatedStudyQuestion}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          AnimatedVisibility(visible = isExpanded) {
            Column {
              Spacer(modifier = Modifier.height(12.dp))
              HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
              Spacer(modifier = Modifier.height(10.dp))

              Text(
                text = "עיקרון סומטי:",
                style = MaterialTheme.typography.labelMedium,
                color = SomaticPrimary,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = inq.somaticPrinciple,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
              )

              Spacer(modifier = Modifier.height(10.dp))

              Text(
                text = "דיאלוג ותשובות:",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(6.dp))

              inq.messages.forEach { m ->
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (m.isGuide) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else SomaticPrimary.copy(alpha = 0.08f),
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                ) {
                  Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                      text = m.senderName,
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.Bold,
                      color = if (m.isGuide) SomaticPrimary else GroundAmber
                    )
                    Text(text = m.text, style = MaterialTheme.typography.bodySmall)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

// 3. INSIGHTS VIEW
@Composable
private fun InsightsView(
  inquiries: List<ConversationInquiry>
) {
  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    inquiries.forEach { inq ->
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = inq.title,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Icon(Icons.Default.FormatQuote, contentDescription = null, tint = GroundAmber)
          }

          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "מקור: ${inq.authorReference}",
            style = MaterialTheme.typography.labelSmall,
            color = SomaticPrimary,
            fontWeight = FontWeight.SemiBold
          )

          Spacer(modifier = Modifier.height(10.dp))

          inq.summaryInsights.forEach { insight ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
            ) {
              Text(text = "✦ ", color = GroundAmber, fontWeight = FontWeight.Bold)
              Text(
                text = insight,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }
  }
}

// 4. FLASHCARDS VIEW
@Composable
private fun FlashcardsView(
  inquiries: List<ConversationInquiry>
) {
  var currentIndex by remember { mutableIntStateOf(0) }
  var isFlipped by remember { mutableStateOf(false) }

  val card = inquiries.getOrNull(currentIndex) ?: return

  Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text(
      text = "כרטיסיה ${currentIndex + 1} מתוך ${inquiries.size}",
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.primary
    )

    Spacer(modifier = Modifier.height(12.dp))

    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(
        containerColor = if (isFlipped) SomaticPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
      ),
      elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(260.dp)
        .clickable { isFlipped = !isFlipped }
        .padding(4.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(20.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          PillarChip(pillar = card.category)
          Text(
            text = if (isFlipped) "תשובה / רפלקציה (לחץ להפיכה)" else "שאלת לימוד (לחץ להפיכה)",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        if (!isFlipped) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = card.relatedStudyQuestion,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "מחבר: ${card.authorReference}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        } else {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "עיקרון סומטי מפתח:",
              style = MaterialTheme.typography.labelMedium,
              color = SomaticPrimary,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = card.somaticPrinciple,
              style = MaterialTheme.typography.bodyMedium,
              textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = card.summaryInsights.firstOrNull() ?: "",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center
            )
          }
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(Icons.Default.Flip, contentDescription = null, tint = SomaticPrimary, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isFlipped) "הפוך לשאלה" else "הפוך לתשובה",
            style = MaterialTheme.typography.labelSmall,
            color = SomaticPrimary,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Button(
        onClick = {
          if (currentIndex > 0) {
            currentIndex--
            isFlipped = false
          }
        },
        enabled = currentIndex > 0,
        colors = ButtonDefaults.outlinedButtonColors()
      ) {
        Text("הקודם")
      }

      Button(
        onClick = {
          if (currentIndex < inquiries.size - 1) {
            currentIndex++
            isFlipped = false
          }
        },
        enabled = currentIndex < inquiries.size - 1,
        colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary)
      ) {
        Text("הבא")
      }
    }
  }
}
