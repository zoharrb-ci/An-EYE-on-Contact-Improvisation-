package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.AppLanguage
import com.example.ui.theme.DeviceLocalityInfo
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr

@Composable
fun LanguageSelectorDialog(
  currentLanguage: AppLanguage,
  availableLanguages: List<AppLanguage>,
  isIsraelLocality: Boolean,
  deviceLocalityInfo: DeviceLocalityInfo,
  onSelectLanguage: (AppLanguage) -> Unit,
  onToggleIsraelLocality: (Boolean) -> Unit,
  onDismiss: () -> Unit
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .padding(12.dp)
        .testTag("language_selector_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Language,
              contentDescription = null,
              tint = SomaticPrimary,
              modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = tr("בחירת שפה ומיקום (Locality)", "Language & Device Locality"),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = tr(
                  "עברית מוצעת בישראל בלבד • 9 שפות בינלאומיות",
                  "Hebrew offered in Israel (IL) only • 9 international languages"
                ),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = tr("סגור", "Close")
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Device Locality Status & Simulator Card
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
          border = BorderStroke(1.dp, SomaticPrimary.copy(alpha = 0.25f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = SomaticPrimary,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isIsraelLocality) {
                  tr(
                    "מיקום מכשיר פעיל: ישראל (IL) — עברית מוצעת",
                    "Active Locality: Israel (IL) — Hebrew Offered"
                  )
                } else {
                  tr(
                    "מיקום מכשיר פעיל: חו״ל (${deviceLocalityInfo.countryCode}) — עברית מוסתרת",
                    "Active Locality: Outside Israel (${deviceLocalityInfo.countryCode}) — Hebrew Hidden"
                  )
                },
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = SomaticPrimary
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = tr(
                "מזהה מכשיר: Locale ${deviceLocalityInfo.localeTag} • אזור זמן ${deviceLocalityInfo.timeZoneId}",
                "Detected Device: Locale ${deviceLocalityInfo.localeTag} • TimeZone ${deviceLocalityInfo.timeZoneId}"
              ),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Locality Switcher for testing Israel (IL) vs Outside Israel
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isIsraelLocality) SomaticPrimary else MaterialTheme.colorScheme.surface,
                border = BorderStroke(
                  1.dp,
                  if (isIsraelLocality) SomaticPrimary else MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                  .weight(1f)
                  .clickable { onToggleIsraelLocality(true) }
                  .testTag("locality_israel_button")
              ) {
                Text(
                  text = "🇮🇱 ישראל (IL)",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = if (isIsraelLocality) Color.White else MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp)
                )
              }

              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (!isIsraelLocality) SomaticPrimary else MaterialTheme.colorScheme.surface,
                border = BorderStroke(
                  1.dp,
                  if (!isIsraelLocality) SomaticPrimary else MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                  .weight(1f)
                  .clickable { onToggleIsraelLocality(false) }
                  .testTag("locality_international_button")
              ) {
                Text(
                  text = "🌍 International",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = if (!isIsraelLocality) Color.White else MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp)
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = tr(
            "שפות מוצעות למיקום הנוכחי (${availableLanguages.size}):",
            "Languages Offered for Current Locality (${availableLanguages.size}):"
          ),
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          availableLanguages.forEach { lang ->
            val isSelected = lang == currentLanguage
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = if (isSelected) SomaticPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
              border = BorderStroke(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) SomaticPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onSelectLanguage(lang)
                  onDismiss()
                }
                .testTag("select_lang_${lang.code}")
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 14.dp, vertical = 11.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = lang.flagEmoji,
                    fontSize = 20.sp
                  )
                  Spacer(modifier = Modifier.width(12.dp))
                  Column {
                    Text(
                      text = lang.displayLabel,
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.Bold,
                      color = if (isSelected) SomaticPrimary else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = lang.nativeCountry,
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) SomaticPrimary else MaterialTheme.colorScheme.surface
                  ) {
                    Text(
                      text = lang.toggleBadge,
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.ExtraBold,
                      color = if (isSelected) Color.White else SomaticPrimary,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                  if (isSelected) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                      modifier = Modifier
                        .size(22.dp)
                        .background(SomaticPrimary, CircleShape),
                      contentAlignment = Alignment.Center
                    ) {
                      Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
