package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.PillarBoundariesColor
import com.example.ui.theme.PillarFallingColor
import com.example.ui.theme.PillarJamCommunityColor
import com.example.ui.theme.PillarSmallDanceColor
import com.example.ui.theme.PillarWeightShareColor
import com.example.ui.theme.SomaticPrimary

fun getPillarColor(pillar: String): Color {
  return when {
    pillar.contains("הריקוד הקטן") || pillar.contains("קרקוע") -> PillarSmallDanceColor
    pillar.contains("משקל") -> PillarWeightShareColor
    pillar.contains("גבול") || pillar.contains("הסכמה") -> PillarBoundariesColor
    pillar.contains("נפילה") || pillar.contains("מומנטום") -> PillarFallingColor
    pillar.contains("הקשבה") || pillar.contains("סומט") -> SomaticPrimary
    pillar.contains("קהילה") || pillar.contains("אתיקה") || pillar.contains("ג'אם") -> PillarJamCommunityColor
    else -> Color(0xFF2A82C5)
  }
}

@Composable
fun PillarChip(
  pillar: String,
  isSelected: Boolean = false,
  onClick: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  val baseColor = getPillarColor(pillar)
  val axisType = mapPillarToAxisType(pillar)

  val bg = if (isSelected) baseColor else baseColor.copy(alpha = 0.12f)
  val textColor = if (isSelected) Color.White else baseColor

  Surface(
    shape = RoundedCornerShape(12.dp),
    color = bg,
    modifier = modifier.clickable(enabled = onClick != null) { onClick?.invoke() }
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      SomaticLogoIcon(
        axisType = axisType,
        size = 20.dp,
        showBackground = !isSelected
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = pillar,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
        color = textColor
      )
    }
  }
}

@Composable
fun TwoRiversBadge(
  state: String,
  modifier: Modifier = Modifier
) {
  val (color, dotColor) = when {
    state.contains("עצירה") || state.contains("לא") || state.contains("גבול") ->
      Pair(Color(0xFFFEF2F2), Color(0xFFDC2626))
    state.contains("עדין") ->
      Pair(Color(0xFFFFFBEB), GroundAmber)
    else ->
      Pair(Color(0xFFECFDF5), Color(0xFF059669))
  }

  Surface(
    shape = RoundedCornerShape(8.dp),
    color = color,
    modifier = modifier
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(7.dp)
          .background(dotColor, CircleShape)
      )
      Spacer(modifier = Modifier.width(5.dp))
      Text(
        text = "שני הנהרות: $state",
        style = MaterialTheme.typography.labelSmall,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        color = dotColor
      )
    }
  }
}
