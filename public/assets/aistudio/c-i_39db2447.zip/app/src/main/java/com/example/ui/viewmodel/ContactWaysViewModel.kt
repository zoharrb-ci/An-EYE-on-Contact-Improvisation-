package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ConversationInquiry
import com.example.data.model.ConversationViewMode
import com.example.data.model.DancerProfile
import com.example.data.model.MovementRecord
import com.example.data.model.RecordViewMode
import com.example.data.model.SomaticProgress
import com.example.data.model.SomaticRecommendation
import com.example.data.repository.ContactWaysRepository
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.theme.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppNavTab(val titleHe: String, val titleEn: String, val route: String) {
  HOME("ראשי", "Home", "home"),
  RECORDS("רשומות", "Records", "records"),
  REFLECTION("רפלקציה חדשה", "New Reflection", "reflection"),
  INQUIRIES("שיחות", "Inquiries", "inquiries"),
  PROGRESS("התקדמות", "Progress", "progress"),
  PROFILE("חשבון משתמש", "Profile", "profile");

  fun title(lang: AppLanguage): String = com.example.ui.theme.trLang(lang, titleHe, titleEn)
}

class ContactWaysViewModel(
  private val repository: ContactWaysRepository = ContactWaysRepository()
) : ViewModel() {

  val dancerProfile: StateFlow<DancerProfile> = repository.dancerProfile
  val recordViewMode: StateFlow<RecordViewMode> = repository.recordViewMode
  val conversationViewMode: StateFlow<ConversationViewMode> = repository.conversationViewMode
  val selectedPillarFilter: StateFlow<String?> = repository.selectedPillarFilter
  val somaticProgress: StateFlow<SomaticProgress> = repository.somaticProgress
  val inquiries: StateFlow<List<ConversationInquiry>> = repository.inquiries
  val recommendations: List<SomaticRecommendation> = repository.recommendations

  // Device Locality & Multilingual State (HE offered only in Israel; EN, IT, DE, ES, UK, PT worldwide)
  private val _deviceLocalityInfo = MutableStateFlow(
    com.example.ui.theme.DeviceLocalityDetector.detectDeviceLocality()
  )
  val deviceLocalityInfo: StateFlow<com.example.ui.theme.DeviceLocalityInfo> = _deviceLocalityInfo.asStateFlow()

  private val _isIsraelLocality = MutableStateFlow(true)
  val isIsraelLocality: StateFlow<Boolean> = _isIsraelLocality.asStateFlow()

  private val _availableLanguages = MutableStateFlow(
    AppLanguage.availableLanguages(isIsraelLocality = true)
  )
  val availableLanguages: StateFlow<List<AppLanguage>> = _availableLanguages.asStateFlow()

  private val _appLanguage = MutableStateFlow(AppLanguage.HE)
  val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

  private val _showLanguageSelectorDialog = MutableStateFlow(false)
  val showLanguageSelectorDialog: StateFlow<Boolean> = _showLanguageSelectorDialog.asStateFlow()

  // Device API Key Status resolved from the user's device (SharedPreferences, System Env, System Property, Android Settings, or BuildConfig)
  private val _deviceApiKeyStatus = MutableStateFlow(
    com.example.data.config.DeviceApiKeyProvider.resolveApiKey(null)
  )
  val deviceApiKeyStatus: StateFlow<com.example.data.config.DeviceApiKeyStatus> = _deviceApiKeyStatus.asStateFlow()

  private var hasAppliedDeviceLocality = false

  private val _currentTab = MutableStateFlow(AppNavTab.HOME)
  val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedRecord = MutableStateFlow<MovementRecord?>(null)
  val selectedRecord: StateFlow<MovementRecord?> = _selectedRecord.asStateFlow()

  private val _selectedInquiry = MutableStateFlow<ConversationInquiry?>(null)
  val selectedInquiry: StateFlow<ConversationInquiry?> = _selectedInquiry.asStateFlow()

  private val _selectedRecommendation = MutableStateFlow<SomaticRecommendation?>(null)
  val selectedRecommendation: StateFlow<SomaticRecommendation?> = _selectedRecommendation.asStateFlow()

  private val _showAddRecordDialog = MutableStateFlow(false)
  val showAddRecordDialog: StateFlow<Boolean> = _showAddRecordDialog.asStateFlow()

  private val _showProfileEditDialog = MutableStateFlow(false)
  val showProfileEditDialog: StateFlow<Boolean> = _showProfileEditDialog.asStateFlow()

  // Small Dance somatic meditation guide active
  private val _isSmallDanceActive = MutableStateFlow(false)
  val isSmallDanceActive: StateFlow<Boolean> = _isSmallDanceActive.asStateFlow()

  // Opening weight-transfer animation state
  private val _showIntroAnimation = MutableStateFlow(true)
  val showIntroAnimation: StateFlow<Boolean> = _showIntroAnimation.asStateFlow()

  // Desktop / Widescreen layout override (null = auto by screen width, true = force Desktop, false = force Mobile)
  private val _isDesktopModeOverride = MutableStateFlow<Boolean?>(null)
  val isDesktopModeOverride: StateFlow<Boolean?> = _isDesktopModeOverride.asStateFlow()

  // Desktop viewport scale factor (0.74f = spacious desktop monitor proportions, 0.85f = medium, 1.0f = native)
  private val _desktopZoomScale = MutableStateFlow(0.74f)
  val desktopZoomScale: StateFlow<Float> = _desktopZoomScale.asStateFlow()

  // Immersive Full-Screen mode state
  private val _isFullScreenMode = MutableStateFlow(false)
  val isFullScreenMode: StateFlow<Boolean> = _isFullScreenMode.asStateFlow()

  // Contextual Info & Guidance Modal topic
  private val _activeGuideTopic = MutableStateFlow<SomaticGuideTopic?>(null)
  val activeGuideTopic: StateFlow<SomaticGuideTopic?> = _activeGuideTopic.asStateFlow()

  // Filtered records
  val filteredRecords: StateFlow<List<MovementRecord>> = combine(
    repository.records,
    repository.selectedPillarFilter,
    _searchQuery
  ) { records: List<MovementRecord>, pillar: String?, query: String ->
    records.filter { record ->
      val matchesPillar = pillar == null || pillar == "הכל" || pillar == "All" || record.pillarCategory == pillar
      val matchesQuery = query.isBlank() ||
          record.title.contains(query, ignoreCase = true) ||
          record.partner.contains(query, ignoreCase = true) ||
          record.reflectionNotes.contains(query, ignoreCase = true) ||
          record.contactPoints.any { it.contains(query, ignoreCase = true) }
      matchesPillar && matchesQuery
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  /**
   * Detects the device's locality (Country ISO, System Locales, TimeZone, Telephony Network/SIM Country)
   * and offers Hebrew ONLY when the device locality is Israel (IL).
   * Also resolves the API key defined on the user's device.
   */
  fun detectAndApplyDeviceLocality(context: android.content.Context? = null) {
    _deviceApiKeyStatus.value = com.example.data.config.DeviceApiKeyProvider.resolveApiKey(context)
    if (hasAppliedDeviceLocality) return
    hasAppliedDeviceLocality = true

    val baseInfo = com.example.ui.theme.DeviceLocalityDetector.detectDeviceLocality()
    var isIsrael = baseInfo.isIsraelDeviceLocality
    var countryCode = baseInfo.countryCode

    if (context != null) {
      try {
        val tm = context.getSystemService(android.content.Context.TELEPHONY_SERVICE) as? android.telephony.TelephonyManager
        val netCountry = tm?.networkCountryIso?.uppercase().orEmpty()
        val simCountry = tm?.simCountryIso?.uppercase().orEmpty()
        if (netCountry == "IL" || simCountry == "IL") {
          isIsrael = true
          countryCode = "IL"
        } else if (netCountry.isNotBlank() && countryCode == "INTL") {
          countryCode = netCountry
        }
      } catch (_: Throwable) {
      }
    }

    val updatedInfo = baseInfo.copy(
      countryCode = countryCode,
      isIsraelDeviceLocality = isIsrael
    )
    _deviceLocalityInfo.value = updatedInfo
    _isIsraelLocality.value = isIsrael
    _availableLanguages.value = AppLanguage.availableLanguages(isIsraelLocality = isIsrael)
    _appLanguage.value = com.example.ui.theme.DeviceLocalityDetector.detectInitialLanguage(updatedInfo)
  }

  fun refreshDeviceApiKey(context: android.content.Context? = null) {
    _deviceApiKeyStatus.value = com.example.data.config.DeviceApiKeyProvider.resolveApiKey(context)
  }

  fun saveDeviceApiKey(context: android.content.Context? = null, key: String) {
    _deviceApiKeyStatus.value = com.example.data.config.DeviceApiKeyProvider.saveDeviceApiKey(context, key)
  }

  fun resetToAutoDetectedDeviceApiKey(context: android.content.Context? = null) {
    _deviceApiKeyStatus.value = com.example.data.config.DeviceApiKeyProvider.clearCustomDeviceApiKey(context)
  }

  fun setIsraelLocalityOverride(isIsrael: Boolean) {
    _isIsraelLocality.value = isIsrael
    val offered = AppLanguage.availableLanguages(isIsraelLocality = isIsrael)
    _availableLanguages.value = offered
    if (!isIsrael && _appLanguage.value == AppLanguage.HE) {
      _appLanguage.value = AppLanguage.EN
    } else if (isIsrael && _appLanguage.value == AppLanguage.EN) {
      _appLanguage.value = AppLanguage.HE
    }
  }

  fun setShowLanguageSelectorDialog(show: Boolean) {
    _showLanguageSelectorDialog.value = show
  }

  fun toggleLanguage() {
    val offered = _availableLanguages.value
    if (offered.isEmpty()) return
    if (_appLanguage.value == AppLanguage.HE && offered.contains(AppLanguage.EN)) {
      _appLanguage.value = AppLanguage.EN
    } else if (_appLanguage.value == AppLanguage.EN && offered.contains(AppLanguage.HE)) {
      _appLanguage.value = AppLanguage.HE
    } else {
      val currentIndex = offered.indexOf(_appLanguage.value).coerceAtLeast(0)
      _appLanguage.value = offered[(currentIndex + 1) % offered.size]
    }
  }

  fun setLanguage(lang: AppLanguage) {
    if (lang.israelOnly && !_isIsraelLocality.value) {
      // Hebrew is offered only in Israel
      return
    }
    _appLanguage.value = lang
  }

  fun selectTab(tab: AppNavTab) {
    _currentTab.value = tab
  }

  fun setRecordViewMode(mode: RecordViewMode) {
    repository.setRecordViewMode(mode)
  }

  fun setConversationViewMode(mode: ConversationViewMode) {
    repository.setConversationViewMode(mode)
  }

  fun setPillarFilter(pillar: String?) {
    repository.setPillarFilter(pillar)
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun openRecordDetails(record: MovementRecord) {
    _selectedRecord.value = record
  }

  fun closeRecordDetails() {
    _selectedRecord.value = null
  }

  fun selectInquiry(inquiry: ConversationInquiry?) {
    _selectedInquiry.value = inquiry
  }

  fun selectRecommendation(recommendation: SomaticRecommendation?) {
    _selectedRecommendation.value = recommendation
  }

  fun setShowAddRecordDialog(show: Boolean) {
    _showAddRecordDialog.value = show
  }

  fun setShowProfileEditDialog(show: Boolean) {
    _showProfileEditDialog.value = show
  }

  fun toggleSmallDanceMeditation() {
    _isSmallDanceActive.value = !_isSmallDanceActive.value
  }

  fun dismissIntroAnimation() {
    _showIntroAnimation.value = false
  }

  fun enterDesktopWidescreenPreview() {
    _isDesktopModeOverride.value = true
    _showIntroAnimation.value = false
  }

  fun replayIntroAnimation() {
    _showIntroAnimation.value = true
  }

  fun toggleDesktopMode(currentEffectiveDesktop: Boolean) {
    _isDesktopModeOverride.value = !currentEffectiveDesktop
  }

  fun cycleDesktopZoomScale() {
    _desktopZoomScale.value = when (_desktopZoomScale.value) {
      0.74f -> 0.85f
      0.85f -> 1.0f
      else -> 0.74f
    }
  }

  fun toggleFullScreenMode() {
    _isFullScreenMode.value = !_isFullScreenMode.value
  }

  fun openGuideTopic(topic: SomaticGuideTopic) {
    _activeGuideTopic.value = topic
  }

  fun closeGuideTopic() {
    _activeGuideTopic.value = null
  }

  fun sendInquiryMessage(inquiryId: String, text: String) {
    if (text.isBlank()) return
    viewModelScope.launch {
      repository.addMessageToInquiry(inquiryId, text.trim())
      val updated = repository.inquiries.value.find { it.id == inquiryId }
      _selectedInquiry.value = updated
    }
  }

  fun saveNewRecord(
    title: String,
    partner: String,
    jamName: String,
    durationMinutes: Int,
    pillar: String,
    contactPoints: List<String>,
    weightShare: Float,
    attunement: Float,
    boundaryClarity: Float,
    fallingMomentum: Float = 8.2f,
    grounding: Float = 8.8f,
    tactileAttention: Float = 8.5f,
    twoRiversState: String,
    reflectionNotes: String,
    keyTakeaway: String,
    navigateToRecordsOnSave: Boolean = false
  ) {
    val newRecord = MovementRecord(
      id = "rec-${UUID.randomUUID()}",
      title = if (title.isBlank()) "רפלקציית תנועה חדשה" else title,
      dateStr = "היום",
      jamOrWorkshop = if (jamName.isBlank()) "ג'אם מקומי" else jamName,
      partner = if (partner.isBlank()) "סולו / שותף" else partner,
      durationMinutes = durationMinutes.coerceAtLeast(15),
      pillarCategory = pillar,
      contactPoints = if (contactPoints.isEmpty()) listOf("מרכז הכובד", "גב אל גב") else contactPoints,
      weightSharingLevel = weightShare,
      attunementLevel = attunement,
      boundaryClarityLevel = boundaryClarity,
      fallingMomentumLevel = fallingMomentum,
      groundingLevel = grounding,
      tactileAttentionLevel = tactileAttention,
      twoRiversState = twoRiversState,
      reflectionNotes = if (reflectionNotes.isBlank()) "תיעוד מתוך התבוננות בששת הצירים הסומטיים." else reflectionNotes,
      keyTakeaway = if (keyTakeaway.isBlank()) "שמירה על קשב פתוח ומרכז כובד משוחרר." else keyTakeaway,
      somaticSensations = listOf("התמסרות לכוח המשיכה", "מרחב נשימה פתוח")
    )
    repository.addRecord(newRecord)
    _showAddRecordDialog.value = false
    if (navigateToRecordsOnSave) {
      _currentTab.value = AppNavTab.RECORDS
      _selectedRecord.value = newRecord
    }
  }

  fun deleteRecord(recordId: String) {
    repository.deleteRecord(recordId)
    if (_selectedRecord.value?.id == recordId) {
      _selectedRecord.value = null
    }
  }

  fun updateDancerProfile(
    name: String,
    bio: String,
    role: String,
    touchPref: String,
    intentions: List<String>
  ) {
    repository.updateProfile(name, bio, role, touchPref, intentions)
    _showProfileEditDialog.value = false
  }
}
