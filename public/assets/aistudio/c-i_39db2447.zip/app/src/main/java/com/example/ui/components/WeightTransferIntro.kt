package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.SomaticAxisType
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr

// Exact palette from the 2 illustrated C-i characters (Bright Light Skin & Soft Tones)
private val DancerTeal = Color(0xFF4EB8A6)
private val DancerNavyHair = Color(0xFF2B3A55)
private val DancerBlueShirt = Color(0xFF2A82C5)
private val DancerBlackPants = Color(0xFF334155) // Soft Slate instead of pitch black
private val DancerOrangeLeg = Color(0xFFF36523)
private val DancerBrownHair = Color(0xFF9C7A63) // Warm light chestnut hair
private val DancerSkin = Color(0xFFFCE0C8) // Bright warm light skin tone
private val SoftSkyBg = Color(0xFFF0F9FF)

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun WeightTransferIntroScreen(
  onFinished: () -> Unit,
  onEnterDesktopPreview: (() -> Unit)? = null,
  onToggleLanguage: (() -> Unit)? = null,
  availableLanguages: List<com.example.ui.theme.AppLanguage> = com.example.ui.theme.AppLanguage.entries,
  isIsraelLocality: Boolean = true,
  countryCode: String = "IL",
  onSelectLanguage: ((com.example.ui.theme.AppLanguage) -> Unit)? = null,
  onOpenLanguageDialog: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  val lang = LocalAppLanguage.current
  var replayTrigger by remember { mutableIntStateOf(0) }
  var animationComplete by remember { mutableStateOf(false) }
  var showRationaleDialog by remember { mutableStateOf(false) }
  val progressAnim = remember { Animatable(0f) }

  // Subtle continuous breathing motion at equilibrium
  val infiniteTransition = rememberInfiniteTransition(label = "equilibrium_sway")
  val sway by infiniteTransition.animateFloat(
    initialValue = -1f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "sway"
  )

  val tapPulseAlpha by infiniteTransition.animateFloat(
    initialValue = 0.65f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "tap_pulse"
  )

  LaunchedEffect(replayTrigger) {
    animationComplete = false
    progressAnim.snapTo(0f)
    progressAnim.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = 2600, easing = FastOutSlowInEasing)
    )
    // Wait for user tap to proceed instead of auto-advancing
    animationComplete = true
  }

  val t = progressAnim.value

  val phaseTitle = when {
    t < 0.33f -> tr(
      "שלב 1: הקשבה סומטית והתקרבות למרכז",
      "Phase 1: Somatic Listening & Approaching Center"
    )
    t < 0.68f -> tr(
      "שלב 2: מפגש נקודת מגע והישענות הדדית",
      "Phase 2: Rolling Point of Contact & Mutual Lean"
    )
    else -> tr(
      "שלב 3: העברת משקל מלאה ואיזון דינמי",
      "Phase 3: Full Weight Sharing & Dynamic Counterbalance"
    )
  }

  Surface(
    color = MaterialTheme.colorScheme.background,
    modifier = modifier
      .fillMaxSize()
      .clickable {
        // Clicking anywhere on the screen advances when ready (or immediately)
        onFinished()
      }
      .testTag("weight_transfer_intro_screen")
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp, vertical = 20.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      if (onToggleLanguage != null || onOpenLanguageDialog != null) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
          horizontalArrangement = Arrangement.End
        ) {
          Surface(
            shape = RoundedCornerShape(50),
            color = DancerBlueShirt.copy(alpha = 0.12f),
            border = BorderStroke(1.dp, DancerBlueShirt.copy(alpha = 0.35f)),
            modifier = Modifier
              .clickable {
                onOpenLanguageDialog?.invoke() ?: onToggleLanguage?.invoke()
              }
              .testTag("intro_language_toggle_button")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Language,
                contentDescription = tr("בחירת שפה", "Select Language"),
                tint = DancerBlueShirt,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${lang.flagEmoji} ${lang.displayLabel} ▾",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = DancerBlueShirt
              )
            }
          }
        }
      }

      // Illustrated 2-Character Weight Transfer Stage (Frameless, No Background, No Border)
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(290.dp)
          .clickable { onFinished() }
          .testTag("weight_transfer_animation_canvas"),
        contentAlignment = Alignment.Center
      ) {
        val canvasAlpha = if (t < 0.72f) 1f else ((1f - t) / 0.28f).coerceIn(0f, 1f)
        val artworkAlpha = if (t < 0.58f) 0f else ((t - 0.58f) / 0.30f).coerceIn(0f, 1f)

        if (canvasAlpha > 0.01f) {
          Canvas(
            modifier = Modifier
              .fillMaxSize()
              .padding(16.dp)
              .alpha(canvasAlpha)
          ) {
            drawArticulatedWeightTransfer(
              t = (t / 0.78f).coerceIn(0f, 1f),
              sway = sway
            )
          }
        }

        if (artworkAlpha > 0.01f) {
          val scaleProgress = 0.90f + 0.10f * artworkAlpha
          val rotationDeg = sway * 1.8f * artworkAlpha
          val translateY = sway * 3.5f * artworkAlpha

          Image(
            painter = painterResource(id = R.drawable.ci_dancers_only),
            contentDescription = tr(
              "אנימציית העברת משקל בין שתי הדמויות",
              "Weight transfer animation between two dancers"
            ),
            modifier = Modifier
              .size(230.dp)
              .alpha(artworkAlpha)
              .graphicsLayer {
                scaleX = scaleProgress
                scaleY = scaleProgress
                rotationZ = rotationDeg
                translationY = translateY
              }
          )
        }

        // Phase Indicator Text at bottom of stage (no box/border)
        Text(
          text = phaseTitle,
          style = MaterialTheme.typography.labelMedium,
          color = DancerBlueShirt,
          fontWeight = FontWeight.Bold,
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 8.dp)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Smooth progress bar of the weight-transfer sequence
      LinearProgressIndicator(
        progress = { t },
        modifier = Modifier
          .fillMaxWidth(0.65f)
          .height(5.dp),
        color = DancerOrangeLeg,
        trackColor = DancerBlueShirt.copy(alpha = 0.18f)
      )

      Spacer(modifier = Modifier.height(18.dp))

      // App Name & Description BELOW the animation
      Text(
        text = "Contact Ways — ci-eye",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground,
        textAlign = TextAlign.Center,
        modifier = Modifier.testTag("intro_app_name")
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = tr(
          "הדיאלוג הנע: חקירת מגע, תנופה ומשקל משותף",
          "The Moving Dialogue: Exploring Touch, Momentum & Shared Weight"
        ),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = SomaticPrimary,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = tr(
          "סוויטת התבוננות וחקירה עצמית לקונטקט אימפרוביזציה ודיאלוג גופני. מעקב אחר העברות משקל עדינות, נקודות מגע, גבולות ותקשורת לא-מילולית.",
          "A somatic reflection & self-inquiry suite for Contact Improvisation dancers. Track weight transfers, rolling points of contact, boundaries, and non-verbal attunement."
        ),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        lineHeight = 21.sp,
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 6.dp)
          .testTag("intro_app_description")
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Friendly Rationale & Capabilities Button
      OutlinedButton(
        onClick = { showRationaleDialog = true },
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.5.dp, DancerBlueShirt.copy(alpha = 0.55f)),
        colors = ButtonDefaults.outlinedButtonColors(
          containerColor = SoftSkyBg.copy(alpha = 0.55f),
          contentColor = DancerBlueShirt
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("intro_rationale_button")
      ) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = DancerOrangeLeg,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = tr(
            "למה Contact Ways? הרציונאל והאפשרויות שלך",
            "Why Contact Ways? Somatic Rationale & Features"
          ),
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Tap-to-continue prompt when animation finishes
      AnimatedVisibility(
        visible = animationComplete,
        enter = fadeIn(animationSpec = tween(500))
      ) {
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = DancerOrangeLeg.copy(alpha = 0.12f),
          modifier = Modifier
            .alpha(tapPulseAlpha)
            .clickable { onFinished() }
            .padding(bottom = 8.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.TouchApp,
              contentDescription = null,
              tint = DancerOrangeLeg,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = tr(
                "האנימציה הסתיימה — לחצ/י על המסך למעבר לאפליקציה",
                "Animation complete — Tap anywhere to enter the app"
              ),
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = DancerOrangeLeg
            )
          }
        }
      }

      // Controls: Replay animation or Enter App
      Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        TextButton(
          onClick = { replayTrigger++ },
          modifier = Modifier.testTag("replay_intro_button")
        ) {
          Icon(
            imageVector = Icons.Default.Replay,
            contentDescription = tr("הפעל שוב אנימציה", "Replay animation"),
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(tr("נגן שוב", "Replay"))
        }

        Button(
          onClick = onFinished,
          colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.testTag("enter_app_button")
        ) {
          Text(
            text = tr("היכנס לאפליקציה (נייד)", "Enter App (Mobile)"),
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.width(6.dp))
          Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      if (onEnterDesktopPreview != null) {
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedButton(
          onClick = onEnterDesktopPreview,
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.5.dp, DancerOrangeLeg),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = DancerOrangeLeg),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("enter_desktop_preview_button")
        ) {
          Text(
            text = tr(
              "🖥️ פתח בתצוגת מסך מחשב רחבה (סיבוב לאופקי + לוח שולחני)",
              "🖥️ Open in Desktop Widescreen Mode (Landscape 16:9 + Side Rail)"
            ),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }

  if (showRationaleDialog) {
    RationaleAndFeaturesDialog(
      onDismiss = { showRationaleDialog = false },
      onEnterApp = {
        showRationaleDialog = false
        onFinished()
      }
    )
  }
}

@Composable
fun RationaleAndFeaturesDialog(
  onDismiss: () -> Unit,
  onEnterApp: () -> Unit
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      shape = RoundedCornerShape(26.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
      modifier = Modifier
        .fillMaxWidth(0.94f)
        .heightIn(max = 680.dp)
        .padding(8.dp)
        .testTag("rationale_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            SomaticLogoIcon(
              axisType = SomaticAxisType.WEIGHT_SHARING,
              size = 40.dp
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = tr("למה Contact Ways?", "Why Contact Ways?"),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = tr("הרציונאל והאפשרויות שמחכים לך", "The Somatic Rationale & Features"),
                style = MaterialTheme.typography.labelMedium,
                color = SomaticPrimary,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = tr("סגור", "Close"))
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
          modifier = Modifier
            .weight(1f, fill = false)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Friendly Personal Rationale Box
          Surface(
            shape = RoundedCornerShape(18.dp),
            color = SoftSkyBg.copy(alpha = 0.7f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = tr(
                  "הגוף זוכר, אבל ההתבוננות מעמיקה את החופש",
                  "The body remembers, and reflection deepens freedom"
                ),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = DancerBlueShirt
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = tr(
                  "אחרי ג׳אם טוב או ריקוד מפתיע, הגוף מלא בתחושות קטנות שלעיתים נעלמות ברגע שיוצאים מהסטודיו: הרגע שבו העזת לשחרר משקל, המקום שבו סימנת גבול בבהירות וברוך, או התחושה של 'הריקוד הקטן' בכפות הרגליים.\n\nהאפליקציה נבנתה כדי להעניק לך מרחב אישי, שקט ומזמין לעצור לדקה, להתבונן בששת צירי התנועה שלך, ולגלות איך הדיאלוג הגופני שלך מתפתח מריקוד לריקוד.",
                  "After a rich jam or unexpected dance, the body is full of subtle sensations that often fade once you leave the studio: the moment you dared to pour weight, the clarity of a gentle boundary, or the feeling of 'The Small Dance' in your feet.\n\nContact Ways offers a calm, personal space to pause for a minute, reflect across the 6 movement axes, and observe how your somatic dialogue evolves from jam to jam."
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 21.sp
              )
            }
          }

          Text(
            text = tr("מה אפשר לעשות באפליקציה?", "What can you do in Contact Ways?"),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )

          // Feature 1: 6-Axis Reflection
          RationaleFeatureItem(
            axisType = SomaticAxisType.WEIGHT_SHARING,
            title = tr(
              "1. מילוי רפלקציה לפי 6 צירים (בלשונית הבולטת למטה)",
              "1. Log a 6-Axis Dance Reflection (Prominent Center Tab)"
            ),
            description = tr(
              "דירוג מהיר ואינטואיטיבי בסליידרים של הקשבה סומטית, שיתוף משקל, גבולות, מומנטום, קרקוע ותשומת לב עורית — עם מכ״ם חי שמתעצב מול עיניך ומקום לתובנה אישית.",
              "Rate Somatic Attunement, Weight Sharing, Boundaries, Momentum, Grounding, and Tactile Attention on 1–10 sliders with a live hexagonal radar and personal notes."
            )
          )

          // Feature 2: Tap-to-Reveal Somatic Recommendations
          RationaleFeatureItem(
            axisType = SomaticAxisType.GROUNDING,
            title = tr(
              "2. המלצות ותרגולים בלחיצה במסך הראשי",
              "2. Tap-to-Reveal Somatic Micro-Practices"
            ),
            description = tr(
              "בלי עומס של טקסטים — במסך הראשי מחכים לך כרטיסים מאוירים להצעות תרגול ('הריקוד הקטן', 'שני הנהרות', 'נפילה רכה'). לחיצה קצרה פותחת הנחיה מעוררת השראה לפני או אחרי ג׳אם.",
              "Clean, uncluttered practice cards ('The Small Dance', 'Two Rivers', 'Soft Falling') that open detailed somatic guidance and an interactive standing meditation timer on tap."
            )
          )

          // Feature 3: 4-Mode Records & Conversations
          RationaleFeatureItem(
            axisType = SomaticAxisType.BOUNDARIES,
            title = tr(
              "3. יומן רשומות ושיחות חקירה ב-4 אופני תצוגה",
              "3. Movement Journal & Somatic Inquiries in 4 View Modes"
            ),
            description = tr(
              "מעבר חופשי בין כרטיסיות עשירות, ציר זמן, חלוקה לעמודי תווך או תצוגה קומפקטית — לצד שיחות חקירה וכרטיסיות לימוד מתהפכות על עקרונות מרטין קיו וסטיב פקסטון.",
              "Switch seamlessly among Cards, Timeline, By Theme, and Compact views—plus interactive Q&A, insights, and flip-flashcards on Steve Paxton and Martin Keogh."
            )
          )

          // Feature 4: Visual & Textual Progress + Desktop
          RationaleFeatureItem(
            axisType = SomaticAxisType.ATTUNEMENT,
            title = tr(
              "4. מפת התקדמות + מצב מחשב שולחני דו-לשוני",
              "4. Progress Radar + Bilingual Desktop Widescreen Mode"
            ),
            description = tr(
              "מעקב חזותי במכ״ם ששת הצירים, גרף שעות ג׳אם שבועי, מצב מחשב שולחני רחב (16:9) ומעבר מיידי בין עברית לאנגלית.",
              "Track your 6-pillar radar, weekly jam hours, full Desktop Widescreen split-pane layout, and instant Hebrew/English switching."
            )
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = onEnterApp,
          colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("rationale_start_button")
        ) {
          Text(tr("בואו נתחיל לחקור", "Let's Start Exploring"), fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.width(6.dp))
          Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}

@Composable
private fun RationaleFeatureItem(
  axisType: SomaticAxisType,
  title: String,
  description: String
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.Top
    ) {
      SomaticLogoIcon(
        axisType = axisType,
        size = 42.dp
      )
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          lineHeight = 19.sp
        )
      }
    }
  }
}

private fun lerp(start: Float, stop: Float, fraction: Float): Float {
  return start + (stop - start) * fraction.coerceIn(0f, 1f)
}

private fun lerpOffset(start: Offset, stop: Offset, fraction: Float): Offset {
  val f = fraction.coerceIn(0f, 1f)
  return Offset(
    x = start.x + (stop.x - start.x) * f,
    y = start.y + (stop.y - start.y) * f
  )
}

fun DrawScope.drawArticulatedWeightTransfer(
  t: Float,
  sway: Float
) {
  val w = size.width
  val h = size.height
  val groundY = h * 0.84f
  val limbStroke = w * 0.068f
  val torsoStroke = w * 0.115f

  drawLine(
    color = DancerBlueShirt.copy(alpha = 0.15f),
    start = Offset(w * 0.15f, groundY + 6f),
    end = Offset(w * 0.85f, groundY + 6f),
    strokeWidth = 4f,
    cap = StrokeCap.Round
  )

  // --- DANCER 1 (Teal / Turquoise supporting dancer) ---
  val d1RightFoot = Offset(
    x = lerp(w * 0.36f, w * 0.48f, t),
    y = groundY * 0.98f
  )
  val d1Hip = Offset(
    x = lerp(w * 0.34f, w * 0.42f, t),
    y = lerp(h * 0.53f, h * 0.48f, t)
  )
  val d1Shoulder = Offset(
    x = lerp(w * 0.35f, w * 0.31f, t),
    y = lerp(h * 0.33f, h * 0.56f, t)
  )
  val d1Head = Offset(
    x = lerp(w * 0.36f, w * 0.33f, t),
    y = lerp(h * 0.23f, h * 0.63f, t)
  )
  val d1LeftHand = Offset(
    x = lerp(w * 0.28f, w * 0.18f, t),
    y = lerp(h * 0.48f, groundY * 0.96f, t)
  )

  drawLine(
    color = DancerTeal,
    start = d1Hip,
    end = d1RightFoot,
    strokeWidth = limbStroke,
    cap = StrokeCap.Round
  )
  drawLine(
    color = DancerSkin,
    start = d1RightFoot,
    end = Offset(d1RightFoot.x + w * 0.04f, d1RightFoot.y),
    strokeWidth = limbStroke * 0.55f,
    cap = StrokeCap.Round
  )

  val torsoPath1 = Path().apply {
    moveTo(d1Hip.x, d1Hip.y)
    quadraticTo(
      x1 = lerp(w * 0.34f, w * 0.36f, t),
      y1 = lerp(h * 0.43f, h * 0.44f, t),
      x2 = d1Shoulder.x,
      y2 = d1Shoulder.y
    )
  }
  drawPath(
    path = torsoPath1,
    color = DancerTeal,
    style = Stroke(width = torsoStroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
  )

  val armPath1 = Path().apply {
    moveTo(d1Shoulder.x, d1Shoulder.y)
    quadraticTo(
      x1 = lerp(w * 0.30f, w * 0.23f, t),
      y1 = lerp(h * 0.41f, h * 0.68f, t),
      x2 = d1LeftHand.x,
      y2 = d1LeftHand.y
    )
  }
  drawPath(
    path = armPath1,
    color = DancerTeal,
    style = Stroke(width = limbStroke * 0.82f, cap = StrokeCap.Round)
  )
  drawCircle(
    color = DancerSkin,
    radius = limbStroke * 0.38f,
    center = d1LeftHand
  )

  drawCircle(
    color = DancerNavyHair,
    radius = w * 0.046f,
    center = Offset(d1Head.x, d1Head.y + lerp(-6f, 8f, t))
  )
  drawCircle(
    color = DancerSkin,
    radius = w * 0.042f,
    center = d1Head
  )

  // --- DANCER 2 (Blue Top, Black Pants, Orange Counter-balance Leg) ---
  val d2Hip = Offset(
    x = lerp(w * 0.64f, w * 0.54f, t) + sway * 2f,
    y = lerp(h * 0.53f, h * 0.52f, t)
  )
  val d2Shoulder = Offset(
    x = lerp(w * 0.63f, w * 0.46f, t) + sway * 2f,
    y = lerp(h * 0.32f, h * 0.36f, t)
  )
  val d2Head = Offset(
    x = lerp(w * 0.62f, w * 0.40f, t) + sway * 2f,
    y = lerp(h * 0.22f, h * 0.34f, t)
  )

  val d2LeftKnee = Offset(
    x = lerp(w * 0.60f, w * 0.40f, t),
    y = lerp(h * 0.68f, h * 0.70f, t)
  )
  val d2LeftFoot = Offset(
    x = lerp(w * 0.59f, w * 0.40f, t),
    y = groundY
  )
  val d2RightFoot = Offset(
    x = lerp(w * 0.68f, w * 0.63f, t),
    y = groundY
  )

  val orangeTopFoot = Offset(
    x = lerp(w * 0.69f, w * 0.82f, t),
    y = lerp(groundY, h * 0.14f, t) + sway * 3f
  )
  val orangeLowerFoot = Offset(
    x = lerp(w * 0.67f, w * 0.79f, t),
    y = lerp(groundY * 0.95f, h * 0.64f, t)
  )

  if (t > 0.15f) {
    val orangeAlpha = ((t - 0.15f) / 0.85f).coerceIn(0f, 1f)
    val orangeHipAnchor = lerpOffset(d2Hip, Offset(w * 0.55f, h * 0.38f), t)

    drawLine(
      color = DancerOrangeLeg.copy(alpha = orangeAlpha),
      start = orangeHipAnchor,
      end = orangeTopFoot,
      strokeWidth = limbStroke * 1.1f,
      cap = StrokeCap.Round
    )
    drawCircle(
      color = DancerSkin.copy(alpha = orangeAlpha),
      radius = limbStroke * 0.42f,
      center = orangeTopFoot
    )

    drawLine(
      color = DancerOrangeLeg.copy(alpha = orangeAlpha),
      start = orangeHipAnchor,
      end = orangeLowerFoot,
      strokeWidth = limbStroke * 0.92f,
      cap = StrokeCap.Round
    )
    drawCircle(
      color = DancerSkin.copy(alpha = orangeAlpha),
      radius = limbStroke * 0.40f,
      center = orangeLowerFoot
    )
  }

  val leftLegPath = Path().apply {
    moveTo(d2Hip.x, d2Hip.y)
    lineTo(d2LeftKnee.x, d2LeftKnee.y)
    lineTo(d2LeftFoot.x, d2LeftFoot.y)
  }
  drawPath(
    path = leftLegPath,
    color = DancerBlackPants,
    style = Stroke(width = limbStroke * 1.05f, cap = StrokeCap.Round, join = StrokeJoin.Round)
  )
  drawLine(
    color = DancerBlackPants,
    start = d2Hip,
    end = d2RightFoot,
    strokeWidth = limbStroke * 1.05f,
    cap = StrokeCap.Round
  )
  drawCircle(color = DancerSkin, radius = limbStroke * 0.42f, center = d2LeftFoot)
  drawCircle(color = DancerSkin, radius = limbStroke * 0.42f, center = d2RightFoot)

  drawLine(
    color = DancerBlueShirt,
    start = d2Hip,
    end = d2Shoulder,
    strokeWidth = torsoStroke * 1.15f,
    cap = StrokeCap.Round
  )

  val d2Hand = Offset(
    x = lerp(w * 0.56f, w * 0.46f, t),
    y = lerp(h * 0.48f, h * 0.73f, t)
  )
  drawLine(
    color = DancerBlueShirt,
    start = Offset(d2Shoulder.x - w * 0.04f, d2Shoulder.y + h * 0.04f),
    end = d2Hand,
    strokeWidth = limbStroke * 0.78f,
    cap = StrokeCap.Round
  )
  drawCircle(color = DancerSkin, radius = limbStroke * 0.35f, center = d2Hand)

  drawCircle(
    color = DancerBrownHair,
    radius = w * 0.052f,
    center = Offset(d2Head.x - 3f, d2Head.y - 6f)
  )
  drawCircle(
    color = DancerSkin,
    radius = w * 0.044f,
    center = d2Head
  )

  val contactPoint = lerpOffset(d1Shoulder, d2Shoulder, 0.5f)
  val pulseAlpha = (1f - kotlin.math.abs(t - 0.55f) * 2.2f).coerceIn(0f, 0.65f)
  if (pulseAlpha > 0.05f) {
    drawCircle(
      color = DancerOrangeLeg.copy(alpha = pulseAlpha * 0.35f),
      radius = w * 0.09f,
      center = contactPoint
    )
    drawCircle(
      color = DancerOrangeLeg.copy(alpha = pulseAlpha),
      radius = w * 0.025f,
      center = contactPoint
    )
  }
}
