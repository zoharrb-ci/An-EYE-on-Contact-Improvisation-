package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.EarthSage
import com.example.ui.theme.SomaticPrimary

@Composable
fun SmallDanceMeditationDialog(
  onDismiss: () -> Unit
) {
  val infiniteTransition = rememberInfiniteTransition(label = "breath")
  val breathScale by infiniteTransition.animateFloat(
    initialValue = 0.85f,
    targetValue = 1.25f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 4000, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "breathScale"
  )

  var currentStepIndex by remember { mutableIntStateOf(0) }
  val meditationSteps = listOf(
    "עמוד בפיסוק נוח ברוחב האגן. שחרר את הברכיים כך שלא תהיינה נעולות.",
    "הפנה את תשומת הלב לכפות הרגליים: חוש את המשקל מתחלק בין העקב, הבוהן והקשת.",
    "שים לב שאינך באמת דומם: השלד מבצע מיקרו-התאמות מתמידות כנגד כוח המשיכה.",
    "זהו 'הריקוד הקטן' (The Small Dance). שחרר שליטה שכלית, ואפשר לאדמה להחזיק אותך."
  )

  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
        .testTag("small_dance_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "סגור")
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "תרגול הריקוד הקטן",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.Default.Spa, contentDescription = null, tint = EarthSage)
          }
        }

        Text(
          text = "סטיב פקסטון (1972) • 'מצב של אמון בגוף ובאדמה'",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Breathing Visualizer Box
        Box(
          modifier = Modifier
            .size(160.dp),
          contentAlignment = Alignment.Center
        ) {
          Box(
            modifier = Modifier
              .size(140.dp)
              .scale(breathScale)
              .background(
                brush = Brush.radialGradient(
                  listOf(
                    EarthSage.copy(alpha = 0.4f),
                    SomaticPrimary.copy(alpha = 0.1f),
                    Color.Transparent
                  )
                ),
                shape = CircleShape
              )
          )

          Box(
            modifier = Modifier
              .size(80.dp)
              .background(EarthSage.copy(alpha = 0.25f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = if (breathScale > 1.05f) "שאיפה" else "נשיפה",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              color = EarthSage
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Step Card
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "שלב ${currentStepIndex + 1} מתוך ${meditationSteps.size}",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = meditationSteps[currentStepIndex],
              style = MaterialTheme.typography.bodyMedium,
              textAlign = TextAlign.Center,
              lineHeight = 22.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Button(
            onClick = {
              if (currentStepIndex > 0) currentStepIndex--
            },
            enabled = currentStepIndex > 0,
            colors = ButtonDefaults.outlinedButtonColors()
          ) {
            Text("הקודם")
          }

          if (currentStepIndex < meditationSteps.size - 1) {
            Button(
              onClick = { currentStepIndex++ },
              colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary)
            ) {
              Text("השלב הבא")
            }
          } else {
            Button(
              onClick = onDismiss,
              colors = ButtonDefaults.buttonColors(containerColor = EarthSage)
            ) {
              Text("סיום וחזרה")
            }
          }
        }
      }
    }
  }
}
