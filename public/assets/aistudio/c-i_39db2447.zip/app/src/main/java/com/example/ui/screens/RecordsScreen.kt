package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewHeadline
import androidx.compose.material.icons.filled.ViewKanban
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MovementRecord
import com.example.data.model.RecordViewMode
import com.example.data.model.SomaticAxisType
import com.example.ui.components.AddRecordDialog
import com.example.ui.components.InfoGuideButton
import com.example.ui.components.LogoBlue
import com.example.ui.components.LogoOrange
import com.example.ui.components.LogoTeal
import com.example.ui.components.PillarChip
import com.example.ui.components.RecordDetailDialog
import com.example.ui.components.SomaticGuideTopic
import com.example.ui.components.SomaticLogoIcon
import com.example.ui.components.TwoRiversBadge
import com.example.ui.components.getAxisGuideTopic
import com.example.ui.components.getPillarColor
import com.example.ui.theme.GroundAmber
import com.example.ui.theme.LocalAppLanguage
import com.example.ui.theme.SomaticPrimary
import com.example.ui.theme.tr
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.ContactWaysViewModel

@Composable
fun RecordsScreen(
  viewModel: ContactWaysViewModel,
  isDesktopMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  val records by viewModel.filteredRecords.collectAsState()
  val viewMode by viewModel.recordViewMode.collectAsState()
  val selectedPillar by viewModel.selectedPillarFilter.collectAsState()
  val searchQuery by viewModel.searchQuery.collectAsState()
  val selectedRecord by viewModel.selectedRecord.collectAsState()
  val showAddDialog by viewModel.showAddRecordDialog.collectAsState()

  var showSearchField by remember { mutableStateOf(false) }

  val filterCategories = listOf("הכל", "הריקוד הקטן", "שיתוף משקל", "גבולות והסכמה", "נפילה ומומנטום", "הקשבה סומטית", "תשומת לב עורית")

  val activeDesktopRecord = selectedRecord ?: records.firstOrNull()

  Scaffold(
    floatingActionButton = {
      if (!isDesktopMode) {
        FloatingActionButton(
          onClick = { viewModel.selectTab(AppNavTab.REFLECTION) },
          containerColor = SomaticPrimary,
          contentColor = Color.White,
          modifier = Modifier.testTag("add_record_fab")
        ) {
          Icon(Icons.Default.Add, contentDescription = tr("רפלקציה חדשה", "New Reflection"))
        }
      }
    },
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    if (isDesktopMode) {
      // DESKTOP MASTER-DETAIL SPLIT VIEW
      Row(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp)
      ) {
        // Right Pane (52%): Filterable & Searchable List
        Column(
          modifier = Modifier
            .weight(0.52f)
            .fillMaxHeight()
        ) {
          RecordsListHeaderAndFilters(
            recordsCount = records.size,
            showSearchField = showSearchField,
            onToggleSearch = { showSearchField = !showSearchField },
            searchQuery = searchQuery,
            onSearchQueryChange = { viewModel.setSearchQuery(it) },
            viewMode = viewMode,
            onViewModeChange = { viewModel.setRecordViewMode(it) },
            filterCategories = filterCategories,
            selectedPillar = selectedPillar,
            onPillarFilterChange = { viewModel.setPillarFilter(it) },
            onOpenGuide = { viewModel.openGuideTopic(it) }
          )

          Spacer(modifier = Modifier.height(10.dp))

          if (records.isEmpty()) {
            EmptyRecordsState(onNewReflection = { viewModel.selectTab(AppNavTab.REFLECTION) })
          } else {
            when (viewMode) {
              RecordViewMode.CARDS -> CardsView(
                records = records,
                selectedRecordId = activeDesktopRecord?.id,
                onRecordClick = { viewModel.openRecordDetails(it) }
              )
              RecordViewMode.TIMELINE -> TimelineView(records = records, onRecordClick = { viewModel.openRecordDetails(it) })
              RecordViewMode.CATEGORIZED -> CategorizedView(records = records, onRecordClick = { viewModel.openRecordDetails(it) })
              RecordViewMode.COMPACT -> CompactView(records = records, onRecordClick = { viewModel.openRecordDetails(it) })
            }
          }
        }

        // Left Pane (48%): Embedded Full Record Detail Pane with 6 Axes & Info Buttons
        Box(
          modifier = Modifier
            .weight(0.48f)
            .fillMaxHeight()
        ) {
          if (activeDesktopRecord != null) {
            RecordDetailSidePane(
              record = activeDesktopRecord,
              onOpenGuide = { viewModel.openGuideTopic(it) },
              onDelete = { viewModel.deleteRecord(it) },
              onNewReflection = { viewModel.selectTab(AppNavTab.REFLECTION) }
            )
          } else {
            Card(
              shape = RoundedCornerShape(22.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              modifier = Modifier.fillMaxSize()
            ) {
              Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                  text = tr("בחר רשומה מהרשימה לצפייה בפירוט 6 הצירים", "Select a record from the list to inspect its 6 axes"),
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }
    } else {
      // MOBILE SINGLE-PANE VIEW
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .padding(horizontal = 16.dp)
      ) {
        Spacer(modifier = Modifier.height(8.dp))

        RecordsListHeaderAndFilters(
          recordsCount = records.size,
          showSearchField = showSearchField,
          onToggleSearch = { showSearchField = !showSearchField },
          searchQuery = searchQuery,
          onSearchQueryChange = { viewModel.setSearchQuery(it) },
          viewMode = viewMode,
          onViewModeChange = { viewModel.setRecordViewMode(it) },
          filterCategories = filterCategories,
          selectedPillar = selectedPillar,
          onPillarFilterChange = { viewModel.setPillarFilter(it) },
          onOpenGuide = { viewModel.openGuideTopic(it) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (records.isEmpty()) {
          EmptyRecordsState(onNewReflection = { viewModel.selectTab(AppNavTab.REFLECTION) })
        } else {
          when (viewMode) {
            RecordViewMode.CARDS -> CardsView(
              records = records,
              selectedRecordId = null,
              onRecordClick = { viewModel.openRecordDetails(it) }
            )
            RecordViewMode.TIMELINE -> TimelineView(records = records, onRecordClick = { viewModel.openRecordDetails(it) })
            RecordViewMode.CATEGORIZED -> CategorizedView(records = records, onRecordClick = { viewModel.openRecordDetails(it) })
            RecordViewMode.COMPACT -> CompactView(records = records, onRecordClick = { viewModel.openRecordDetails(it) })
          }
        }
      }
    }
  }

  // Record Detail Modal (only in Mobile Mode)
  if (!isDesktopMode) {
    selectedRecord?.let { rec ->
      RecordDetailDialog(
        record = rec,
        onDismiss = { viewModel.closeRecordDetails() },
        onDelete = {
          viewModel.deleteRecord(it)
        }
      )
    }
  }

  // Add Record Modal
  if (showAddDialog) {
    AddRecordDialog(
      onDismiss = { viewModel.setShowAddRecordDialog(false) },
      onSave = { title, partner, jam, dur, pillar, pts, w, att, b, twoR, notes, takeaway ->
        viewModel.saveNewRecord(
          title = title,
          partner = partner,
          jamName = jam,
          durationMinutes = dur,
          pillar = pillar,
          contactPoints = pts,
          weightShare = w,
          attunement = att,
          boundaryClarity = b,
          fallingMomentum = 8.0f,
          grounding = 8.0f,
          tactileAttention = 8.0f,
          twoRiversState = twoR,
          reflectionNotes = notes,
          keyTakeaway = takeaway
        )
      }
    )
  }
}

@Composable
private fun RecordsListHeaderAndFilters(
  recordsCount: Int,
  showSearchField: Boolean,
  onToggleSearch: () -> Unit,
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  viewMode: RecordViewMode,
  onViewModeChange: (RecordViewMode) -> Unit,
  filterCategories: List<String>,
  selectedPillar: String?,
  onPillarFilterChange: (String) -> Unit,
  onOpenGuide: (SomaticGuideTopic) -> Unit
) {
  val lang = LocalAppLanguage.current
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = tr("יומן רשומות תנועה", "Movement Reflections Journal"),
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(8.dp))
        InfoGuideButton(
          topic = SomaticGuideTopic.GUIDE_RECORDS_MODES,
          onOpenGuide = onOpenGuide,
          label = tr("4 תצוגות", "4 Views")
        )
      }
      Text(
        text = tr("$recordsCount רשומות מתועדות בג'אמים וסדנאות", "$recordsCount sessions logged across jams & workshops"),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    IconButton(onClick = onToggleSearch) {
      Icon(Icons.Default.Search, contentDescription = tr("חיפוש רשומות", "Search records"), tint = SomaticPrimary)
    }
  }

  AnimatedVisibility(visible = showSearchField) {
    Column {
      Spacer(modifier = Modifier.height(8.dp))
      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchQueryChange,
        placeholder = { Text(tr("חיפוש לפי פרטנר, תחושה, גבול...", "Search by partner, sensation, boundary...")) },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("records_search_input"),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = SomaticPrimary,
          unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        )
      )
    }
  }

  Spacer(modifier = Modifier.height(10.dp))

  // Mode Selector Bar (4 display modes)
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(4.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      RecordViewMode.values().forEach { mode ->
        val isSelected = viewMode == mode
        val icon = when (mode) {
          RecordViewMode.CARDS -> Icons.Default.ViewAgenda
          RecordViewMode.TIMELINE -> Icons.Default.CalendarMonth
          RecordViewMode.CATEGORIZED -> Icons.Default.ViewKanban
          RecordViewMode.COMPACT -> Icons.Default.ViewHeadline
        }
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (isSelected) SomaticPrimary else Color.Transparent,
          modifier = Modifier
            .weight(1f)
            .clickable { onViewModeChange(mode) }
            .testTag("mode_${mode.name.lowercase()}")
        ) {
          Column(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = icon,
              contentDescription = mode.title(lang),
              tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
              text = mode.title(lang),
              style = MaterialTheme.typography.labelSmall,
              fontSize = 10.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }
  }

  Spacer(modifier = Modifier.height(8.dp))

  LazyRow(
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    contentPadding = PaddingValues(vertical = 4.dp)
  ) {
    items(filterCategories) { pillar ->
      val isSelected = (pillar == "הכל" && (selectedPillar == null || selectedPillar == "הכל")) || selectedPillar == pillar
      PillarChip(
        pillar = pillar,
        isSelected = isSelected,
        onClick = { onPillarFilterChange(pillar) }
      )
    }
  }
}

@Composable
private fun EmptyRecordsState(onNewReflection: () -> Unit) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = tr("לא נמצאו רשומות מתאימות", "No matching records found"),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(8.dp))
      Button(
        onClick = onNewReflection,
        colors = ButtonDefaults.buttonColors(containerColor = SomaticPrimary)
      ) {
        Text(tr("מילוי רפלקציה ראשונה", "Log First Reflection"))
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RecordDetailSidePane(
  record: MovementRecord,
  onOpenGuide: (SomaticGuideTopic) -> Unit,
  onDelete: (String) -> Unit,
  onNewReflection: () -> Unit
) {
  val axesList = listOf(
    Triple(SomaticAxisType.ATTUNEMENT, record.attunementLevel, LogoBlue),
    Triple(SomaticAxisType.WEIGHT_SHARING, record.weightSharingLevel, LogoOrange),
    Triple(SomaticAxisType.BOUNDARIES, record.boundaryClarityLevel, GroundAmber),
    Triple(SomaticAxisType.FALLING_MOMENTUM, record.fallingMomentumLevel, SomaticPrimary),
    Triple(SomaticAxisType.GROUNDING, record.groundingLevel, LogoTeal),
    Triple(SomaticAxisType.TACTILE_ATTENTION, record.tactileAttentionLevel, Color(0xFF7C3AED))
  )

  Card(
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    modifier = Modifier
      .fillMaxSize()
      .testTag("desktop_record_detail_pane")
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(20.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        PillarChip(pillar = record.pillarCategory)
        TwoRiversBadge(state = record.twoRiversState)
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = record.title,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = "📅 ${record.dateStr}  •  📍 ${record.jamOrWorkshop}  •  👥 פרטנר: ${record.partner} (${record.durationMinutes} דק׳)",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(14.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "דירוג ששת צירי המכ״ם הסומטי בריקוד:",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold
        )
        InfoGuideButton(
          topic = SomaticGuideTopic.GUIDE_PROGRESS_RADAR,
          onOpenGuide = onOpenGuide,
          label = "הסבר הצירים"
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        axesList.chunked(2).forEach { pair ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            pair.forEach { (axisType, score, color) ->
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = color.copy(alpha = 0.08f),
                modifier = Modifier
                  .weight(1f)
                  .clickable { onOpenGuide(getAxisGuideTopic(axisType)) }
              ) {
                Row(
                  modifier = Modifier.padding(8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    SomaticLogoIcon(axisType = axisType, size = 28.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = axisType.shortLabelHe,
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.SemiBold
                    )
                  }
                  Text(
                    text = "${score.toInt()}/10",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = color
                  )
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "הערת רפלקציה מלאה:",
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = record.reflectionNotes,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface,
        lineHeight = 22.sp
      )

      Spacer(modifier = Modifier.height(12.dp))

      Surface(
        shape = RoundedCornerShape(14.dp),
        color = GroundAmber.copy(alpha = 0.1f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "💡 תובנה מרכזית (Key Takeaway):",
            style = MaterialTheme.typography.labelMedium,
            color = GroundAmber,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "״${record.keyTakeaway}״",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = "נקודות מגע מרכזיות:",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(6.dp))
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        record.contactPoints.forEach { pt ->
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
          ) {
            Text(
              text = pt,
              style = MaterialTheme.typography.labelSmall,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedButton(
          onClick = { onDelete(record.id) },
          colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
          modifier = Modifier.weight(0.4f)
        ) {
          Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("מחק")
        }

        Button(
          onClick = onNewReflection,
          colors = ButtonDefaults.buttonColors(containerColor = LogoOrange),
          modifier = Modifier.weight(0.6f)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("רפלקציה חדשה", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

// 1. CARDS VIEW
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CardsView(
  records: List<MovementRecord>,
  selectedRecordId: String?,
  onRecordClick: (MovementRecord) -> Unit
) {
  LazyColumn(
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(bottom = 80.dp)
  ) {
    items(records, key = { it.id }) { record ->
      val isSelected = record.id == selectedRecordId
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (isSelected) BorderStroke(2.dp, SomaticPrimary) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onRecordClick(record) }
          .testTag("record_card_${record.id}")
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            TwoRiversBadge(state = record.twoRiversState)
            PillarChip(pillar = record.pillarCategory)
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = record.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(4.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "👥 פרטנר: ${record.partner}",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = SomaticPrimary
            )
            Text(
              text = "⏱️ ${record.durationMinutes} דק' • ${record.dateStr}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = GroundAmber.copy(alpha = 0.08f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "״${record.keyTakeaway}״",
              style = MaterialTheme.typography.bodySmall,
              fontStyle = FontStyle.Italic,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(10.dp)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            record.contactPoints.take(3).forEach { pt ->
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
              ) {
                Text(
                  text = pt,
                  style = MaterialTheme.typography.labelSmall,
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
              }
            }
            if (record.contactPoints.size > 3) {
              Text(
                text = "+${record.contactPoints.size - 3}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterVertically)
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "משקל: ${record.weightSharingLevel.toInt()}/10 • הקשבה: ${record.attunementLevel.toInt()}/10 • גבול: ${record.boundaryClarityLevel.toInt()}/10",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.outline
            )
            Text(
              text = "פרטים מלאים ›",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = SomaticPrimary
            )
          }
        }
      }
    }
  }
}

// 2. TIMELINE VIEW
@Composable
private fun TimelineView(
  records: List<MovementRecord>,
  onRecordClick: (MovementRecord) -> Unit
) {
  LazyColumn(
    contentPadding = PaddingValues(bottom = 80.dp)
  ) {
    items(records, key = { it.id }) { record ->
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onRecordClick(record) }
          .padding(vertical = 4.dp)
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.width(36.dp)
        ) {
          Box(
            modifier = Modifier
              .size(14.dp)
              .background(getPillarColor(record.pillarCategory), CircleShape)
          )
          Box(
            modifier = Modifier
              .width(2.dp)
              .height(110.dp)
              .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
          )
        }

        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier
            .weight(1f)
            .padding(bottom = 12.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = record.dateStr,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${record.durationMinutes} דק'",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = record.title,
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = record.reflectionNotes,
              style = MaterialTheme.typography.bodySmall,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }
  }
}

// 3. CATEGORIZED VIEW
@Composable
private fun CategorizedView(
  records: List<MovementRecord>,
  onRecordClick: (MovementRecord) -> Unit
) {
  val grouped = remember(records) { records.groupBy { it.pillarCategory } }

  LazyColumn(
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(bottom = 80.dp)
  ) {
    grouped.forEach { (category, catRecords) ->
      item {
        Column {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(vertical = 4.dp)
          ) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .background(getPillarColor(category), CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "$category (${catRecords.size})",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
          }

          catRecords.forEach { rec ->
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clickable { onRecordClick(rec) }
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = rec.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                  Text(
                    text = "עם ${rec.partner} • ${rec.dateStr}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = SomaticPrimary.copy(alpha = 0.1f)
                ) {
                  Text(
                    text = "עומק ${rec.attunementLevel.toInt()}/10",
                    style = MaterialTheme.typography.labelSmall,
                    color = SomaticPrimary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

// 4. COMPACT VIEW
@Composable
private fun CompactView(
  records: List<MovementRecord>,
  onRecordClick: (MovementRecord) -> Unit
) {
  LazyColumn(
    verticalArrangement = Arrangement.spacedBy(8.dp),
    contentPadding = PaddingValues(bottom = 80.dp)
  ) {
    items(records, key = { it.id }) { record ->
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onRecordClick(record) }
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .background(getPillarColor(record.pillarCategory), CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = record.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              Text(
                text = "${record.dateStr} • ${record.partner} • ${record.twoRiversState}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }

          Spacer(modifier = Modifier.width(8.dp))

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = SomaticPrimary.copy(alpha = 0.12f)
          ) {
            Text(
              text = "${record.durationMinutes} דק'",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = SomaticPrimary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }
    }
  }
}
