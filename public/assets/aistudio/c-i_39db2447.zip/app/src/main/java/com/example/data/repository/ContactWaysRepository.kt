package com.example.data.repository

import com.example.data.model.ConversationInquiry
import com.example.data.model.ConversationViewMode
import com.example.data.model.DancerProfile
import com.example.data.model.DaySessionData
import com.example.data.model.InquiryMessage
import com.example.data.model.MovementRecord
import com.example.data.model.ProgressMilestone
import com.example.data.model.RecordViewMode
import com.example.data.model.SomaticAxisType
import com.example.data.model.SomaticProgress
import com.example.data.model.SomaticRecommendation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class ContactWaysRepository {

  private val _dancerProfile = MutableStateFlow(
    DancerProfile(
      name = "זוהר בר-און",
      levelTitle = "רקדנ/ית קשוב/ה ומבוסס/ת",
      bio = "חוקר/ת תנועה וקונטקט אימפרוביזציה מזה 4 שנים. מתמקדת בדיאלוג סומטי עדין, גבולות בטוחים בריקוד ומפגש מרכז-משקל.",
      yearsDanced = 4.2f,
      primaryRole = "חוקר/ת תנועה וג'אמר/ית",
      touchPreference = "פתוח/ה למגוון רמות מגע עם תשומת לב הדדית וקשב לשני הנהרות",
      activeIntentions = listOf(
        "חידוד הריקוד הקטן לפני כל ריקוד משותף",
        "תרגול עקבי של שלושת סגנונות הנפילה",
        "בהירות מוחלטת בסימון 'לא' פיזי ומילולי",
        "הקשבה רב-חושית מעבר לראייה"
      ),
      totalJamHours = 148.5f,
      currentStreakWeeks = 6,
      completedInquiriesCount = 8,
      savedRecordsCount = 4
    )
  )
  val dancerProfile: StateFlow<DancerProfile> = _dancerProfile.asStateFlow()

  private val _recordViewMode = MutableStateFlow(RecordViewMode.CARDS)
  val recordViewMode: StateFlow<RecordViewMode> = _recordViewMode.asStateFlow()

  private val _conversationViewMode = MutableStateFlow(ConversationViewMode.CHAT)
  val conversationViewMode: StateFlow<ConversationViewMode> = _conversationViewMode.asStateFlow()

  private val _selectedPillarFilter = MutableStateFlow<String?>("הכל")
  val selectedPillarFilter: StateFlow<String?> = _selectedPillarFilter.asStateFlow()

  private val _records = MutableStateFlow<List<MovementRecord>>(getInitialRecords())
  val records: StateFlow<List<MovementRecord>> = _records.asStateFlow()

  private val _inquiries = MutableStateFlow<List<ConversationInquiry>>(getInitialInquiries())
  val inquiries: StateFlow<List<ConversationInquiry>> = _inquiries.asStateFlow()

  val recommendations: List<SomaticRecommendation> = getInitialRecommendations()

  private val _somaticProgress = MutableStateFlow(calculateProgress(_records.value, _dancerProfile.value))
  val somaticProgress: StateFlow<SomaticProgress> = _somaticProgress.asStateFlow()

  fun setRecordViewMode(mode: RecordViewMode) {
    _recordViewMode.value = mode
  }

  fun setConversationViewMode(mode: ConversationViewMode) {
    _conversationViewMode.value = mode
  }

  fun setPillarFilter(pillar: String?) {
    _selectedPillarFilter.value = pillar
  }

  fun addRecord(newRecord: MovementRecord) {
    val updated = listOf(newRecord) + _records.value
    _records.value = updated
    _dancerProfile.value = _dancerProfile.value.copy(
      savedRecordsCount = updated.size,
      totalJamHours = _dancerProfile.value.totalJamHours + (newRecord.durationMinutes / 60f)
    )
    _somaticProgress.value = calculateProgress(updated, _dancerProfile.value)
  }

  fun deleteRecord(id: String) {
    val updated = _records.value.filterNot { it.id == id }
    _records.value = updated
    _dancerProfile.value = _dancerProfile.value.copy(savedRecordsCount = updated.size)
    _somaticProgress.value = calculateProgress(updated, _dancerProfile.value)
  }

  fun addMessageToInquiry(inquiryId: String, userText: String) {
    val updated = _inquiries.value.map { inquiry ->
      if (inquiry.id == inquiryId) {
        val userMsg = InquiryMessage(
          id = UUID.randomUUID().toString(),
          senderName = _dancerProfile.value.name,
          isGuide = false,
          text = userText,
          timeStr = "עכשיו"
        )
        val guideReply = generateGuideReply(inquiry.category, userText)
        inquiry.copy(
          messages = inquiry.messages + userMsg + guideReply,
          summaryInsights = inquiry.summaryInsights + "תובנה חדשה: " + userText.take(50) + "..."
        )
      } else inquiry
    }
    _inquiries.value = updated
  }

  fun updateProfile(
    name: String,
    bio: String,
    role: String,
    touchPref: String,
    intentions: List<String>
  ) {
    _dancerProfile.value = _dancerProfile.value.copy(
      name = name,
      bio = bio,
      primaryRole = role,
      touchPreference = touchPref,
      activeIntentions = intentions
    )
  }

  private fun generateGuideReply(category: String, userText: String): InquiryMessage {
    val text = when {
      userText.contains("גבול") || userText.contains("לא") ->
        "תשובה מעמיקה: מרטין קיו מדגיש שהסימון של ה'לא' אינו דחייה של הפרטנר, אלא כיול של שדה המשחק. כאשר אתה מאט ומנמיך את מרכז הכובד, אתה נותן לרקדן שמולך מתנה - ודאות שממנה יכולה לצמוח סקרנות אמיתית."
      userText.contains("משקל") || userText.contains("נפילה") ->
        "תובנה סומטית: בשיתוף משקל, הכוח אינו מגיע מהשרירים אלא מהשלד וכוח המשיכה. כששני רקדנים מוצאים מרכז כובד משותף, הנפילה הופכת לתנופה מתמשכת במקום לעצירה."
      else ->
        "הקשבה דרך הגוף: סטיב פקסטון תיאר את 'הריקוד הקטן' כחזרה לתשומת לב עמוקה. המשך לחקור כיצד שינוי מזערי בתשומת הלב שלך משנה את כל הדיאלוג ברגע הנוכחי."
    }
    return InquiryMessage(
      id = UUID.randomUUID().toString(),
      senderName = "מדריך סומטי (ci-eye)",
      isGuide = true,
      text = text,
      timeStr = "עכשיו",
      contextTip = "מבוסס על עקרונות הדיאלוג הנע"
    )
  }

  private fun calculateProgress(records: List<MovementRecord>, profile: DancerProfile): SomaticProgress {
    val avgWeight = if (records.isNotEmpty()) records.map { it.weightSharingLevel }.average().toFloat() * 10f else 82f
    val avgAttunement = if (records.isNotEmpty()) records.map { it.attunementLevel }.average().toFloat() * 10f else 88f
    val avgBoundary = if (records.isNotEmpty()) records.map { it.boundaryClarityLevel }.average().toFloat() * 10f else 92f
    val fallingScore = if (records.isNotEmpty()) records.map { it.fallingMomentumLevel }.average().toFloat() * 10f else 84f
    val groundingScore = if (records.isNotEmpty()) records.map { it.groundingLevel }.average().toFloat() * 10f else 89f
    val nonVerbalScore = if (records.isNotEmpty()) records.map { it.tactileAttentionLevel }.average().toFloat() * 10f else 86f

    val overall = (avgWeight + avgAttunement + avgBoundary + fallingScore + groundingScore + nonVerbalScore) / 6f

    val weeklyData = listOf(
      DaySessionData("א'", 1.5f, 4.0f),
      DaySessionData("ב'", 0.0f, 0.0f),
      DaySessionData("ג'", 2.0f, 4.8f),
      DaySessionData("ד'", 0.0f, 0.0f),
      DaySessionData("ה'", 1.2f, 4.2f),
      DaySessionData("ו'", 3.0f, 5.0f),
      DaySessionData("ש'", 2.5f, 4.7f)
    )

    val milestones = listOf(
      ProgressMilestone(
        id = "m1",
        title = "הריקוד הקטן",
        description = "הקשבה דרוכה לכוח המשיכה ומיקרו-התאמות של השלד",
        isUnlocked = true,
        unlockedDate = "הושלם לפני שבוע",
        category = "סומטיקה",
        iconEmoji = "🌿"
      ),
      ProgressMilestone(
        id = "m2",
        title = "101 דרכים לומר לא",
        description = "תרגול תרגיל 'שני הנהרות' ובהירות גבולות פיזיים ומילוליים",
        isUnlocked = true,
        unlockedDate = "הושלם השבוע",
        category = "אתיקה וגבולות",
        iconEmoji = "🛡️"
      ),
      ProgressMilestone(
        id = "m3",
        title = "נפילה רכה והתאוששות",
        description = "הארכת שטח פנים במפגש עם הרצפה ומינוף תנופת הירידה לעלייה",
        isUnlocked = true,
        unlockedDate = "פעיל",
        category = "פיזיקה",
        iconEmoji = "🌊"
      ),
      ProgressMilestone(
        id = "m4",
        title = "מרכז כובד משותף",
        description = "הישענות דו-כיוונית בטוחה ומציאת נקודת איזון דינמית בג'אם",
        isUnlocked = true,
        unlockedDate = "פעיל",
        category = "שיתוף משקל",
        iconEmoji = "⚖️"
      ),
      ProgressMilestone(
        id = "m5",
        title = "הקשבה רב-חושית ועור",
        description = "פיתוח 'תשומת לב מוחשית' (Attention is Tactile) מעבר לראייה",
        isUnlocked = false,
        unlockedDate = "ביעד הקרוב",
        category = "חושים",
        iconEmoji = "✨"
      )
    )

    val narrative = "במהלך השבועות האחרונים נרשמה עלייה ניכרת במדד בהירות הגבולות (92%) וביכולת הוויסות בתרגיל שני הנהרות. תרגול 'הריקוד הקטן' תרם ליציבות קרקעית גבוהה (89%), תוך שילוב עדין של שלושת סגנונות הנפילה אל תוך מומנטום שיתוף המשקל."

    return SomaticProgress(
      attunementScore = avgAttunement.coerceIn(0f, 100f),
      weightShareScore = avgWeight.coerceIn(0f, 100f),
      boundaryScore = avgBoundary.coerceIn(0f, 100f),
      fallingMomentumScore = fallingScore,
      groundingScore = groundingScore,
      nonVerbalScore = nonVerbalScore,
      overallIndex = overall.coerceIn(0f, 100f),
      levelTitle = "חוקר/ת תנועה מתקדם/ת — רמת אמון גבוהה",
      nextLevelTitle = "מנחה דיאלוג סומטי וג'אמר/ית מנוסה",
      levelProgressPct = 78f,
      textualNarrative = narrative,
      weeklySessions = weeklyData,
      milestones = milestones
    )
  }

  private fun getInitialRecords(): List<MovementRecord> {
    return listOf(
      MovementRecord(
        id = "rec-1",
        title = "ג'אם סופשבוע בירושלים: הריקוד הקטן ומפגש אגן-גב",
        dateStr = "8 בנובמבר 2026",
        jamOrWorkshop = "ג'אם ירושלמי פתוח",
        partner = "יונתן ר.",
        durationMinutes = 90,
        pillarCategory = "הריקוד הקטן",
        contactPoints = listOf("אגן ומרכז", "גב אל גב", "שכמות וכתפיים"),
        weightSharingLevel = 8.5f,
        attunementLevel = 9.2f,
        boundaryClarityLevel = 9.5f,
        fallingMomentumLevel = 8.2f,
        groundingLevel = 9.6f,
        tactileAttentionLevel = 8.8f,
        twoRiversState = "מגע בכל מקום (מבוסס אמון)",
        reflectionNotes = "התחלנו בעמידה שקטה של 10 דקות להרגיש את כוח המשיכה והמיקרו-התאמות. המעבר לשיתוף משקל היה טבעי ורך, ללא מאמץ שרירי מיותר. נקודת המגע זרמה לאורך עמוד השדרה.",
        keyTakeaway = "כאשר תשומת הלב נמצאת בתנועה מתמדת, החקירה חיה ולא הופכת לתבניתית.",
        somaticSensations = listOf("חמימות בעמוד השדרה", "נשימה סרעפתית רגועה", "היענות לקרקע")
      ),
      MovementRecord(
        id = "rec-2",
        title = "סדנת '101 דרכים לומר לא' - תרגיל שני הנהרות",
        dateStr = "4 בנובמבר 2026",
        jamOrWorkshop = "סדנת עומק מרטין קיו",
        partner = "שירה ל.",
        durationMinutes = 120,
        pillarCategory = "גבולות והסכמה",
        contactPoints = listOf("כפות ידיים", "אמות הידיים", "כתף"),
        weightSharingLevel = 6.8f,
        attunementLevel = 9.6f,
        boundaryClarityLevel = 10.0f,
        fallingMomentumLevel = 7.5f,
        groundingLevel = 9.0f,
        tactileAttentionLevel = 9.2f,
        twoRiversState = "עצירה / סימון גבול (הורדת מרכז)",
        reflectionNotes = "תרגול עמוק של תרגיל 'שני הנהרות'. ההבנה שלומר 'לא' בביטחון היא הדבר שמזין את ה'כן' המלא והאותנטי. הורדת מרכז הכובד שימשה כסימון פיזי ברור ללא מילים מיותרות.",
        keyTakeaway = "עד שלאדם יש את הביטחון והיכולת לומר 'לא' למשהו, לא יהיה לו את האמון והיכולת לומר 'כן' מלא לאותו הדבר.",
        somaticSensations = listOf("שחרור מתח בצוואר", "תחושת בהירות פנימית", "גבול מוגן")
      ),
      MovementRecord(
        id = "rec-3",
        title = "ג'אם סטודיו תל אביב: שלושת סגנונות הנפילה",
        dateStr = "1 בנובמבר 2026",
        jamOrWorkshop = "ג'אם ערב בסטודיו נעים",
        partner = "דניאל ק.",
        durationMinutes = 80,
        pillarCategory = "נפילה ומומנטום",
        contactPoints = listOf("צלעות", "ירכיים", "משטח הרצפה"),
        weightSharingLevel = 9.0f,
        attunementLevel = 8.8f,
        boundaryClarityLevel = 8.9f,
        fallingMomentumLevel = 9.5f,
        groundingLevel = 8.6f,
        tactileAttentionLevel = 8.4f,
        twoRiversState = "מגע עדין בלבד במעברים",
        reflectionNotes = "חקרנו נפילה כקיפול צעיף (creasing down like a scarf), גלגול ככדור מתוח והארכת שטח מגע עם הרצפה (elongated surface). שימוש בריבאונד של הנפילה כדי לעלות מחדש.",
        keyTakeaway = "Following through: לא לתת לתנופה למות בנקודת השפל, אלא להשתמש בה כדי להמריא שוב.",
        somaticSensations = listOf("רפיון שרירי מועיל", "פיזור עומס אל הקרקע", "תנופה חסרת מאמץ")
      ),
      MovementRecord(
        id = "rec-4",
        title = "דיאלוג עיוור: הקשבה דרך מגע ועור",
        dateStr = "26 באוקטובר 2026",
        jamOrWorkshop = "מעבדת אימפרוביזציה",
        partner = "נועה מ.",
        durationMinutes = 60,
        pillarCategory = "הקשבה סומטית",
        contactPoints = listOf("ראש אל כתף", "צלעות", "כפות רגליים"),
        weightSharingLevel = 7.8f,
        attunementLevel = 9.8f,
        boundaryClarityLevel = 9.2f,
        fallingMomentumLevel = 8.4f,
        groundingLevel = 8.5f,
        tactileAttentionLevel = 9.7f,
        twoRiversState = "מגע מדורג וקשוב",
        reflectionNotes = "חקירה בעיניים עצומות. תפיסת המרחב השתנתה לחלוטין. תשומת הלב הפכה למגע מוחשי (Attention is Tactile) - חווינו הדדיות רגשית ועורית עמוקה.",
        keyTakeaway = "העור אינו קו גבול מפריד, אלא איבר שמיעה הדדי בעל רגישות אינסופית.",
        somaticSensations = listOf("דופק מאוזן", "רגישות עורית מוגברת", "תחושת מרחב 360 מעלות")
      )
    )
  }

  private fun getInitialRecommendations(): List<SomaticRecommendation> {
    return listOf(
      SomaticRecommendation(
        id = "rec-tip-1",
        shortTitle = "הריקוד הקטן",
        shortTitleEn = "The Small Dance",
        subtitleTag = "קרקוע והקשבה לשלד",
        subtitleTagEn = "Grounding & Skeletal Listening",
        axisType = SomaticAxisType.GROUNDING,
        summaryPreview = "2 דקות עמידה שקטה לפני ג׳אם",
        fullExplanation = "סטיב פקסטון פיתח את 'הריקוד הקטן' (The Small Dance) כדי לאפשר לרקדן לחוש את הרפלקסים העדינים של השלד מול כוח המשיכה עוד לפני שמתחילים לנוע עם פרטנר.",
        fullExplanationEn = "Steve Paxton developed 'The Small Dance' so dancers can sense the subtle skeletal reflexes against gravity in quiet standing before entering a duet.",
        practicalSteps = listOf(
          "עמדו בפיסוק ברוחב האגן ושחררו נעילה מהברכיים.",
          "שימו לב למיקרו-תנודות בכפות הרגליים ובגב התחתון.",
          "תנו לשלד להחזיק אתכם במינימום מאמץ שרירי."
        ),
        practicalStepsEn = listOf(
          "Stand with feet hip-width apart and soften your knees.",
          "Notice micro-adjustments in the soles of your feet and lower back.",
          "Allow your skeleton to support you with minimal muscular effort."
        ),
        quoteText = "זה התחיל מתוך מצב של אמון בגוף ובאדמה.",
        quoteTextEn = "It began from a state of trust in the body and the earth.",
        quoteAuthor = "סטיב פקסטון",
        quoteAuthorEn = "Steve Paxton",
        hasInteractivePractice = true
      ),
      SomaticRecommendation(
        id = "rec-tip-2",
        shortTitle = "שני הנהרות וגבולות",
        shortTitleEn = "Two Rivers & Boundaries",
        subtitleTag = "101 דרכים לומר לא",
        subtitleTagEn = "101 Ways to Say No",
        axisType = SomaticAxisType.BOUNDARIES,
        summaryPreview = "כיצד 'לא' בטוח מאפשר 'כן' שלם",
        fullExplanation = "בסדנתו של מרטין קיו, היכולת לסמן גבול ברור — דרך הורדת מרכז הכובד, שינוי טונוס או סימון יד — היא הבסיס שמאפשר אמון מלא ופתיחות למגע.",
        fullExplanationEn = "Inspired by Martin Keogh's workshop, signaling a clear boundary—by lowering your center, shifting tone, or redirecting—builds the trust needed for a wholehearted 'yes'.",
        practicalSteps = listOf(
          "כשאינך מעוניין/ת בהרמה, הנמך/י את האגן והפוך/י לקרקע יציבה.",
          "זכור/י: שינוי כיוון או הקטנת מגע הם חלק טבעי מהדיאלוג, לא דחייה אישית.",
          "בדוק/י עם עצמך בכל רגע: האם המגע כרגע מדויק לי?"
        ),
        practicalStepsEn = listOf(
          "If you do not want a lift, lower your pelvis and become stable ground.",
          "Remember: redirecting or lightening touch is a natural part of the dialogue, not rejection.",
          "Check in with yourself continuously: does this contact feel right now?"
        ),
        quoteText = "עד שלאדם יש את הביטחון והיכולת לומר 'לא' למשהו, לא יהיה לו את האמון לומר 'כן' מלא לאותו הדבר.",
        quoteTextEn = "Until a person has the safety and ability to say 'no' to something, they cannot truly say a full 'yes' to it.",
        quoteAuthor = "מרטין קיו",
        quoteAuthorEn = "Martin Keogh"
      ),
      SomaticRecommendation(
        id = "rec-tip-3",
        shortTitle = "שיתוף משקל ואיזון",
        shortTitleEn = "Weight Sharing & Balance",
        subtitleTag = "מרכז כובד משותף",
        subtitleTagEn = "Shared Center of Gravity",
        axisType = SomaticAxisType.WEIGHT_SHARING,
        summaryPreview = "מפגש אגן-שכמות ותמיכה הדדית",
        fullExplanation = "בשיתוף משקל איננו 'סוחבים' את הפרטנר בכוח השרירים, אלא מוצאים קשת משותפת שבה שני הגופים נשענים אל נקודת מפגש אחת והעומס זורם אל הרצפה.",
        fullExplanationEn = "In weight sharing we do not 'carry' our partner with muscular force; instead, we find a shared arch where both bodies lean into a single rolling point and pour weight into the floor.",
        practicalSteps = listOf(
          "התחילו בהישענות עדינה של גב אל גב או כתף אל כתף.",
          "העבירו משקל בהדרגה רק כל עוד כפות הרגליים שלכם חשות יציבות.",
          "השתמשו ברגל חופשית או בזרוע כמשקולת נגדית לאיזון (Counter-balance)."
        ),
        practicalStepsEn = listOf(
          "Begin with a gentle lean back-to-back or shoulder-to-shoulder.",
          "Pour weight gradually only while your feet feel grounded and stable.",
          "Use a free leg or arm as a natural counterbalance."
        ),
        quoteText = "תנועה לתוך ומחוץ לאיזון בנפילה מתמשכת זה לעבר זה, סביב זה וכלפי הרצפה.",
        quoteTextEn = "Moving into and out of balance in an ongoing fall toward, around, and with one another.",
        quoteAuthor = "הדיאלוג הנע",
        quoteAuthorEn = "The Moving Dialogue"
      ),
      SomaticRecommendation(
        id = "rec-tip-4",
        shortTitle = "נפילה רכה ומומנטום",
        shortTitleEn = "Soft Falling & Momentum",
        subtitleTag = "שלושת סגנונות הנפילה",
        subtitleTagEn = "Three Styles of Falling",
        axisType = SomaticAxisType.FALLING_MOMENTUM,
        summaryPreview = "להפוך ירידה לרצפה לתנופת עלייה",
        fullExplanation = "נפילה בקונטקט אינה התרסקות אלא המשך זרימה: התקפלות רכה כצעיף, התעגלות ככדור, או התארכות לאורך הרצפה להגדלת שטח הפנים.",
        fullExplanationEn = "Falling in Contact Improvisation is not crashing—it is continuous flow: creasing down like a scarf, rolling like a ball, or elongating surface contact along the floor.",
        practicalSteps = listOf(
          "הגדילו את שטח המגע עם הרצפה כדי לפזר את העומס ברכות.",
          "אל תיתנו לתנופה להיעצר בנקודת השפל (Following through).",
          "השתמשו באנרגיית המפגש עם הקרקע כדי להתגלגל ולעלות מחדש."
        ),
        practicalStepsEn = listOf(
          "Widen your surface contact with the floor to distribute force softly.",
          "Follow through—don't let momentum die at the lowest point.",
          "Use the rebound from the floor to spiral and rise effortlessly."
        ),
        quoteText = "Following through: לא לתת לתנופה למות בנקודת השפל, אלא להשתמש בה כדי להמריא שוב.",
        quoteTextEn = "Following through: never let momentum die at the bottom; ride the rebound to rise again.",
        quoteAuthor = "עקרונות יסוד ב-CI",
        quoteAuthorEn = "CI Core Principles"
      ),
      SomaticRecommendation(
        id = "rec-tip-5",
        shortTitle = "הקשבה סומטית בתנועה",
        shortTitleEn = "Somatic Attunement",
        subtitleTag = "תשומת לב נעה",
        subtitleTagEn = "Moving Attention",
        axisType = SomaticAxisType.ATTUNEMENT,
        summaryPreview = "לשמור על סקרנות ושאלה פתוחה",
        fullExplanation = "כאשר תשומת הלב שלנו מתקבעת על תבנית מוכרת, החקירה נעלמת. הקשבה סומטית פירושה לשמור על קשב גמיש שעוקב אחר שינויים זעירים במהירות, בנשימה ובכיוון.",
        fullExplanationEn = "When attention fixates on a familiar habit, inquiry vanishes. Somatic attunement means keeping a fluid, curious attention that tracks subtle shifts in breath, tone, and direction.",
        practicalSteps = listOf(
          "הקשיבו לנשימה שלכם ולנשימת הפרטנר דרך נקודת המגע.",
          "אם הריקוד הופך אוטומטי, האטו ב-50% והמתינו להפתעה הבאה.",
          "אפשרו לנקודת המגע להתגלגל מעצמה מבלי לדחוף אותה."
        ),
        practicalStepsEn = listOf(
          "Listen to both your breath and your partner's breath through the point of contact.",
          "If the dance feels automatic, slow down by 50% and wait for the next surprise.",
          "Allow the rolling point of contact to lead without pushing it."
        ),
        quoteText = "התפיסה עוקבת אחר תשומת הלב; כאשר תשומת הלב מתקבעת, החקירה נעלמת.",
        quoteTextEn = "Perception follows attention; when attention becomes fixed, inquiry disappears.",
        quoteAuthor = "סטיב פקסטון",
        quoteAuthorEn = "Steve Paxton"
      ),
      SomaticRecommendation(
        id = "rec-tip-6",
        shortTitle = "תשומת לב עורית",
        shortTitleEn = "Tactile Attention",
        subtitleTag = "Attention is Tactile",
        subtitleTagEn = "Attention is Tactile",
        axisType = SomaticAxisType.TACTILE_ATTENTION,
        summaryPreview = "העור כאיבר הקשבה תלת-ממדי",
        fullExplanation = "ניטה ליטל וג׳וזף דומיט מתארים כיצד הכוונת תשומת הלב אל העור ואל המרחב שבין הרקדנים יוצרת תחושת מגע מוחשית והדדיות רגשית גם בתנועה עדינה.",
        fullExplanationEn = "Nita Little and Joseph Dumit describe how directing attention to the skin and the space between dancers creates tactile presence and 360° spatial awareness.",
        practicalSteps = listOf(
          "נסו דקה של תנועה בעיניים חצי-עצומות או במבט רך והיקפי.",
          "חושו את הטמפרטורה והמרקם של נקודת המגע.",
          "שימו לב גם למרחב שמאחורי הגב שלכם בזמן הריקוד."
        ),
        practicalStepsEn = listOf(
          "Explore a minute of movement with soft peripheral vision or half-closed eyes.",
          "Sense the temperature, texture, and direction of the contact point.",
          "Stay aware of the 360° space behind your back while moving."
        ),
        quoteText = "האופן שבו אנו מכוונים את תשומת הלב שלנו משפיע באופן ישיר ומוחשי על החוויה הגופנית שלנו.",
        quoteTextEn = "How we direct our attention has a direct, tangible effect on our bodily experience.",
        quoteAuthor = "ניטה ליטל וג׳וזף דומיט",
        quoteAuthorEn = "Nita Little & Joseph Dumit"
      )
    )
  }

  private fun getInitialInquiries(): List<ConversationInquiry> {
    return listOf(
      ConversationInquiry(
        id = "inq-1",
        title = "חקירת גבולות והסכמה: 'לא' מאפשר 'כן' מלא",
        category = "גבולות והסכמה",
        subtitle = "על בסיס עבודתו של מרטין קיו בסדנת '101 דרכים לומר לא'",
        dateStr = "5 בנובמבר 2026",
        relatedStudyQuestion = "תאר את הרעיון המרכזי בסדנת 101 דרכים לומר לא והסבר את הקשר לאמון",
        somaticPrinciple = "גבולות ברורים מגבירים את האמון והמסוגלות להיפתח לדרגות מגע שונות",
        authorReference = "מרטין קיו (Martin Keogh)",
        summaryInsights = listOf(
          "היכולת לומר 'לא' בביטחון היא תנאי יסוד לפיתוח אמון מלא.",
          "בתרגיל שני הנהרות, השליטה של המקבל על הגבולות פותחת אותו למגע רחב יותר.",
          "סימון 'לא' פיזי ע\"י הנמכת מרכז הכובד מאפשר תקשורת ישירה ללא אשמה."
        ),
        messages = listOf(
          InquiryMessage(
            id = "m1-1",
            senderName = "מדריך סומטי (ci-eye)",
            isGuide = true,
            text = "שלום זוהר. מה הבנת מתוך תרגיל 'שני הנהרות' בנוגע לתחושת הביטחון שלך כשרקדן אחר מתקרב?",
            timeStr = "10:15",
            contextTip = "תרגיל שפותח לבדיקת רמות מגע שונות ושליטת המקבל"
          ),
          InquiryMessage(
            id = "m1-2",
            senderName = "זוהר בר-און",
            isGuide = false,
            text = "שמתי לב שברגע שידעתי שיש לי מנדט מוחלט לעצור או לסמן 'מגע עדין בלבד' עם היד, הגוף שלי נרגע לחלוטין והצלחתי לקבל משקל שקודם היה מבהיל אותי.",
            timeStr = "10:18"
          ),
          InquiryMessage(
            id = "m1-3",
            senderName = "מדריך סומטי (ci-eye)",
            isGuide = true,
            text = "מדויק להפליא. מרטין קיו כותב: 'עד שלאדם יש את הביטחון והיכולת לומר לא, לא יהיה לו האמון לומר כן מלא'. איך התבטא ה'לא' הפיזי שלך בג'אם האחרון?",
            timeStr = "10:20"
          ),
          InquiryMessage(
            id = "m1-4",
            senderName = "זוהר בר-און",
            isGuide = false,
            text = "כשמישהו ניסה להרים אותי מוקדם מדי, במקום להיאבק פשוט הורדתי את מרכזי הכובד שלי לאדמה והתרחקתי במילומטרים בודדים. הגוף שלי נעשה כבד מדי להרמה - אמרתי 'לא' בבהירות ובחיוך.",
            timeStr = "10:24"
          )
        )
      ),
      ConversationInquiry(
        id = "inq-2",
        title = "הריקוד הקטן והגוף ככלי נגינה מכוונן",
        category = "הקשבה סומטית",
        subtitle = "חקירה סביב משנתו המקורית של סטיב פקסטון (1972)",
        dateStr = "2 בנובמבר 2026",
        relatedStudyQuestion = "הסבר את רעיון הגוף כ'כלי נגינה מכוונן' ותרגול הריקוד הקטן",
        somaticPrinciple = "מצב של אמון בגוף ובאדמה, ללא כוריאוגרפיה מוכתבת מראש",
        authorReference = "סטיב פקסטון (Steve Paxton)",
        summaryInsights = listOf(
          "הריקוד הקטן הוא התבוננות בעמידה במקום כדי לחוש התאמות עדינות ביחס לכוח המשיכה.",
          "הגוף אינו כלי הרגלי סגור, אלא כלי שניתן לכוונן להרחבת אוצר התנועה.",
          "כאשר תשומת הלב מתקבעת, החקירה נעלמת; תשומת הלב חייבת להיות בתנועה מתמדת."
        ),
        messages = listOf(
          InquiryMessage(
            id = "m2-1",
            senderName = "מדריך סומטי (ci-eye)",
            isGuide = true,
            text = "ברוך הבא לתרגול הריקוד הקטן (The Small Dance). כיצד חווית את היחס בין עמוד השדרה שלך לכוח המשיכה בעמידה ללא תנועה גלויה?",
            timeStr = "16:00",
            contextTip = "חזרה ליסודות תיאטרון המחול ג'אדסון"
          ),
          InquiryMessage(
            id = "m2-2",
            senderName = "זוהר בר-און",
            isGuide = false,
            text = "גיליתי שהגוף אף פעם לא באמת דומם. תמיד יש נדנוד עדין, מיקרו-התאמה של הקרסוליים והשוקיים, והנשימה שמעבירה גלים לאורך השלד.",
            timeStr = "16:04"
          ),
          InquiryMessage(
            id = "m2-3",
            senderName = "מדריך סומטי (ci-eye)",
            isGuide = true,
            text = "זוהי תמצית ההבחנה של פקסטון: המפגש שמתחיל מתוך 'מצב של אמון בגוף ובאדמה'. כשאתה פוגש פרטנר מתוך המצב הזה, אין צורך להמציא צעדים - הדיאלוג נובע מתוך כוח המשיכה המשותף.",
            timeStr = "16:07"
          )
        )
      ),
      ConversationInquiry(
        id = "inq-3",
        title = "אתיקה בג'אם ואיזון כוחות במרחב",
        category = "אתיקה וקהילה",
        subtitle = "דיון בהשראת מאמרה של קתלין ריאה ומודל The Field Center",
        dateStr = "28 באוקטובר 2026",
        relatedStudyQuestion = "האם העיקרון 'שמור על עצמך' מספיק? כיצד מנווטים פערי כוחות?",
        somaticPrinciple = "שילוב העיקרון 'שמור על אחרים' עם אחריות מוגברת של רקדנים ותיקים ומורים",
        authorReference = "קתלין ריאה (Kathleen Rea)",
        summaryInsights = listOf(
          "בג'אם מתקיימים פערי כוחות חברתיים (ותק, מגדר, מורה/תלמיד) שחייבים להילקח בחשבון.",
          "העיקרון 'שמור על עצמך' אינו פוטר את הצד החזק מאחריות אתית להסכמה.",
          "הג'אם הוא מרחב למידה וגילוי, ואין להעביר בו שיעורים לא מבוקשים."
        ),
        messages = listOf(
          InquiryMessage(
            id = "m3-1",
            senderName = "מדריך סומטי (ci-eye)",
            isGuide = true,
            text = "בג'אם האחרון צפית בדינמיקה בין רקדן מתחיל לרקדן ותיק. מה הבחנת בנוגע לאחריות המשותפת?",
            timeStr = "19:10"
          ),
          InquiryMessage(
            id = "m3-2",
            senderName = "זוהר בר-און",
            isGuide = false,
            text = "שמתי לב שהוותיק הרפה ממהירות התנועה שלו והתאים את מידת שיתוף המשקל ליכולת ההיענות של החדש. זה לא היה מתנשא או מלמד, אלא יצר מרחב מכבד שאיפשר לחדש ליהנות מבלי לחשוש מפציעה.",
            timeStr = "19:15"
          )
        )
      )
    )
  }
}
