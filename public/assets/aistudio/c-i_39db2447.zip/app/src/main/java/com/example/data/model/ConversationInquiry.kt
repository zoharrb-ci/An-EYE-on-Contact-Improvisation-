package com.example.data.model

data class InquiryMessage(
  val id: String,
  val senderName: String,
  val isGuide: Boolean,
  val text: String,
  val timeStr: String,
  val contextTip: String? = null
)

data class ConversationInquiry(
  val id: String,
  val title: String,
  val category: String,
  val subtitle: String,
  val dateStr: String,
  val messages: List<InquiryMessage>,
  val summaryInsights: List<String>,
  val relatedStudyQuestion: String,
  val somaticPrinciple: String,
  val authorReference: String
)
